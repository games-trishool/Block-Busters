# Project artwork

The app icon and feature graphic were authored for Block Busters using original SVG geometry in the game's navy, mint, violet, and peach palette. No third-party image assets are used.

- `icon.svg`: editable 1024 × 1024 app icon; opaque background, with Android/Google Play applying their own outer masks.
- `icon.png`: 1024 × 1024 PNG rendition for Android export configuration.
- `icon-foreground.svg` / `icon-background.svg`: 432 × 432 Android adaptive icon layers. The transparent foreground emblem fits inside the centered 264-pixel safe circle.
- `store-icon.png`: 512 × 512 PNG for the Google Play listing.
- `store-feature.svg` / `store-feature.png`: editable source and 1024 × 500 Play feature graphic.

The feature graphic uses the system DejaVu Sans font when rendered. No font binary is included in these files.

To regenerate PNGs with Inkscape:

```sh
inkscape assets/icon.svg --export-filename=assets/icon.png --export-width=1024 --export-height=1024
inkscape assets/icon.svg --export-filename=assets/store-icon.png --export-width=512 --export-height=512
inkscape assets/store-feature.svg --export-filename=assets/store-feature.png --export-width=1024 --export-height=500
```
