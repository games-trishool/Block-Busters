extends SceneTree
## Exercises the actual app, local persistence, and lifecycle integration.

var checks := 0
var failures := 0

func _initialize() -> void:
	_run.call_deferred()

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error("FAIL: " + message)
	else:
		print("PASS: ", message)

func _run() -> void:
	var store_script = load("res://scripts/save_store.gd")
	var store = store_script.new()
	store.save_path = "user://app-test-progress.cfg"
	DirAccess.remove_absolute(store.save_path)
	store.load_data()
	check(store.best_score == 0 and store.runs == 0, "fresh install has safe progress defaults")
	store.best_score = 8765
	store.runs = 12
	store.sound_enabled = false
	store.haptics_enabled = false
	check(store.save_data() == OK, "progress atomically saves")
	var restored = store_script.new()
	restored.save_path = store.save_path
	restored.load_data()
	check(restored.best_score == 8765 and restored.runs == 12, "score and run count survive reload")
	check(not restored.sound_enabled and not restored.haptics_enabled, "settings survive reload")
	var corrupt := FileAccess.open(store.save_path, FileAccess.WRITE)
	corrupt.store_string("corrupt {broken data")
	corrupt.close()
	var recover = store_script.new()
	recover.save_path = store.save_path
	recover.load_data()
	check(recover.best_score == 0 and recover.sound_enabled, "invalid save falls back to defaults")
	DirAccess.remove_absolute(store.save_path)

	var scene = load("res://scenes/main.tscn").instantiate()
	root.add_child(scene)
	await process_frame
	check(scene.screen == "home" and not scene.game.visible, "app boots into playable home screen")
	# Keep all app test writes separate from ordinary saved progress.
	scene.progress.save_path = "user://app-test-progress.cfg"
	scene.progress.best_score = 0
	scene.progress.runs = 0
	scene._start_run()
	check(scene.screen == "game" and scene.game.get_state() == "ready", "play opens ready endless run")
	check(scene.game.bricks.size() > 0 and scene.game.lives == 3, "run has targets and three lives")
	scene.game.launch_ball()
	check(scene.game.get_state() == "playing", "launch begins active gameplay")
	scene._on_score(1234)
	check(scene.progress.best_score == 1234 and scene.score_label.text == "1,234", "score signal updates formatted HUD and best score")
	scene._pause()
	check(scene.screen == "pause" and scene.game.get_state() == "paused", "pause stops simulation")
	var held_ball: Vector2 = scene.game.ball_position
	scene.game._physics_process(0.5)
	check(scene.game.ball_position == held_ball, "ball stays fixed during pause")
	scene._show_settings("pause")
	var old_sound: bool = scene.progress.sound_enabled
	scene._toggle_sound()
	check(scene.progress.sound_enabled != old_sound and scene.sounds.enabled == scene.progress.sound_enabled, "sound toggle updates engine and saves")
	var old_haptics: bool = scene.progress.haptics_enabled
	scene._toggle_haptics()
	check(scene.progress.haptics_enabled != old_haptics and scene.game.haptics_enabled == scene.progress.haptics_enabled, "haptics toggle updates game and saves")
	scene._return_from_panel()
	check(scene.screen == "pause" and scene.game.get_state() == "paused", "settings back returns to paused run")
	scene._resume()
	check(scene.screen == "game" and scene.game.get_state() == "playing", "resume continues existing run")
	scene._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
	check(scene.screen == "pause" and scene.game.get_state() == "paused", "losing app focus pauses safely")
	scene._resume()
	scene.game.lives = 1
	scene.game.score = 1450
	scene.game._lose_life()
	check(scene.screen == "over" and scene.progress.best_score == 1450, "final life loss opens results and keeps best score")
	scene._start_run()
	check(scene.game.score == 0 and scene.game.lives == 3 and scene.progress.best_score == 1450, "retry resets run while preserving record")
	scene._show_home()
	scene._show_help("home")
	check(scene.screen == "help", "instructions reachable from home")
	scene._return_from_panel()
	check(scene.screen == "home", "instructions return home")
	scene._show_settings("home")
	scene._show_privacy()
	check(scene.screen == "privacy", "privacy notice available offline")
	scene._go_back()
	check(scene.screen == "settings", "Android Back leaves privacy for settings")
	scene._go_back()
	check(scene.screen == "home", "Android Back leaves settings for home")
	scene.queue_free()
	await process_frame
	DirAccess.remove_absolute(store.save_path)
	print("APP TESTS: %d checks, %d failures" % [checks, failures])
	quit(1 if failures > 0 else 0)
