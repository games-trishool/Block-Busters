extends SceneTree
## Real viewport-delivered touchscreen events exercise GUI emulation and gameplay.

var checks := 0
var failures := 0
var app: Node2D


func _initialize() -> void:
	_run.call_deferred()


func _check(condition: bool, message: String) -> void:
	checks += 1
	if condition:
		print("PASS: ", message)
	else:
		failures += 1
		push_error("FAIL: " + message)


func _touch(position: Vector2, pressed: bool) -> void:
	var event := InputEventScreenTouch.new()
	event.index = 0
	event.position = position
	event.pressed = pressed
	Input.parse_input_event(event)
	await process_frame


func _tap(position: Vector2) -> void:
	await _touch(position, true)
	await _touch(position, false)
	await process_frame


func _run() -> void:
	root.size = Vector2i(480, 900)
	app = load("res://scenes/main.tscn").instantiate()
	app.progress.save_path = "user://touch-ui-test-progress.cfg"
	DirAccess.remove_absolute(app.progress.save_path)
	root.add_child(app)
	await process_frame
	await process_frame
	_check(bool(ProjectSettings.get_setting("input_devices/pointing/emulate_mouse_from_touch")), "project enables touchscreen-to-GUI mouse emulation")
	_check(app.screen == "home", "touch test starts at home")
	await _tap(Vector2(240.0, 695.0))
	_check(app.screen == "game", "touching PLAY ENDLESS reaches the game through the actual GUI")
	_check(app.game.get_state() == "ready", "home button touch release does not accidentally launch the ball")
	await _touch(Vector2(320.0, 650.0), true)
	_check(app.game.get_state() == "playing", "real playfield touch launches the ready ball")
	_check(is_equal_approx(app.game._paddle_target, 320.0), "real touchscreen event positions the paddle")
	var drag := InputEventScreenDrag.new()
	drag.index = 0
	drag.position = Vector2(130.0, 650.0)
	drag.relative = Vector2(-190.0, 0.0)
	Input.parse_input_event(drag)
	await process_frame
	_check(is_equal_approx(app.game._paddle_target, 130.0), "real touchscreen drag moves the active paddle")
	await _touch(drag.position, false)
	await _tap(Vector2(422.0, 60.0))
	_check(app.screen == "pause" and app.game.get_state() == "paused", "HUD pause button works through touchscreen GUI emulation")
	await _tap(Vector2(240.0, 554.0))
	_check(app.screen == "settings" and app.game.get_state() == "paused", "touching Settings opens preferences while preserving the paused run")
	var old_sound: bool = app.progress.sound_enabled
	await _tap(Vector2(384.0, 341.0))
	_check(app.screen == "settings" and app.progress.sound_enabled != old_sound and app.sounds.enabled == app.progress.sound_enabled, "touching sound switch changes the actual audio preference")
	var old_haptics: bool = app.progress.haptics_enabled
	await _tap(Vector2(384.0, 467.0))
	_check(app.progress.haptics_enabled != old_haptics and app.game.haptics_enabled == app.progress.haptics_enabled, "touching haptics switch changes the actual game preference")
	await _tap(Vector2(240.0, 761.0))
	_check(app.screen == "privacy", "touch Privacy & credits opens the offline privacy notice")
	await _tap(Vector2(240.0, 727.0))
	_check(app.screen == "licenses", "touch Engine licenses opens the bundled open-source credits")
	await _tap(Vector2(240.0, 809.0))
	_check(app.screen == "privacy", "touch Back to privacy leaves engine credits")
	await _tap(Vector2(240.0, 790.0))
	_check(app.screen == "settings", "touch Back to settings preserves the paused settings context")
	await _tap(Vector2(60.0, 60.0))
	_check(app.screen == "pause" and app.game.get_state() == "paused", "touch Back returns preferences to paused run")
	await _tap(Vector2(240.0, 473.0))
	_check(app.screen == "game" and app.game.get_state() == "playing", "touch Resume continues the existing run")
	await _tap(Vector2(422.0, 60.0))
	await _tap(Vector2(240.0, 741.0))
	_check(app.screen == "home" and app.game.get_state() == "menu", "touch End run returns to home without launching a new ball")
	var path: String = app.progress.save_path
	app.queue_free()
	await process_frame
	DirAccess.remove_absolute(path)
	print("TOUCH UI TESTS: %d checks, %d failures" % [checks, failures])
	quit(1 if failures > 0 else 0)
