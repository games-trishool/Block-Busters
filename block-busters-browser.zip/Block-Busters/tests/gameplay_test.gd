extends SceneTree
## Run: godot --headless --path . --script tests/gameplay_test.gd

const Gameplay = preload("res://scripts/gameplay.gd")
var failures := 0
var checks := 0
var game: Node2D
var finished_scores: Array[int] = []


func _initialize() -> void:
	call_deferred("_run")


func _check(condition: bool, description: String) -> void:
	checks += 1
	if condition:
		print("PASS: ", description)
	else:
		failures += 1
		push_error("FAIL: " + description)


func _fixture_brick(rect: Rect2, hp: int = 1, row: int = 0, col: int = 0) -> Dictionary:
	return {"rect": rect, "row": row, "col": col, "hp": hp, "max_hp": hp, "color": Color.CYAN, "age": 1.0, "flash": 0.0}


func _run() -> void:
	game = Gameplay.new()
	root.add_child(game)
	game.set_physics_process(false)
	game.run_finished.connect(func(value: int) -> void: finished_scores.append(value))
	game.start_run()
	_check(game.get_state() == "ready" and game.lives == 3 and game.score == 0, "new run starts ready with three lives and zero score")
	_check(game.bricks.size() == 28, "opening board contains the expected 28 targets")
	game.aim_paddle(-100.0)
	_check(is_equal_approx(game.paddle_x, Gameplay.LEFT + Gameplay.PADDLE_WIDTH * 0.5), "paddle clamps to left arena edge")
	game.aim_paddle(1000.0)
	_check(is_equal_approx(game.paddle_x, Gameplay.RIGHT - Gameplay.PADDLE_WIDTH * 0.5), "paddle clamps to right arena edge")
	game.aim_paddle(240.0)
	game.launch_ball()
	_check(game.get_state() == "playing" and game.ball_velocity.y < 0.0, "launch enters play with upward ball velocity")
	game.ball_position = Vector2(33.0, 600.0)
	game.ball_velocity = Vector2(-500.0, -20.0)
	game._advance_ball(0.03)
	_check(game.ball_position.x >= Gameplay.LEFT + Gameplay.BALL_RADIUS and game.ball_velocity.x > 0.0, "swept wall collision reflects without leaving the arena")
	_check(absf(game.ball_velocity.y) > game.ball_velocity.length() * 0.29, "wall collision prevents nearly horizontal stalled rallies")
	game.paddle_x = 240.0
	game.ball_position = Vector2(240.0, 718.0)
	game.ball_velocity = Vector2(0.0, 600.0)
	game.combo = 4
	game._advance_ball(0.07)
	_check(game.ball_velocity.y < 0.0 and game.combo == 0, "paddle returns the ball and resets the rally combo")
	game.ball_position = Vector2(279.0, 718.0)
	game.ball_velocity = Vector2(0.0, 600.0)
	game._advance_ball(0.07)
	_check(game.ball_velocity.x > 200.0 and game.ball_velocity.y < 0.0, "paddle edge steers the rebound toward that edge")
	game.bricks.assign([_fixture_brick(Rect2(90.0, 250.0, 61.0, 28.0)), _fixture_brick(Rect2(350.0, 250.0, 61.0, 28.0), 1, 0, 5)])
	game.ball_position = Vector2(120.0, 320.0)
	game.ball_velocity = Vector2(0.0, -1500.0)
	game._advance_ball(0.08)
	_check(game.score == 25 and game.combo == 1 and game.bricks.size() == 1 and game.ball_velocity.y > 0.0, "fast ball cannot tunnel through a brick; destruction awards score and combo")
	game.bricks.assign([_fixture_brick(Rect2(90.0, 250.0, 61.0, 28.0), 2), _fixture_brick(Rect2(350.0, 250.0, 61.0, 28.0), 1, 0, 5)])
	game.score = 0
	game.combo = 0
	game.ball_position = Vector2(120.0, 320.0)
	game.ball_velocity = Vector2(0.0, -500.0)
	game._advance_ball(0.10)
	_check(game.bricks.size() == 2 and int(game.bricks[0]["hp"]) == 1 and game.score == 10, "armored brick retains one hit point after its first impact")
	game.ball_position = Vector2(120.0, 320.0)
	game.ball_velocity = Vector2(0.0, -500.0)
	game._advance_ball(0.10)
	_check(game.bricks.size() == 1 and game.score == 35 and game.combo == 1, "second armored impact destroys it and awards the destruction bonus")
	game.bricks.assign([_fixture_brick(Rect2(90.0, 250.0, 61.0, 28.0))])
	game.ball_position = Vector2(120.0, 320.0)
	game.ball_velocity = Vector2(0.0, -500.0)
	game._advance_ball(0.10)
	_check(not game.bricks.is_empty() and game.get_state() == "playing", "clearing the final target replenishes targets without ending or pausing the endless run")
	game.bricks.clear()
	game.ball_position = Vector2(71.5, 217.0)
	game._replenish_bricks()
	var safe_spawn := true
	for brick in game.bricks:
		var rect: Rect2 = brick["rect"]
		if rect.grow(Gameplay.BALL_RADIUS + 26.0).has_point(game.ball_position):
			safe_spawn = false
	_check(safe_spawn and game.bricks.size() == 12, "endless refill skips the ball's vicinity while adding twelve reachable targets")
	game.score = 1000000
	game._elapsed = 100000.0
	_check(game._ball_speed() <= Gameplay.MAX_SPEED, "difficulty speed remains capped even during a very long run")
	var before_pause: Vector2 = game.ball_position
	game.set_paused(true)
	game._physics_process(0.25)
	_check(game.get_state() == "paused" and game.ball_position == before_pause, "pause freezes gameplay and ball physics")
	game.set_paused(false)
	_check(game.get_state() == "playing", "resume restores the previous playing state")
	game.start_run()
	for expected_lives in [2, 1, 0]:
		game.launch_ball()
		game.ball_position = Vector2(35.0, 805.0)
		game.ball_velocity = Vector2(0.0, 600.0)
		game._advance_ball(0.10)
		_check(game.lives == expected_lives, "missing the paddle loses exactly one life: " + str(expected_lives) + " remain")
	_check(game.get_state() == "game_over" and finished_scores.size() == 1, "final miss emits one run result and enters game over")
	game.restart_run()
	var touch := InputEventScreenTouch.new()
	touch.index = 0
	touch.position = Vector2(320.0, 650.0)
	touch.pressed = true
	game._unhandled_input(touch)
	_check(game.get_state() == "playing" and is_equal_approx(game._paddle_target, 320.0), "touch starts a run and places the paddle beneath the player's finger")
	var drag := InputEventScreenDrag.new()
	drag.index = 0
	drag.position = Vector2(120.0, 670.0)
	game._unhandled_input(drag)
	_check(is_equal_approx(game._paddle_target, 120.0), "active finger drag moves the paddle target")
	game.set_paused(true)
	drag.position = Vector2(400.0, 670.0)
	game._unhandled_input(drag)
	_check(is_equal_approx(game._paddle_target, 120.0), "paused touch gestures cannot move the paddle")
	game.reset_to_menu()
	_check(game.get_state() == "menu" and game.bricks.is_empty(), "return to menu clears the active run")
	game.position = Vector2(64.0, 38.0)
	game.start_run()
	touch.position = Vector2(384.0, 688.0)
	game._unhandled_input(touch)
	_check(is_equal_approx(game._paddle_target, 320.0), "touch coordinates account for a centered canvas offset on larger screens")
	var emulated_mouse := InputEventMouseButton.new()
	emulated_mouse.device = -1
	emulated_mouse.button_index = MOUSE_BUTTON_LEFT
	emulated_mouse.pressed = true
	emulated_mouse.position = Vector2(164.0, 688.0)
	game._unhandled_input(emulated_mouse)
	_check(is_equal_approx(game._paddle_target, 320.0), "emulated mouse events cannot duplicate real touch or jump the paddle")
	game.position = Vector2.ZERO
	game.start_run()
	game.lives = 100
	game.launch_ball()
	var simulation_safe := true
	for frame in range(120 * 120):
		if game.get_state() == "ready":
			game.launch_ball()
		game.aim_paddle(game.ball_position.x)
		game._physics_process(1.0 / 120.0)
		var position: Vector2 = game.ball_position
		if not position.is_finite() or position.x < Gameplay.LEFT + Gameplay.BALL_RADIUS - 0.1 or position.x > Gameplay.RIGHT - Gameplay.BALL_RADIUS + 0.1:
			simulation_safe = false
			break
	_check(simulation_safe and game.score > 100 and not game.bricks.is_empty() and game.get_state() == "playing", "two-minute automated endless run scores, refills, and keeps a finite ball inside the arena")
	var occupied: Dictionary = {}
	var duplicate := false
	for brick in game.bricks:
		var cell := Vector2i(int(brick["col"]), int(brick["row"]))
		if occupied.has(cell):
			duplicate = true
		occupied[cell] = true
	_check(not duplicate and game.bricks.size() <= Gameplay.COLS * Gameplay.ROWS, "extended endless refills never overlap brick grid cells or exceed the fixed field")
	print("Gameplay checks: ", checks - failures, "/", checks, " passed")
	game.queue_free()
	quit(1 if failures else 0)
