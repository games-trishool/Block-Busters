class_name ProgressStore
extends RefCounted
## Local-only storage. No account, network, or personal information.

var best_score: int = 0
var runs: int = 0
var sound_enabled: bool = true
var haptics_enabled: bool = true
var save_path: String = "user://progress.cfg"

func load_data() -> void:
	var config := ConfigFile.new()
	if config.load(save_path) != OK:
		return
	best_score = maxi(0, int(config.get_value("progress", "best_score", 0)))
	runs = maxi(0, int(config.get_value("progress", "runs", 0)))
	sound_enabled = bool(config.get_value("settings", "sound", true))
	haptics_enabled = bool(config.get_value("settings", "haptics", true))

func save_data() -> Error:
	var config := ConfigFile.new()
	config.set_value("progress", "best_score", best_score)
	config.set_value("progress", "runs", runs)
	config.set_value("settings", "sound", sound_enabled)
	config.set_value("settings", "haptics", haptics_enabled)
	var temporary := save_path + ".tmp"
	var error := config.save(temporary)
	if error != OK:
		return error
	return DirAccess.rename_absolute(temporary, save_path)
