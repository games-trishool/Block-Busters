class_name BrickGame
extends Node2D
## An entirely offline endless brick breaker. All coordinates use a 480 × 900 canvas.

signal score_changed(score: int)
signal lives_changed(lives: int)
signal run_finished(score: int)
signal state_changed(state: String)
signal combo_changed(combo: int)
signal feedback(kind: String)

const LEFT := 24.0
const RIGHT := 456.0
const TOP := 172.0
const LOSS_Y := 812.0
const BALL_RADIUS := 7.0
const PADDLE_Y := 748.0
const PADDLE_WIDTH := 96.0
const PADDLE_HEIGHT := 12.0
const INITIAL_SPEED := 360.0
const MAX_SPEED := 660.0
const COLS := 6
const ROWS := 6
const BRICK_SIZE := Vector2(61.0, 28.0)
const GRID_ORIGIN := Vector2(41.0, 203.0)
const GRID_STEP := Vector2(67.0, 36.0)
const PALETTE: Array[Color] = [Color("ff6f91"), Color("ffad72"), Color("f5d878"), Color("a9e78a"), Color("6ee7dc"), Color("a9a0fa")]

var sound_enabled := true
var haptics_enabled := true
var score := 0
var lives := 3
var combo := 0
var bricks: Array[Dictionary] = []
var ball_position := Vector2(240.0, 727.0)
var ball_velocity := Vector2.ZERO
var paddle_x := 240.0
var _paddle_target := 240.0
var _state := "menu"
var _resume_state := "ready"
var _elapsed := 0.0
var _refill_cooldown := 0.0
var _generation := 0
var _particles: Array[Dictionary] = []
var _trail: Array[Vector2] = []
var _touch_id := -1
var _time := 0.0
var _paddle_flash := 0.0
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	_rng.seed = 190734
	set_physics_process(true)
	queue_redraw()


func start_run() -> void:
	score = 0
	lives = 3
	combo = 0
	paddle_x = 240.0
	_paddle_target = paddle_x
	_elapsed = 0.0
	_refill_cooldown = 1.0
	_generation = 0
	_particles.clear()
	_trail.clear()
	bricks.clear()
	_rng.seed = 190734
	for row in range(5):
		for col in range(COLS):
			# Leave a quiet central notch for the ball's first ascent.
			if row == 4 and (col == 2 or col == 3):
				continue
			_add_brick(row, col)
	_reset_ball()
	_set_state("ready")
	score_changed.emit(score)
	lives_changed.emit(lives)
	combo_changed.emit(combo)
	queue_redraw()


func restart_run() -> void:
	start_run()


func reset_to_menu() -> void:
	_set_state("menu")
	bricks.clear()
	_particles.clear()
	_trail.clear()
	ball_velocity = Vector2.ZERO
	_touch_id = -1
	queue_redraw()


func get_state() -> String:
	return _state


func set_paused(paused: bool) -> void:
	if paused and (_state == "playing" or _state == "ready"):
		_resume_state = _state
		_set_state("paused")
		_touch_id = -1
	elif not paused and _state == "paused":
		_set_state(_resume_state)


func toggle_pause() -> void:
	set_paused(_state != "paused")


func aim_paddle(x: float) -> void:
	if _state != "playing" and _state != "ready":
		return
	_paddle_target = clampf(x, LEFT + PADDLE_WIDTH * 0.5, RIGHT - PADDLE_WIDTH * 0.5)
	if _state == "ready":
		paddle_x = _paddle_target
		_reset_ball()


func launch_ball() -> void:
	if _state != "ready":
		return
	var direction := Vector2(0.31 if _generation % 2 == 0 else -0.31, -0.95).normalized()
	ball_velocity = direction * _ball_speed()
	_set_state("playing")
	feedback.emit("launch")


func _set_state(value: String) -> void:
	if _state == value:
		return
	_state = value
	state_changed.emit(_state)


func _reset_ball() -> void:
	ball_position = Vector2(paddle_x, PADDLE_Y - BALL_RADIUS - 8.0)
	ball_velocity = Vector2.ZERO
	_trail.clear()


func _ball_speed() -> float:
	return minf(MAX_SPEED, INITIAL_SPEED + _elapsed * 0.8 + float(score) * 0.018)


func _unhandled_input(event: InputEvent) -> void:
	if _state != "playing" and _state != "ready":
		return
	# Touch also produces emulated mouse events for the surrounding Godot UI.
	# The arena handles real touch directly, so ignore the duplicate pointer.
	if (event is InputEventMouseMotion or event is InputEventMouseButton) and event.device == -1:
		return
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		var position := get_global_transform_with_canvas().affine_inverse() * touch.position
		if touch.pressed and position.y > 145.0 and _touch_id == -1:
			_touch_id = touch.index
			aim_paddle(position.x)
			launch_ball()
			get_viewport().set_input_as_handled()
		elif not touch.pressed and touch.index == _touch_id:
			_touch_id = -1
			get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		if drag.index == _touch_id:
			var position := get_global_transform_with_canvas().affine_inverse() * drag.position
			aim_paddle(position.x)
			get_viewport().set_input_as_handled()
	elif event is InputEventMouseMotion:
		var motion := event as InputEventMouseMotion
		var position := get_global_transform_with_canvas().affine_inverse() * motion.position
		if position.y > 145.0:
			aim_paddle(position.x)
	elif event is InputEventMouseButton:
		var button := event as InputEventMouseButton
		var position := get_global_transform_with_canvas().affine_inverse() * button.position
		if button.button_index == MOUSE_BUTTON_LEFT and button.pressed and position.y > 145.0:
			aim_paddle(position.x)
			launch_ball()
	elif event is InputEventKey:
		var key := event as InputEventKey
		if key.pressed and not key.echo and key.keycode == KEY_SPACE:
			launch_ball()


func _physics_process(delta: float) -> void:
	_time += delta
	if _state == "playing" or _state == "ready":
		var direction := float(Input.is_physical_key_pressed(KEY_RIGHT) or Input.is_physical_key_pressed(KEY_D)) - float(Input.is_physical_key_pressed(KEY_LEFT) or Input.is_physical_key_pressed(KEY_A))
		if direction != 0.0:
			aim_paddle(_paddle_target + direction * 600.0 * delta)
		paddle_x = move_toward(paddle_x, _paddle_target, 1450.0 * delta)
		if _state == "ready":
			_reset_ball()
	if _state == "playing":
		_elapsed += delta
		_refill_cooldown -= delta
		if bricks.size() <= 8 and _refill_cooldown <= 0.0:
			_replenish_bricks()
		# Swept contacts prevent tunnelling, even after a slow device frame.
		var remaining := minf(delta, 0.25)
		while remaining > 0.0 and _state == "playing":
			var step := minf(remaining, 1.0 / 60.0)
			_advance_ball(step)
			remaining -= step
		_trail.push_front(ball_position)
		if _trail.size() > 11:
			_trail.pop_back()
	if _state != "paused":
		_paddle_flash = maxf(0.0, _paddle_flash - delta * 4.0)
		_update_particles(delta)
		for brick in bricks:
			brick["age"] = minf(1.0, float(brick["age"]) + delta * 4.0)
	queue_redraw()


func _advance_ball(delta: float) -> void:
	var remaining := delta
	var impact_count := 0
	while remaining > 0.000001 and impact_count < 10 and _state == "playing":
		var displacement := ball_velocity * remaining
		var hit_time := 1.0
		var normal := Vector2.ZERO
		var kind := "none"
		var brick_index := -1
		if displacement.x < 0.0:
			var t := (LEFT + BALL_RADIUS - ball_position.x) / displacement.x
			if t >= 0.0 and t <= hit_time:
				hit_time = t; normal = Vector2.RIGHT; kind = "wall"
		elif displacement.x > 0.0:
			var t := (RIGHT - BALL_RADIUS - ball_position.x) / displacement.x
			if t >= 0.0 and t <= hit_time:
				hit_time = t; normal = Vector2.LEFT; kind = "wall"
		if displacement.y < 0.0:
			var t := (TOP + BALL_RADIUS - ball_position.y) / displacement.y
			if t >= 0.0 and t <= hit_time:
				hit_time = t; normal = Vector2.DOWN; kind = "wall"
		elif displacement.y > 0.0:
			var t := (LOSS_Y - ball_position.y) / displacement.y
			if t >= 0.0 and t <= hit_time:
				hit_time = t; normal = Vector2.UP; kind = "loss"
			if ball_position.y <= PADDLE_Y - PADDLE_HEIGHT * 0.5:
				var paddle_rect := Rect2(paddle_x - PADDLE_WIDTH * 0.5, PADDLE_Y - PADDLE_HEIGHT * 0.5, PADDLE_WIDTH, PADDLE_HEIGHT)
				var paddle_hit := _sweep_rect(ball_position, displacement, paddle_rect.grow(BALL_RADIUS))
				if not paddle_hit.is_empty() and float(paddle_hit["time"]) <= hit_time:
					hit_time = float(paddle_hit["time"]); normal = Vector2.UP; kind = "paddle"
		for index in range(bricks.size()):
			var rect: Rect2 = bricks[index]["rect"]
			var hit := _sweep_rect(ball_position, displacement, rect.grow(BALL_RADIUS))
			if not hit.is_empty() and float(hit["time"]) < hit_time:
				hit_time = float(hit["time"])
				normal = hit["normal"]
				kind = "brick"
				brick_index = index
		ball_position += displacement * hit_time
		if kind == "none":
			break
		remaining *= 1.0 - hit_time
		impact_count += 1
		if kind == "loss":
			_lose_life()
			break
		if kind == "paddle":
			var offset := clampf((ball_position.x - paddle_x) / (PADDLE_WIDTH * 0.5), -1.0, 1.0)
			var angle := offset * 1.02
			ball_velocity = Vector2(sin(angle), -cos(angle)) * _ball_speed()
			if absf(ball_velocity.x) < 45.0:
				ball_velocity.x = 45.0 if offset >= 0.0 else -45.0
				ball_velocity = ball_velocity.normalized() * _ball_speed()
			combo = 0
			combo_changed.emit(combo)
			_paddle_flash = 1.0
			_emit_particles(ball_position, Color("81f2df"), 8)
			feedback.emit("paddle")
		else:
			ball_velocity = ball_velocity.bounce(normal)
			if kind == "brick":
				_hit_brick(brick_index)
			else:
				feedback.emit("wall")
		# A minimum vertical component prevents long, almost horizontal rallies.
		var speed := _ball_speed()
		ball_velocity = ball_velocity.normalized() * speed
		if absf(ball_velocity.y) < speed * 0.32:
			ball_velocity.y = speed * 0.32 * (-1.0 if ball_velocity.y < 0.0 else 1.0)
			ball_velocity.x = sqrt(speed * speed - ball_velocity.y * ball_velocity.y) * (-1.0 if ball_velocity.x < 0.0 else 1.0)
		ball_position += normal * 0.12


func _sweep_rect(origin: Vector2, movement: Vector2, rect: Rect2) -> Dictionary:
	var enter := -INF
	var leave := INF
	var normal := Vector2.ZERO
	for axis in range(2):
		var p := origin[axis]
		var d := movement[axis]
		var minimum := rect.position[axis]
		var maximum := rect.end[axis]
		if absf(d) < 0.000001:
			if p < minimum or p > maximum:
				return {}
			continue
		var near_time := (minimum - p) / d
		var far_time := (maximum - p) / d
		var axis_normal := Vector2.ZERO
		axis_normal[axis] = -1.0 if d > 0.0 else 1.0
		if near_time > far_time:
			var swap := near_time; near_time = far_time; far_time = swap
		if near_time > enter:
			enter = near_time
			normal = axis_normal
		leave = minf(leave, far_time)
		if enter > leave:
			return {}
	if enter < -0.00001 or enter > 1.0 or leave < 0.0:
		return {}
	return {"time": maxf(0.0, enter), "normal": normal}


func _hit_brick(index: int) -> void:
	if index < 0 or index >= bricks.size():
		return
	var brick := bricks[index]
	brick["hp"] = int(brick["hp"]) - 1
	var rect: Rect2 = brick["rect"]
	var color: Color = brick["color"]
	if int(brick["hp"]) <= 0:
		combo += 1
		score += 25 + mini(combo - 1, 9) * 5
		bricks.remove_at(index)
		_emit_particles(rect.get_center(), color, 15)
		combo_changed.emit(combo)
		feedback.emit("break")
	else:
		score += 10
		brick["flash"] = 1.0
		_emit_particles(ball_position, color, 6)
		feedback.emit("hit")
	score_changed.emit(score)
	if bricks.is_empty():
		_replenish_bricks()


func _lose_life() -> void:
	lives -= 1
	combo = 0
	combo_changed.emit(combo)
	lives_changed.emit(lives)
	_emit_particles(ball_position - Vector2(0.0, 15.0), Color("ff6f91"), 22)
	feedback.emit("lose")
	_touch_id = -1
	if haptics_enabled and OS.has_feature("android"):
		Input.vibrate_handheld(65)
	if lives <= 0:
		ball_velocity = Vector2.ZERO
		_set_state("game_over")
		run_finished.emit(score)
	else:
		_reset_ball()
		_set_state("ready")


func _add_brick(row: int, col: int) -> bool:
	var rect := Rect2(GRID_ORIGIN + Vector2(col, row) * GRID_STEP, BRICK_SIZE)
	if _state == "playing" and rect.grow(BALL_RADIUS + 26.0).has_point(ball_position):
		return false
	var hp := 1
	if score >= 600 and (row + col + _generation) % 4 == 0:
		hp = 2
	if score >= 2200 and (row * 2 + col + _generation) % 7 == 0:
		hp = 3
	bricks.append({"rect": rect, "row": row, "col": col, "hp": hp, "max_hp": hp, "color": PALETTE[(row + _generation) % PALETTE.size()], "age": 0.0, "flash": 0.0})
	return true


func _replenish_bricks() -> void:
	_generation += 1
	_refill_cooldown = 0.75
	# Refill vacant fixed grid cells; targets never descend onto the paddle.
	# Skip the ball's immediate vicinity so a new brick cannot trap it.
	var occupied: Dictionary = {}
	for brick in bricks:
		occupied[Vector2i(int(brick["col"]), int(brick["row"]))] = true
	var count := 0
	for row in range(ROWS):
		for col in range(COLS):
			var cell := Vector2i(col, row)
			if not occupied.has(cell) and _add_brick(row, col):
				count += 1
			if count >= 12:
				return


func _emit_particles(position: Vector2, color: Color, amount: int) -> void:
	for i in range(amount):
		var angle := _rng.randf_range(0.0, TAU)
		_particles.append({"position": position, "velocity": Vector2.from_angle(angle) * _rng.randf_range(35.0, 180.0), "life": _rng.randf_range(0.25, 0.62), "max_life": 0.65, "size": _rng.randf_range(1.5, 4.0), "color": color})
	while _particles.size() > 180:
		_particles.pop_front()


func _update_particles(delta: float) -> void:
	for i in range(_particles.size() - 1, -1, -1):
		var particle := _particles[i]
		particle["life"] = float(particle["life"]) - delta
		if float(particle["life"]) <= 0.0:
			_particles.remove_at(i)
			continue
		particle["position"] = Vector2(particle["position"]) + Vector2(particle["velocity"]) * delta
		particle["velocity"] = Vector2(particle["velocity"]) * (1.0 - delta * 2.0)
	for brick in bricks:
		brick["flash"] = maxf(0.0, float(brick["flash"]) - delta * 6.0)


func _draw() -> void:
	if _state == "menu":
		return
	# Restrained guide rails frame the playfield without competing with the ball.
	draw_line(Vector2(LEFT, TOP + 2.0), Vector2(LEFT, 785.0), Color(0.36, 0.68, 0.72, 0.13), 1.0, true)
	draw_line(Vector2(RIGHT, TOP + 2.0), Vector2(RIGHT, 785.0), Color(0.36, 0.68, 0.72, 0.13), 1.0, true)
	for brick in bricks:
		var rect: Rect2 = brick["rect"]
		var color: Color = brick["color"]
		var age := float(brick["age"])
		var scale_factor := 0.78 + age * 0.22
		var visible_rect := Rect2(rect.get_center() - rect.size * scale_factor * 0.5, rect.size * scale_factor)
		var style := StyleBoxFlat.new()
		style.bg_color = color.lerp(Color.WHITE, float(brick["flash"]) * 0.5)
		style.bg_color.a = age
		style.set_corner_radius_all(7)
		style.shadow_color = Color(color, 0.10 * age)
		style.shadow_size = 6
		draw_style_box(style, visible_rect)
		draw_line(visible_rect.position + Vector2(9.0, 4.0), visible_rect.position + Vector2(visible_rect.size.x - 9.0, 4.0), Color(1.0, 1.0, 1.0, 0.24 * age), 1.0, true)
		var hp := int(brick["hp"])
		if int(brick["max_hp"]) > 1:
			for dot in range(hp):
				var dot_x := rect.get_center().x + (float(dot) - float(hp - 1) * 0.5) * 6.0
				draw_circle(Vector2(dot_x, rect.get_center().y), 1.6, Color(0.05, 0.09, 0.15, 0.52))
	for i in range(_trail.size() - 1, -1, -1):
		var strength := 1.0 - float(i) / float(maxi(1, _trail.size()))
		draw_circle(_trail[i], BALL_RADIUS * strength, Color(0.57, 0.96, 0.89, strength * 0.15))
	for particle in _particles:
		var color: Color = particle["color"]
		color.a *= clampf(float(particle["life"]) / 0.45, 0.0, 1.0)
		draw_circle(particle["position"], float(particle["size"]), color)
	if _state != "game_over":
		var pulse := 0.82 + sin(_time * 4.0) * 0.12
		draw_circle(ball_position, BALL_RADIUS * 2.3, Color(0.55, 0.97, 0.87, 0.06 * pulse))
		draw_circle(ball_position, BALL_RADIUS * 1.5, Color(0.55, 0.97, 0.87, 0.13 * pulse))
		draw_circle(ball_position, BALL_RADIUS, Color("f3fff9"))
	var paddle_style := StyleBoxFlat.new()
	paddle_style.bg_color = Color("a2f6dd").lerp(Color.WHITE, _paddle_flash * 0.6)
	paddle_style.set_corner_radius_all(6)
	paddle_style.shadow_color = Color(0.39, 0.96, 0.79, 0.17 + _paddle_flash * 0.12)
	paddle_style.shadow_size = 13
	draw_style_box(paddle_style, Rect2(paddle_x - PADDLE_WIDTH * 0.5, PADDLE_Y - PADDLE_HEIGHT * 0.5, PADDLE_WIDTH, PADDLE_HEIGHT))
	draw_line(Vector2(paddle_x - 14.0, PADDLE_Y), Vector2(paddle_x + 14.0, PADDLE_Y), Color(0.05, 0.25, 0.25, 0.25), 2.0, true)
	if _state == "ready":
		for i in range(5):
			var dot_position := ball_position + Vector2(0.31, -0.95).normalized() * (24.0 + float(i) * 15.0)
			draw_circle(dot_position, 1.8, Color(0.73, 0.96, 0.88, (1.0 - float(i) / 5.0) * 0.35))
