#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TOOLS_DIR="${BLOCK_BUSTERS_TOOLS_DIR:-/workspace/.block-busters-tools}"
if [[ ! -f "$TOOLS_DIR/env.sh" ]]; then
  bash "$PROJECT_DIR/tools/setup-android.sh"
fi
# shellcheck disable=SC1091
source "$TOOLS_DIR/env.sh"
cd "$PROJECT_DIR"
mkdir -p artifacts
touch artifacts/.gdignore

godot --headless --editor --path "$PROJECT_DIR" --import
prepare_gradle_template() {
  if [[ ! -f android/build/build.gradle ]]; then
    mkdir -p android/build
    unzip -q "$XDG_DATA_HOME/godot/export_templates/4.6.3.stable/android_source.zip" -d android/build
    cp "$XDG_DATA_HOME/godot/export_templates/4.6.3.stable/version.txt" android/.build_version
    touch android/.gdignore
  fi
  # Pin the wrapper's official release checksum before Gradle downloads/runs it.
  # The Android source template is from the verified Godot 4.6.3 release above.
  python3 - <<'PY'
from pathlib import Path
p = Path('android/build/gradle/wrapper/gradle-wrapper.properties')
text = p.read_text()
expected = 'https\\://services.gradle.org/distributions/gradle-8.11.1-bin.zip'
if 'distributionUrl=' + expected not in text:
    raise SystemExit('Unexpected Gradle version in Android template; update and verify the build tooling first.')
lines = [s for s in text.splitlines() if not s.startswith('distributionSha256Sum=')]
lines.append('distributionSha256Sum=f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6')
p.write_text('\n'.join(lines) + '\n')
PY
}
case "${1:-debug}" in
  debug)
    godot --headless --path "$PROJECT_DIR" --export-debug 'Android Debug' "$PROJECT_DIR/artifacts/block-busters-debug.apk"
    "$ANDROID_HOME/build-tools/36.1.0/apksigner" verify --verbose "$PROJECT_DIR/artifacts/block-busters-debug.apk"
    ;;
  unsigned)
    prepare_gradle_template
    godot --headless --path "$PROJECT_DIR" --export-release 'Android AAB Unsigned' "$PROJECT_DIR/artifacts/block-busters-unsigned.aab"
    ;;
  release)
    : "${GODOT_ANDROID_KEYSTORE_RELEASE_PATH:?Set the path to your private upload keystore}"
    : "${GODOT_ANDROID_KEYSTORE_RELEASE_USER:?Set your upload key alias}"
    : "${GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD:?Set the upload key password securely}"
    prepare_gradle_template
    godot --headless --path "$PROJECT_DIR" --export-release 'Android AAB Release' "$PROJECT_DIR/artifacts/block-busters-release.aab"
    jarsigner -verify "$PROJECT_DIR/artifacts/block-busters-release.aab" > artifacts/release-signature-check.txt
    cat artifacts/release-signature-check.txt
    if ! rg -q '^jar verified\.' artifacts/release-signature-check.txt; then
      printf 'Release AAB does not have a verified JAR signature.\n' >&2
      exit 1
    fi
    ;;
  *)
    printf 'Usage: %s [debug|unsigned|release]\n' "$0" >&2
    exit 2
    ;;
esac
