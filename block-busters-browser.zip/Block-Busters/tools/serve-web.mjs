#!/usr/bin/env node
// A dependency-free local server for the prebuilt Godot browser export.
import http from 'node:http';
import { createReadStream, existsSync } from 'node:fs';
import { stat, realpath } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const webRoot = path.join(projectRoot, 'web');
const port = Number(process.env.PORT || 5173);
const host = process.env.HOST || '127.0.0.1';
const types = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.wasm': 'application/wasm',
  '.pck': 'application/octet-stream',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.css': 'text/css; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
};

if (!existsSync(path.join(webRoot, 'index.html'))) {
  console.error('The browser export is missing. Use the complete browser ZIP, or rebuild with Godot (see START_HERE.md).');
  process.exit(1);
}
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error('PORT must be an integer between 1 and 65535.');
  process.exit(1);
}

const canonicalRoot = await realpath(webRoot);
const server = http.createServer(async (request, response) => {
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    response.writeHead(405, { Allow: 'GET, HEAD' }).end();
    return;
  }
  try {
    const url = new URL(request.url, 'http://local.invalid');
    const pathname = decodeURIComponent(url.pathname);
    const requested = path.resolve(webRoot, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (requested !== webRoot && !requested.startsWith(webRoot + path.sep)) {
      response.writeHead(403).end('Forbidden');
      return;
    }
    const canonicalFile = await realpath(requested);
    if (!canonicalFile.startsWith(canonicalRoot + path.sep)) {
      response.writeHead(403).end('Forbidden');
      return;
    }
    const info = await stat(canonicalFile);
    if (!info.isFile()) {
      response.writeHead(404).end('Not found');
      return;
    }
    response.writeHead(200, {
      'Content-Type': types[path.extname(canonicalFile)] || 'application/octet-stream',
      'Content-Length': info.size,
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
      'Cross-Origin-Opener-Policy': 'same-origin',
      'Cross-Origin-Embedder-Policy': 'require-corp',
    });
    if (request.method === 'HEAD') response.end();
    else createReadStream(canonicalFile).on('error', () => response.destroy()).pipe(response);
  } catch (error) {
    response.writeHead(error instanceof URIError ? 400 : 404).end('Not found');
  }
});
server.on('error', error => {
  if (error.code === 'EADDRINUSE') {
    console.error(`Port ${port} is already in use. Stop the other server or set PORT to another number.`);
  } else console.error(error.message);
  process.exitCode = 1;
});
server.listen(port, host, () => {
  console.log('\nBlock Busters browser test');
  console.log(`Open http://${host === '0.0.0.0' ? 'localhost' : host}:${port} in your browser.`);
  console.log('No npm install or Godot installation is needed to play this export.');
  console.log('Keep this terminal open. Press Ctrl+C to stop.\n');
});
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
