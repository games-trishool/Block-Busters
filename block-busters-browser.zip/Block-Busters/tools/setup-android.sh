#!/usr/bin/env bash
set -euo pipefail

# Everything is retained outside the checkout. No root access is needed.
TOOLS_DIR="${BLOCK_BUSTERS_TOOLS_DIR:-/workspace/.block-busters-tools}"
GODOT_VERSION=4.6.3
DOWNLOADS="$TOOLS_DIR/downloads"
mkdir -p "$DOWNLOADS" "$TOOLS_DIR/data/godot/export_templates/$GODOT_VERSION.stable" "$TOOLS_DIR/config/godot" "$TOOLS_DIR/cache" "$TOOLS_DIR/android-sdk" "$TOOLS_DIR/gradle"
# adb uses this standard per-user directory even when ANDROID_USER_HOME is set.
# No private Play signing credentials are stored here by this setup.
mkdir -p "$HOME/.android"

download() {
  local destination="$1" url="$2"
  if [[ ! -s "$destination" ]]; then
    curl --fail --location --retry 2 --output "$destination.part" "$url"
    mv "$destination.part" "$destination"
  fi
}

# SHA-256 from the same official Temurin release, pinned here for repeatability.
if [[ ! -x "$TOOLS_DIR/jdk/bin/javac" ]]; then
  download "$DOWNLOADS/jdk17.tar.gz" 'https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.17%2B10/OpenJDK17U-jdk_x64_linux_hotspot_17.0.17_10.tar.gz'
  printf '%s  %s\n' '992f96e7995075ac7636bb1a8de52b0c61d71ed3137fafc979ab96b4ab78dd75' "$DOWNLOADS/jdk17.tar.gz" | sha256sum --check -
  mkdir -p "$TOOLS_DIR/jdk"
  tar -xzf "$DOWNLOADS/jdk17.tar.gz" --strip-components=1 -C "$TOOLS_DIR/jdk"
fi
export JAVA_HOME="$TOOLS_DIR/jdk"
export ANDROID_HOME="$TOOLS_DIR/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export ANDROID_USER_HOME="$TOOLS_DIR/android-user"
mkdir -p "$ANDROID_USER_HOME"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/cmdline-tools/19.0/bin:$ANDROID_HOME/platform-tools:$PATH"
export XDG_DATA_HOME="$TOOLS_DIR/data"
export XDG_CONFIG_HOME="$TOOLS_DIR/config"
export XDG_CACHE_HOME="$TOOLS_DIR/cache"
export GRADLE_USER_HOME="$TOOLS_DIR/gradle"

# Java ships its own trust store. Trust the platform's public egress CA, just as
# curl does through the system CA bundle; TLS verification stays enabled.
PLATFORM_CA=/usr/local/share/ca-certificates/environment-proxy-ca.crt
if [[ -f "$PLATFORM_CA" ]]; then
  keytool -delete -cacerts -storepass changeit -alias block-busters-environment-proxy >/dev/null 2>&1 || true
  keytool -importcert -noprompt -cacerts -storepass changeit -alias block-busters-environment-proxy -file "$PLATFORM_CA"
fi

# The Android SDK and Gradle do not automatically use HTTPS_PROXY.
PROXY_ARGS=()
if [[ -n "${HTTPS_PROXY:-}" ]]; then
  read -r PROXY_HOST PROXY_PORT < <(python3 -c 'import os,urllib.parse; p=urllib.parse.urlsplit(os.environ["HTTPS_PROXY"]); print(p.hostname, p.port or 80)')
  PROXY_ARGS=(--proxy=http "--proxy_host=$PROXY_HOST" "--proxy_port=$PROXY_PORT")
  export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:-} -Dhttps.proxyHost=$PROXY_HOST -Dhttps.proxyPort=$PROXY_PORT -Dhttp.proxyHost=$PROXY_HOST -Dhttp.proxyPort=$PROXY_PORT"
fi

if [[ ! -x "$ANDROID_HOME/cmdline-tools/19.0/bin/sdkmanager" ]]; then
  download "$DOWNLOADS/commandlinetools.zip" 'https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip'
  # Published checksum in Google's HTTPS repository2-3.xml, cmdline-tools;19.0.
  printf '%s  %s\n' '5fdcc763663eefb86a5b8879697aa6088b041e70' "$DOWNLOADS/commandlinetools.zip" | sha1sum --check -
  mkdir -p "$ANDROID_HOME/cmdline-tools"
  unzip -q "$DOWNLOADS/commandlinetools.zip" -d "$ANDROID_HOME/cmdline-tools"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/19.0"
fi

if [[ ! -x "$ANDROID_HOME/build-tools/36.1.0/apksigner" || ! -f "$ANDROID_HOME/platforms/android-36/android.jar" || ! -x "$ANDROID_HOME/platform-tools/adb" ]]; then
  # License acceptance is required for the requested Android development workflow.
  # A finite input file preserves sdkmanager's actual exit status without SIGPIPE.
  python3 -c 'print("y\n" * 100)' > "$TOOLS_DIR/android-license-answers.txt"
  sdkmanager "${PROXY_ARGS[@]}" --sdk_root="$ANDROID_HOME" --licenses < "$TOOLS_DIR/android-license-answers.txt"
  sdkmanager "${PROXY_ARGS[@]}" --sdk_root="$ANDROID_HOME" 'platform-tools' 'build-tools;36.1.0' 'platforms;android-36'
fi

TEMPLATES="$XDG_DATA_HOME/godot/export_templates/$GODOT_VERSION.stable"
if [[ ! -f "$TEMPLATES/android_source.zip" ]]; then
  ARCHIVE="Godot_v$GODOT_VERSION-stable_export_templates.tpz"
  download "$DOWNLOADS/$ARCHIVE" "https://github.com/godotengine/godot-builds/releases/download/$GODOT_VERSION-stable/$ARCHIVE"
  # From the release's official SHA512-SUMS.txt.
  printf '%s  %s\n' 'da606b61c10157844f8300172df374472665f95015495cb1a7cd132c40ede404faa96cc1016a4b9662db9909ddea69632c4948b2cd11163438dad4808881fb68' "$DOWNLOADS/$ARCHIVE" | sha512sum --check -
  unzip -j -o -q "$DOWNLOADS/$ARCHIVE" 'templates/android_*' 'templates/linux_*x86_64' 'templates/web_*' 'templates/version.txt' -d "$TEMPLATES"
fi

if [[ ! -f "$TOOLS_DIR/debug.keystore" ]]; then
  keytool -genkeypair -noprompt -keystore "$TOOLS_DIR/debug.keystore" -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Android Debug,O=Android,C=US'
fi

cat > "$TOOLS_DIR/config/godot/editor_settings-4.6.tres" <<EOF
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/java_sdk_path = "$JAVA_HOME"
export/android/android_sdk_path = "$ANDROID_HOME"
export/android/debug_keystore = "$TOOLS_DIR/debug.keystore"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
EOF

cat > "$TOOLS_DIR/env.sh" <<EOF
export BLOCK_BUSTERS_TOOLS_DIR="$TOOLS_DIR"
export JAVA_HOME="$JAVA_HOME"
export ANDROID_HOME="$ANDROID_HOME"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export ANDROID_USER_HOME="$ANDROID_USER_HOME"
export XDG_DATA_HOME="$XDG_DATA_HOME"
export XDG_CONFIG_HOME="$XDG_CONFIG_HOME"
export XDG_CACHE_HOME="$XDG_CACHE_HOME"
export GRADLE_USER_HOME="$GRADLE_USER_HOME"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/cmdline-tools/19.0/bin:$ANDROID_HOME/platform-tools:\$PATH"
export GODOT_ANDROID_KEYSTORE_DEBUG_PATH="$TOOLS_DIR/debug.keystore"
export GODOT_ANDROID_KEYSTORE_DEBUG_USER=androiddebugkey
export GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD=android
EOF
if [[ -n "${PROXY_HOST:-}" ]]; then
  printf 'export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:-} -Dhttps.proxyHost=%s -Dhttps.proxyPort=%s -Dhttp.proxyHost=%s -Dhttp.proxyPort=%s"\n' "$PROXY_HOST" "$PROXY_PORT" "$PROXY_HOST" "$PROXY_PORT" >> "$TOOLS_DIR/env.sh"
fi

printf 'Android tooling installed. Source %s/env.sh before direct Godot export commands.\n' "$TOOLS_DIR"
java -version
godot --version
