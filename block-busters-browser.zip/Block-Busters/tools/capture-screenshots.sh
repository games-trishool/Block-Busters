#!/usr/bin/env bash
# Render the actual game through Godot/OpenGL. No display or capture data is retained in Git.
set -euo pipefail

repo_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
tools_dir="${BLOCK_BUSTERS_TOOLS_DIR:-/workspace/.block-busters-tools}"
capture_dir="${1:-$repo_dir/artifacts/screenshots}"
capture_size="${CAPTURE_SIZE:-480x900}"
display_dir="$tools_dir/display"
mkdir -p "$display_dir" "$capture_dir" "$tools_dir/visual-cache" "$tools_dir/visual-userdata" "$tools_dir/visual-config"
mkdir -p "$repo_dir/artifacts"
touch "$repo_dir/artifacts/.gdignore"
capture_dir="$(cd -- "$capture_dir" && pwd)"
display_pid=""
cleanup() {
  if [[ -n "$display_pid" ]]; then
    kill "$display_pid" 2>/dev/null || true
    wait "$display_pid" 2>/dev/null || true
  fi
}
trap cleanup EXIT

if [[ -z "${DISPLAY:-}" ]] || ! xdpyinfo -display "$DISPLAY" >/dev/null 2>&1; then
  if [[ ! -x /usr/lib/xorg/Xorg ]]; then
    printf '%s\n' 'A working X11 display or Xorg with its dummy driver is required.' >&2
    exit 1
  fi
  cat > "$display_dir/xorg.conf" <<'XORG'
Section "ServerFlags"
 Option "AutoAddDevices" "false"
 Option "AutoAddGPU" "false"
 Option "DontVTSwitch" "true"
 Option "AllowMouseOpenFail" "true"
EndSection
Section "Device"
 Identifier "DummyDevice"
 Driver "dummy"
 VideoRam 256000
EndSection
Section "Monitor"
 Identifier "DummyMonitor"
 HorizSync 5.0 - 1000.0
 VertRefresh 5.0 - 200.0
 Modeline "1920x1080" 148.50 1920 2008 2052 2200 1080 1084 1089 1125 +HSync +VSync
EndSection
Section "Screen"
 Identifier "DummyScreen"
 Device "DummyDevice"
 Monitor "DummyMonitor"
 DefaultDepth 24
 SubSection "Display"
  Depth 24
  Modes "1920x1080"
 EndSubSection
EndSection
XORG
  for display_number in $(seq 99 119); do
    if ! xdpyinfo -display ":$display_number" >/dev/null 2>&1; then
      export DISPLAY=":$display_number"
      break
    fi
  done
  /usr/lib/xorg/Xorg "$DISPLAY" -config "$display_dir/xorg.conf" \
    -logfile "$display_dir/capture-xorg.log" -nolisten tcp -noreset \
    -novtswitch -sharevts > "$display_dir/capture-display.log" 2>&1 &
  display_pid="$!"
  for _ in $(seq 1 50); do
    if xdpyinfo -display "$DISPLAY" >/dev/null 2>&1; then break; fi
    if ! kill -0 "$display_pid" 2>/dev/null; then
      cat "$display_dir/capture-display.log" >&2
      exit 1
    fi
    sleep 0.1
  done
  xdpyinfo -display "$DISPLAY" >/dev/null
fi

export LIBGL_ALWAYS_SOFTWARE=1
export XDG_CACHE_HOME="$tools_dir/visual-cache"
export XDG_DATA_HOME="$tools_dir/visual-userdata"
export XDG_CONFIG_HOME="$tools_dir/visual-config"
godot --headless --path "$repo_dir" --editor --import > "$display_dir/capture-import.log" 2>&1
for screen in home game settings help over; do
  target="$capture_dir/$screen.png"
  rm -f -- "$target"
  timeout "${CAPTURE_TIMEOUT_SECONDS:-45}s" godot --path "$repo_dir" --audio-driver Dummy --rendering-method gl_compatibility \
    --resolution "$capture_size" -- --capture="$screen" --capture-path="$target" \
    > "$display_dir/capture-$screen.log" 2>&1 || {
      capture_status="$?"
      cat "$display_dir/capture-$screen.log" >&2
      exit "$capture_status"
    }
  if [[ ! -s "$target" ]]; then
    cat "$display_dir/capture-$screen.log" >&2
    printf 'Missing screenshot: %s\n' "$target" >&2
    exit 1
  fi
  printf 'Captured %s\n' "$target"
done
