# Block Busters — Google Play listing draft

This is release preparation material. The app has not been uploaded, reviewed, or approved by Google Play. Review the copy against the final build and device testing before submission.

## Store copy

**App name** (13/30 characters):

Block Busters

**Short description** (78/80 characters):

An endless neon brick breaker. Drag, bounce and chase your best score offline.

**Full description**:

One paddle. Endless possibilities.

Block Busters is a fast, colorful brick breaker made for your phone. Slide your paddle, keep the ball in play and turn a wall of neon bricks into your next best score.

THE RUN KEEPS GOING

Break through changing brick patterns in one endless run. There is no level list to finish: fresh patterns keep the challenge moving, with difficulty that grows to a fixed cap. Lose your last life, take a breath and try again.

MADE FOR TOUCH

Drag to position your paddle and tap to launch. Clear controls and a portrait playfield make it easy to jump into a quick session.

CHASE YOUR OWN BEST

Build combos and beat your personal record. Your best score and preferences stay on your device.

PLAY ON YOUR TERMS

• Offline, single-player play
• Endless, changing brick patterns
• Touch paddle controls
• Local best score
• Optional sound and vibration
• Pause and resume during a run
• No ads, accounts or in-app purchases

No server connection or daily check-in is needed. Just launch, bounce and keep the run alive.

## Graphic files

| Purpose | File | Dimensions |
| --- | --- | --- |
| Google Play app icon | `assets/store-icon.png` | 512 × 512 |
| Google Play feature graphic | `assets/store-feature.png` | 1024 × 500 |
| High-resolution source icon | `assets/icon.png` | 1024 × 1024 |
| Editable vector sources | `assets/icon.svg`, `assets/store-feature.svg` | SVG |

The graphics are original geometric artwork. The feature graphic is promotional artwork; capture screenshots from the actual app for the phone screenshot section. Do not present concept art as an in-game screenshot.

## Developer information to supply

- Confirm the public developer name; the current artwork uses **Trishool Games**.
- Supply a monitored developer support email address in Play Console. Do not leave a placeholder in the public listing.
- Publish the completed privacy policy from `docs/PRIVACY.md` at a publicly accessible HTTPS URL, add the developer contact, and enter that URL in Play Console. Keep the URL accessible after release.
- Confirm the application ID before the first upload. The planned default is `com.trishoolgames.blockbusters`; the package ID cannot be changed for an already published app.

## Play Console submission checklist

- Build a release Android App Bundle with a private upload key. Use Play App Signing, and back up the upload key/passwords outside the repository. The debug APK is for testing, not a Play release artifact.
- Confirm the bundle meets the current target Android API and native-library requirements shown by Play Console. A successful local build does not establish store acceptance.
- Install the release-equivalent build on real Android devices. Check touch movement, edge swipes, screen cutouts, pause/background/resume, sound/vibration toggles, best-score persistence, and an extended endless run.
- Upload real phone screenshots showing both the home screen and active gameplay. Confirm small-screen readability.
- Complete the content rating, target audience, app access, ads, and data safety forms. For the current offline build, no app data is collected or shared, no account is required, and there are no ads. Reassess these answers if SDKs or online features are added.
- Select the intended audience and answer the rating questions accurately. An arcade theme alone does not determine a store rating or a Families policy declaration.
- Complete any identity verification, closed testing, and production access steps required for the developer account.
- Review the store copy and privacy policy, then submit a signed bundle through an internal or closed testing track before production.

## Operation after release

The game uses local play and local storage, so it needs no game server, live event schedule, or daily operational monitoring. Keep the developer contact and privacy policy valid. Plan occasional maintenance when Android compatibility, a confirmed bug, or a Play policy change requires an update; offline operation does not remove those store obligations.
