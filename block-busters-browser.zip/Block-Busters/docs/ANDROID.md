# Android builds

Block Busters is a portrait, offline Godot 4.6.3 game. Android package ID:
`com.trishoolgames.blockbusters`; version `1.0.0`, version code `1`.
The release App Bundle targets Android 16 / API 36, supports Android 7 / API 24
and later, and includes the 64-bit ARM architecture. The only requested Android permission is the normal `VIBRATE` permission for
optional haptic feedback. No network, advertising, account, storage, or analytics
permission is required.

## Prepare the cloud workspace

From `/workspace/Block-Busters`:

```sh
bash tools/setup-android.sh
```

The repeatable setup stores JDK 17, Android SDK, official Godot export templates,
a test-only debug keystore, and caches under `/workspace/.block-busters-tools`.
It requires `curl`, `unzip`, `tar`, Python 3, and the Godot 4.6.3 editor already
installed by this cloud image. No global package changes or root access are needed.
It also creates Android's standard `~/.android` directory so adb can initialize.
Downloads use HTTPS and the published artifact checksums. Java trusts the public
cloud proxy CA supplied in the machine's system trust configuration. Certificate
and artifact verification stay enabled.

The script accepts the Android SDK package licenses needed for Android builds.
If preparing your own machine, review Google's terms before running it.
Google's SDK manager verifies the downloaded SDK packages itself. The large
Godot download is verified against the release's SHA-512 manifest; the JDK uses
its release's SHA-256; Google's command-line tools use the SHA-1 published in
Google's repository manifest.

To use the tools directly:

```sh
source /workspace/.block-busters-tools/env.sh
```

This activates the JDK/SDK paths, writable Godot/cache directories, and supported
proxy routing. It never contains your Play upload key or password.

## Installable test APK

```sh
bash tools/build-android.sh debug
```

Output: `artifacts/block-busters-debug.apk`. The script verifies the APK signature.
This uses the public Android debug key and is for testing, not Play Store upload.
Both the APK and Play release profile target API 36.

With USB debugging enabled on a connected phone:

```sh
source /workspace/.block-busters-tools/env.sh
adb install -r artifacts/block-busters-debug.apk
```

The package is ARM64. Most physical Android phones support this architecture.
For an x86_64 emulator, enable that architecture in the export profile first.

## Unsigned Play release bundle

```sh
bash tools/build-android.sh unsigned
```

Output: `artifacts/block-busters-unsigned.aab`. This verifies that the release
Gradle pipeline works. It cannot be uploaded to Play until it is signed with
your own upload key. Gradle's generated project is retained in ignored `android/`.

## Signed bundle for Play

Keep your private upload keystore outside the repository and back it up securely.
Use your existing upload key if the application has already been registered.
For a new application, create a key on your own trusted machine with Android
Studio or `keytool -genkeypair`, then use a secure local file or secret mount.
Never send the password or keystore in chat or commit either to Git.

Set these variables securely in your build environment:

- `GODOT_ANDROID_KEYSTORE_RELEASE_PATH`: absolute path to your upload keystore.
- `GODOT_ANDROID_KEYSTORE_RELEASE_USER`: its key alias.
- `GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD`: key/store password; Godot requires them to match.

Then run:

```sh
bash tools/build-android.sh release
```

Output: `artifacts/block-busters-release.aab`. The script verifies the resulting
bundle's JAR signature. Test through Play Console's internal testing track before
production. Review `docs/STORE_LISTING.md` for the listing and publication checklist.
Upload signing credentials are not required for normal development or APK testing.
They have deliberately not been generated or embedded in this project.

Before the first Play upload, confirm that the package ID belongs to you. It
becomes permanent for that Play application. Increase `version/code` in every
Android export profile for each later upload, and keep version names consistent.
Check Play Console's current target API requirements when submitting; they change
over time. No Play account access or production publication was performed here.

## Useful checks

```sh
godot --headless --editor --path . --import
bash tools/build-android.sh debug
bash tools/build-android.sh unsigned
```

Also run the gameplay smoke suite documented in the repository README. On a
physical phone, check touch input, tall/narrow screen layouts, Android Back,
suspend/resume, audio, and persistence after force-closing the game. Desktop
or headless validation cannot establish physical-device behavior.
