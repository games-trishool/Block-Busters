# Block Busters Privacy Policy

Effective date: 23 October 2026

**Before publishing:** replace the developer contact placeholder below with a real support email address, confirm the public developer name, and host this policy at a public HTTPS URL. This draft is for the offline build described here.

## About the game

Block Busters is an offline, single-player brick-breaking game developed by Trishool Games. It does not require an account, a server connection, or a sign-in.

## Information collected or shared

The game does not collect, transmit, sell, or share personal information. It does not include advertising, analytics, tracking, social sign-in, cloud leaderboards, or in-app purchases. It does not use cookies or advertising identifiers.

## Information stored on your device

The game saves local gameplay records, such as your best score, and preferences, such as sound and vibration settings, in the app's private storage. These records are used only to provide the game on your device and are not sent to the developer.

You can remove the game's local records by clearing its app storage in Android settings or uninstalling it. Android's own device backup or device transfer features, if enabled and supported on your device, are governed by your device and Google settings rather than a developer-operated service.

## Device features

The game can play audio and provide optional vibration feedback. It does not record audio, use the camera, read contacts, or request your location. Sound and vibration can be switched off in the game.

## Children

The game does not knowingly collect personal information from children or other players. There are no accounts, chat, advertising, or purchases in this build. The game's published age rating and target audience are provided separately in its store listing.

## Platform services

Google Play and Android may process information independently to provide their own services, such as app distribution, security, device backups, and platform crash reporting. Their handling of that information is governed by their respective policies and your platform settings. The developer does not add an in-game data collection service.

## Changes to this policy

If a future update introduces online features or changes the game's data practices, the developer will update this policy and applicable store disclosures before releasing those features. The effective date above identifies the current policy.

## Contact

Developer: Trishool Games

Support email: **[REPLACE WITH YOUR DEVELOPER SUPPORT EMAIL BEFORE PUBLICATION]**
