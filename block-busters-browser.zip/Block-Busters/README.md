# Block Busters

A portrait, **endless offline Android brick breaker**, built with Godot 4.6.3.
Drag the paddle, tap to launch, chain brick hits, and chase a locally saved best
score. New targets appear continuously. Difficulty and brick durability have
fixed caps; there is no level list, backend, live event schedule, login, ad SDK,
analytics, or in-app purchase.

## Quick browser test from VS Code

The downloadable browser ZIP includes the ready-built `web/` export. Extract it,
open the folder containing `package.json` in VS Code, and run **`npm start`** in
its terminal. Open the address printed by the terminal. Node.js 18+ is required;
there are no npm packages to install, and Godot/Android tools are not needed to
play. See [START_HERE.md](START_HERE.md) for the full steps and rebuilding source
changes. The browser version uses the same game code as Android.

## Play and develop

Use the existing checkout at `/workspace/Block-Busters`. Each cloud task is
already isolated; another Git worktree is unnecessary.

```sh
cd /workspace/Block-Busters
bash tools/setup-android.sh
source /workspace/.block-busters-tools/env.sh
godot --editor --path .
```

Press F6/F5 in Godot or run `godot --path .` in a graphical session. On a phone,
drag anywhere in the playfield to position the paddle; tap to launch. On a
desktop, use the mouse, or arrows/A/D and Space. Escape/P pauses; the Android
Back button pauses or navigates back. Leaving the app pauses an active run.

There are three lives per run. Consecutive brick destructions before a paddle
bounce earn increasing bonuses, capped at 70 points per brick. Armored bricks
need extra hits. Ball speed caps at 660 logical pixels/second. New targets
fill vacant cells without spawning on the ball or descending onto the paddle.
The run has no completion state.

High score, run count, and sound/vibration settings stay in app-private local
storage (`user://progress.cfg`). The active run stays in memory across pause;
it does **not** survive force-stop, process termination, or a device restart.
Uninstalling clears local data; Android automatic backup is disabled.

## Validate

```sh
bash tools/test.sh
bash tools/capture-screenshots.sh
```

The headless suites check swept collisions, paddle steering, armor, combos,
endless refills, difficulty caps, exact life loss, transformed touch input,
emulated input, a simulated two-minute run, local saves, settings, and lifecycle
navigation. The screenshot helper uses a real OpenGL renderer with the cloud
image's virtual X11 display; it captures actual screens under
`artifacts/screenshots/`. For a taller screen:

```sh
CAPTURE_SIZE=480x1040 bash tools/capture-screenshots.sh artifacts/screenshots-tall
```

On a phone, test cutouts, touch, haptics, background/resume, force-stop persistence,
and an extended run before publishing. Desktop and headless checks do not replace
physical Android testing.

## Android artifacts

```sh
bash tools/build-android.sh debug      # installable, test-signed APK
bash tools/build-android.sh unsigned   # unsigned release Android App Bundle
```

Outputs are `artifacts/block-busters-debug.apk` and
`artifacts/block-busters-unsigned.aab`. Build products and credentials are
excluded from Git. The SDK, JDK, templates, caches, and test key are retained
outside the repository under `/workspace/.block-busters-tools`.

The Play release uses package ID `com.trishoolgames.blockbusters`, version 1.0.0,
version code 1, ARM64, min API 24, and target API 36. Confirm the application ID
before your first upload. Follow [Android builds](docs/ANDROID.md) to provide
your own upload key securely and build a signed release bundle. Do not publish
the debug APK or an unsigned bundle.

## Prepare the Play Store release

Original app icons, adaptive icon layers, and the 1024×500 Play feature graphic
are in `assets/`. The store listing and release checklist are in
[STORE_LISTING.md](docs/STORE_LISTING.md). Complete the developer contact in
[PRIVACY.md](docs/PRIVACY.md), publish that policy at a public HTTPS URL, and
complete Play Console's account, rating, data safety, and testing requirements.
Capture the final signed build on real phones for the store screenshots.

The app does not require a game server or ongoing content production. Occasional
Android compatibility or store policy updates may still be needed.

## Project map

| File | Responsibility |
| --- | --- |
| `scripts/gameplay.gd` | Endless targets, swept ball physics, input, particles, scoring |
| `scripts/main.gd` | Menus, HUD, local best, lifecycle, privacy and license screens |
| `scripts/save_store.gd` | Atomic local progress/settings persistence |
| `scripts/audio.gd` | Original synthesized sound effects |
| `tools/` | Repeatable setup, checks, screenshots, Android packaging |
| `tests/` | Headless gameplay and app integration checks |

Godot and its third-party library notices are accessible inside the app at
**Settings → Privacy & credits → Engine licenses**. Artwork and sound in this
repository are original; no third-party commercial asset pack is required.
DejaVu Sans supplies missing symbol glyphs in web exports; its license is
included under `assets/fonts/` and in the in-game license credits.
