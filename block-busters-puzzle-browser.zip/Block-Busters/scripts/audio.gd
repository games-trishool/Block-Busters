class_name ArcadeAudio
extends Node
## Original synthesized effects; no downloaded audio or music.

var enabled: bool = true
var _effects: Dictionary = {}
var _voices: Array[AudioStreamPlayer] = []
var _voice: int = 0

func _ready() -> void:
	for i in range(6):
		var player := AudioStreamPlayer.new()
		player.volume_db = -14.0
		add_child(player)
		_voices.append(player)
	_effects["place"] = _tone(510.0, 0.075, 1.15)
	_effects["clear"] = _tone(760.0, 0.18, 1.8)
	_effects["select"] = _tone(600.0, 0.035)
	_effects["invalid"] = _tone(170.0, 0.07, 0.8)
	_effects["game_over"] = _tone(180.0, 0.4, 0.35)
	_effects["combo"] = _tone(880.0, 0.12, 1.25)
	_effects["click"] = _tone(740.0, 0.04)

func play(kind: String) -> void:
	if not enabled or _voices.is_empty():
		return
	var effect: AudioStreamWAV = _effects.get(kind, _effects["place"])
	var player := _voices[_voice]
	_voice = (_voice + 1) % _voices.size()
	player.stream = effect
	player.play()

func _tone(frequency: float, length: float, slide: float = 1.0) -> AudioStreamWAV:
	var rate := 22050
	var count := int(length * rate)
	var samples := PackedByteArray()
	samples.resize(count * 2)
	var phase := 0.0
	for i in range(count):
		var t := float(i) / count
		phase += TAU * lerpf(frequency, frequency * slide, t) / rate
		var envelope := minf(t * 25.0, 1.0) * pow(1.0 - t, 2.0)
		var value := int((sin(phase) + sin(phase * 2.0) * 0.12) * envelope * 16000.0)
		samples.encode_s16(i * 2, value)
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.data = samples
	return stream
