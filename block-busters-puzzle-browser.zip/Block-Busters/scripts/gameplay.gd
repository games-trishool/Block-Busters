class_name BlockPuzzle
extends Node2D
## Endless offline block placement: use all three pieces, clear rows/columns, repeat.

signal score_changed(score: int)
signal combo_changed(combo: int)
signal lines_changed(lines: int)
signal pieces_changed()
signal selection_changed(slot: int)
signal state_changed(state: String)
signal run_finished(score: int)
signal feedback(kind: String)

const GRID_SIZE := 8
const CELL_SIZE := 54.0
const BOARD_ORIGIN := Vector2(24.0, 194.0)
const BOARD_RECT := Rect2(BOARD_ORIGIN, Vector2(432.0, 432.0))
const TRAY_CENTERS := [Vector2(86, 750), Vector2(240, 750), Vector2(394, 750)]
const TRAY_CELL := 27.0
const TOUCH_LIFT := 88.0
const PALETTE: Array[Color] = [Color("00dc4c"), Color("ff6048"), Color("3388ff"), Color("ffcb46"), Color("c343f2"), Color("21d4f2"), Color("ff762e")]
const MAX_PARTICLES := 128
const MAX_STYLE_CACHE := 512
const POP_DURATION := 0.18
const ATLAS_CELL := 96
const SHAPES := [
	[Vector2i(0, 0)],
	[Vector2i(0, 0), Vector2i(1, 0)],
	[Vector2i(0, 0), Vector2i(0, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0)],
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(0, 2)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(1, 1)],
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(1, 1)],
	[Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(3, 0)],
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(0, 2), Vector2i(0, 3)],
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(0, 2), Vector2i(1, 2)],
	[Vector2i(1, 0), Vector2i(1, 1), Vector2i(0, 2), Vector2i(1, 2)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(1, 1)],
	[Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1)],
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(0, 2)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(1, 1), Vector2i(2, 1)],
	[Vector2i(1, 0), Vector2i(2, 0), Vector2i(0, 1), Vector2i(1, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(0, 2), Vector2i(1, 2)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1), Vector2i(0, 2), Vector2i(1, 2), Vector2i(2, 2)]
]

var sound_enabled := true
var haptics_enabled := true
var score := 0
var combo := 0
var lines_cleared := 0
var moves := 0
var board: Array[int] = []
var pieces: Array[Dictionary] = []
var selected_slot := -1
var _state := "menu"
var _rng := RandomNumberGenerator.new()
var _time := 0.0
var _bag: Array[int] = []
var _particles: Array[Dictionary] = []
var _flashes: Array[Dictionary] = []
var _beams: Array[Dictionary] = []
var _cell_pops: Dictionary = {}
var _style_cache: Dictionary = {}
var _style_cache_hits := 0
var _style_cache_misses := 0
var _redraw_count := 0
var _tile_atlas: ImageTexture
var _atlas_builds := 0
var _pointer_active := false
var _pointer_touch := false
var _touch_id := -1
var _dragging := false
var _from_tray := false
var _press_position := Vector2.ZERO
var _pointer_position := Vector2.ZERO
var _ghost_cell := Vector2i(-100, -100)
var _ghost_visible := false

func _ready() -> void:
	_rng.randomize()
	_build_tile_atlas()
	board.resize(GRID_SIZE * GRID_SIZE)
	board.fill(0)
	set_process(false)

func start_run() -> void:
	score = 0
	combo = 0
	lines_cleared = 0
	moves = 0
	_bag.clear()
	_particles.clear()
	_flashes.clear()
	_beams.clear()
	_cell_pops.clear()
	set_process(false)
	_cancel_pointer()
	selected_slot = -1
	load_demo_board()
	pieces.assign([
		_make_piece(SHAPES[12], 2),
		_make_piece(SHAPES[14], 1),
		_make_piece(SHAPES[3], 3)
	])
	_set_state("playing")
	score_changed.emit(score)
	combo_changed.emit(combo)
	lines_changed.emit(lines_cleared)
	pieces_changed.emit()
	selection_changed.emit(selected_slot)
	queue_redraw()

func restart_run() -> void:
	start_run()

func load_demo_board() -> void:
	board.resize(GRID_SIZE * GRID_SIZE)
	board.fill(0)
	for cell in [Vector2i(3, 0), Vector2i(4, 0), Vector2i(4, 1), Vector2i(4, 2)]:
		board[_index(cell)] = 2
	for cell in [Vector2i(0, 5), Vector2i(0, 6), Vector2i(1, 6), Vector2i(0, 7), Vector2i(1, 7), Vector2i(2, 7)]:
		board[_index(cell)] = 1
	for cell in [Vector2i(5, 6), Vector2i(6, 6), Vector2i(7, 6), Vector2i(6, 7), Vector2i(7, 7)]:
		board[_index(cell)] = 3
	queue_redraw()

func reset_to_menu() -> void:
	_cancel_pointer()
	selected_slot = -1
	_set_state("menu")
	board.fill(0)
	pieces.clear()
	_particles.clear()
	_flashes.clear()
	_beams.clear()
	_cell_pops.clear()
	set_process(false)
	queue_redraw()

func get_state() -> String:
	return _state

func get_board() -> Array[int]:
	return board.duplicate()

func set_paused(paused: bool) -> void:
	if paused and _state == "playing":
		_cancel_pointer()
		_set_state("paused")
	elif not paused and _state == "paused":
		_set_state("playing")

func _set_state(value: String) -> void:
	if _state != value:
		_state = value
		set_process(value != "paused" and value != "menu" and _has_effects())
		state_changed.emit(_state)
		queue_redraw()

func _index(cell: Vector2i) -> int:
	return cell.y * GRID_SIZE + cell.x

func get_cell(position: Vector2) -> Vector2i:
	return Vector2i(floori((position.x - BOARD_ORIGIN.x) / CELL_SIZE), floori((position.y - BOARD_ORIGIN.y) / CELL_SIZE))

func get_piece_cells(slot: int) -> Array:
	if slot < 0 or slot >= pieces.size():
		return []
	return pieces[slot]["cells"].duplicate()

func _make_piece(cells: Array, color_index: int) -> Dictionary:
	var shape: Array[Vector2i] = []
	for cell in cells:
		shape.append(Vector2i(cell))
	return {"cells": shape, "color_index": color_index, "used": false}

func _shape_fits(cells: Array, anchor: Vector2i) -> bool:
	if cells.is_empty() or board.size() != GRID_SIZE * GRID_SIZE:
		return false
	for offset in cells:
		var cell: Vector2i = anchor + Vector2i(offset)
		if cell.x < 0 or cell.y < 0 or cell.x >= GRID_SIZE or cell.y >= GRID_SIZE:
			return false
		if board[_index(cell)] != 0:
			return false
	return true

func can_place(slot: int, cell: Vector2i) -> bool:
	if slot < 0 or slot >= pieces.size() or bool(pieces[slot].get("used", false)):
		return false
	return _shape_fits(pieces[slot]["cells"], cell)

func select_piece(slot: int) -> bool:
	if _state != "playing" or slot < 0 or slot >= pieces.size() or bool(pieces[slot].get("used", false)):
		return false
	selected_slot = slot
	_ghost_visible = false
	selection_changed.emit(selected_slot)
	feedback.emit("select")
	queue_redraw()
	return true

func place_piece(slot: int, cell: Vector2i) -> bool:
	if _state != "playing" or not can_place(slot, cell):
		if _state == "playing":
			feedback.emit("invalid")
		return false
	var piece := pieces[slot]
	for offset in piece["cells"]:
		var position: Vector2i = cell + Vector2i(offset)
		board[_index(position)] = int(piece["color_index"])
		_cell_pops[_index(position)] = POP_DURATION
	piece["used"] = true
	moves += 1
	set_process(true)
	score += piece["cells"].size() * 10
	var cleared := _clear_lines()
	if cleared > 0:
		combo += 1
		lines_cleared += cleared
		score += 100 * cleared * combo
		feedback.emit("clear")
		if haptics_enabled and OS.has_feature("android"):
			Input.vibrate_handheld(35)
	else:
		combo = 0
		feedback.emit("place")
	selected_slot = -1
	_cancel_pointer()
	combo_changed.emit(combo)
	lines_changed.emit(lines_cleared)
	score_changed.emit(score)
	selection_changed.emit(selected_slot)
	var all_used := true
	for candidate in pieces:
		if not bool(candidate["used"]):
			all_used = false
			break
	if all_used:
		_deal_hand()
	pieces_changed.emit()
	_check_game_over()
	queue_redraw()
	return true

func _clear_lines() -> int:
	var rows: Array[int] = []
	var columns: Array[int] = []
	for y in range(GRID_SIZE):
		var full := true
		for x in range(GRID_SIZE):
			if board[y * GRID_SIZE + x] == 0:
				full = false
				break
		if full:
			rows.append(y)
	for x in range(GRID_SIZE):
		var full := true
		for y in range(GRID_SIZE):
			if board[y * GRID_SIZE + x] == 0:
				full = false
				break
		if full:
			columns.append(x)
	for y in rows:
		_beams.append({"axis": 0, "line": y, "life": 0.42})
	for x in columns:
		_beams.append({"axis": 1, "line": x, "life": 0.42})
	while _beams.size() > 16:
		_beams.pop_front()
	var indices: Dictionary = {}
	for y in rows:
		for x in range(GRID_SIZE):
			indices[y * GRID_SIZE + x] = true
	for x in columns:
		for y in range(GRID_SIZE):
			indices[y * GRID_SIZE + x] = true
	for index in indices:
		var color := _color_for(board[index])
		var cell := Vector2i(int(index) % GRID_SIZE, int(index) / GRID_SIZE)
		var center := BOARD_ORIGIN + (Vector2(cell) + Vector2(0.5, 0.5)) * CELL_SIZE
		_flashes.append({"position": center, "color": color, "life": 0.42})
		_cell_pops.erase(index)
		_emit_particles(center, color, 6)
		board[index] = 0
	while _flashes.size() > GRID_SIZE * GRID_SIZE:
		_flashes.pop_front()
	if not indices.is_empty():
		set_process(true)
	return rows.size() + columns.size()

func has_any_move() -> bool:
	for slot in range(pieces.size()):
		if bool(pieces[slot].get("used", false)):
			continue
		for y in range(GRID_SIZE):
			for x in range(GRID_SIZE):
				if can_place(slot, Vector2i(x, y)):
					return true
	return false

func _check_game_over() -> void:
	if _state == "playing" and not has_any_move():
		_cancel_pointer()
		_set_state("game_over")
		feedback.emit("game_over")
		run_finished.emit(score)

func _deal_hand() -> void:
	pieces.clear()
	for slot in range(3):
		var shape_index := _next_shape()
		pieces.append(_make_piece(SHAPES[shape_index], _rng.randi_range(1, PALETTE.size())))
	# Avoid a freshly dealt hand that is already impossible. Remaining pieces can
	# still become blocked through player choices, which is the natural end of a run.
	if not has_any_move():
		for shape in SHAPES:
			var found := false
			for y in range(GRID_SIZE):
				for x in range(GRID_SIZE):
					if _shape_fits(shape, Vector2i(x, y)):
						pieces[0] = _make_piece(shape, _rng.randi_range(1, PALETTE.size()))
						found = true
						break
				if found:
					break
			if found:
				break

func _next_shape() -> int:
	if _bag.is_empty():
		for index in range(SHAPES.size()):
			_bag.append(index)
		# Fisher-Yates uses the per-run generator rather than global random state.
		for index in range(_bag.size() - 1, 0, -1):
			var other := _rng.randi_range(0, index)
			var temporary := _bag[index]
			_bag[index] = _bag[other]
			_bag[other] = temporary
	return _bag.pop_back()

func _piece_size(slot: int) -> Vector2:
	var size := Vector2.ONE
	if slot >= 0 and slot < pieces.size():
		for cell in pieces[slot]["cells"]:
			size.x = maxf(size.x, float(cell.x + 1))
			size.y = maxf(size.y, float(cell.y + 1))
	return size

func _slot_at(position: Vector2) -> int:
	for slot in range(3):
		if Rect2(TRAY_CENTERS[slot] - Vector2(66, 62), Vector2(132, 132)).has_point(position):
			return slot
	return -1

func _cancel_pointer() -> void:
	_pointer_active = false
	_dragging = false
	_from_tray = false
	_touch_id = -1
	_ghost_visible = false

func _pointer_down(position: Vector2, is_touch: bool) -> bool:
	var slot := _slot_at(position)
	if slot >= 0:
		if not select_piece(slot):
			return false
		_pointer_active = true
		_pointer_touch = is_touch
		_from_tray = true
		_dragging = false
		_press_position = position
		_pointer_position = position
		return true
	if BOARD_RECT.has_point(position) and selected_slot >= 0:
		_pointer_active = true
		_pointer_touch = is_touch
		_from_tray = false
		_dragging = false
		_press_position = position
		_pointer_position = position
		_ghost_cell = get_cell(position)
		_ghost_visible = true
		return true
	return false

func _pointer_motion(position: Vector2) -> void:
	var previous_position := _pointer_position
	var previous_cell := _ghost_cell
	var previous_visible := _ghost_visible
	_pointer_position = position
	if _pointer_active:
		if _from_tray and position.distance_to(_press_position) > 10.0:
			_dragging = true
		if _dragging:
			var top_left := position - _piece_size(selected_slot) * CELL_SIZE * 0.5
			if _pointer_touch:
				top_left.y -= TOUCH_LIFT
			_ghost_cell = Vector2i(roundi((top_left.x - BOARD_ORIGIN.x) / CELL_SIZE), roundi((top_left.y - BOARD_ORIGIN.y) / CELL_SIZE))
			_ghost_visible = true
		elif not _from_tray:
			_ghost_cell = get_cell(position)
			_ghost_visible = true
	elif selected_slot >= 0:
		_ghost_visible = BOARD_RECT.has_point(position)
		_ghost_cell = get_cell(position)
	if (_dragging and position != previous_position) or _ghost_cell != previous_cell or _ghost_visible != previous_visible:
		queue_redraw()

func _pointer_up(position: Vector2) -> void:
	if not _pointer_active:
		return
	_pointer_motion(position)
	var slot := selected_slot
	var target := _ghost_cell
	var should_place := _dragging or not _from_tray
	_cancel_pointer()
	if should_place:
		place_piece(slot, target)
	queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if _state != "playing":
		return
	if (event is InputEventMouseMotion or event is InputEventMouseButton) and event.device == -1:
		return
	var inverse := get_global_transform_with_canvas().affine_inverse()
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		var position := inverse * touch.position
		if touch.pressed and _touch_id == -1:
			if _pointer_down(position, true):
				_touch_id = touch.index
				get_viewport().set_input_as_handled()
		elif not touch.pressed and touch.index == _touch_id:
			_pointer_up(position)
			_touch_id = -1
			get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		if drag.index == _touch_id:
			_pointer_motion(inverse * drag.position)
			get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if mouse.button_index == MOUSE_BUTTON_LEFT:
			if mouse.pressed:
				if _pointer_down(inverse * mouse.position, false):
					get_viewport().set_input_as_handled()
			elif _pointer_active:
				_pointer_up(inverse * mouse.position)
				get_viewport().set_input_as_handled()
	elif event is InputEventMouseMotion:
		_pointer_motion(inverse * event.position)

func _has_effects() -> bool:
	return not _particles.is_empty() or not _flashes.is_empty() or not _beams.is_empty() or not _cell_pops.is_empty()

func _process(delta: float) -> void:
	if _state == "paused" or _state == "menu":
		return
	_time += delta
	for index in range(_particles.size() - 1, -1, -1):
		var particle := _particles[index]
		particle["life"] = float(particle["life"]) - delta
		if float(particle["life"]) <= 0.0:
			_particles.remove_at(index)
		else:
			particle["position"] = Vector2(particle["position"]) + Vector2(particle["velocity"]) * delta
			particle["velocity"] = Vector2(particle["velocity"]) * maxf(0.0, 1.0 - delta * 2.4)
	for index in range(_flashes.size() - 1, -1, -1):
		_flashes[index]["life"] = float(_flashes[index]["life"]) - delta
		if float(_flashes[index]["life"]) <= 0.0:
			_flashes.remove_at(index)
	for index in range(_beams.size() - 1, -1, -1):
		_beams[index]["life"] = float(_beams[index]["life"]) - delta
		if float(_beams[index]["life"]) <= 0.0:
			_beams.remove_at(index)
	for index in _cell_pops.keys():
		_cell_pops[index] = float(_cell_pops[index]) - delta
		if float(_cell_pops[index]) <= 0.0:
			_cell_pops.erase(index)
	# Godot retains drawing commands. Idle boards do not need new draw commands,
	# style allocations or per-frame animation processing.
	queue_redraw()
	if not _has_effects():
		set_process(false)

func _emit_particles(position: Vector2, color: Color, amount: int) -> void:
	for index in range(amount):
		_particles.append({"position": position, "velocity": Vector2.from_angle(_rng.randf_range(0.0, TAU)) * _rng.randf_range(35.0, 165.0), "life": _rng.randf_range(0.27, 0.60), "color": color, "size": _rng.randf_range(1.4, 3.2), "spark": index % 3 == 0})
	while _particles.size() > MAX_PARTICLES:
		_particles.pop_front()
	if _state != "menu" and _state != "paused":
		set_process(true)

func _color_for(index: int) -> Color:
	return PALETTE[posmod(index - 1, PALETTE.size())]

func _box(rect: Rect2, color: Color, radius: int, border: Color = Color.TRANSPARENT, width: int = 0, glow: float = 0.0) -> void:
	# Only opacity is animated. Quantizing it keeps this cache finite without
	# changing placement, scoring or pointer precision.
	color.a = snappedf(color.a, 1.0 / 16.0)
	border.a = snappedf(border.a, 1.0 / 16.0)
	glow = snappedf(glow, 1.0 / 16.0)
	if color.a <= 0.0 and border.a <= 0.0:
		return
	var key := "%s:%s:%d:%d:%d" % [color.to_rgba32(), border.to_rgba32(), radius, width, int(glow * 16)]
	var style: StyleBoxFlat = _style_cache.get(key)
	if style == null:
		style = StyleBoxFlat.new()
		style.bg_color = color
		style.set_corner_radius_all(radius)
		style.border_color = border
		style.set_border_width_all(width)
		if glow > 0.0:
			style.shadow_color = Color(border if border.a > 0.0 else color, glow)
			style.shadow_size = 7
		if _style_cache.size() >= MAX_STYLE_CACHE:
			_style_cache.erase(_style_cache.keys()[0])
		_style_cache[key] = style
		_style_cache_misses += 1
	else:
		_style_cache_hits += 1
	draw_style_box(style, rect)

func get_render_stats() -> Dictionary:
	return {"style_cache_entries": _style_cache.size(), "style_cache_hits": _style_cache_hits, "style_cache_misses": _style_cache_misses, "redraws": _redraw_count, "particles": _particles.size(), "flashes": _flashes.size(), "beams": _beams.size(), "active_pops": _cell_pops.size(), "atlas_builds": _atlas_builds, "atlas_cells": PALETTE.size() + 2}

func _build_tile_atlas() -> void:
	if _tile_atlas != null:
		return
	var image := Image.create(ATLAS_CELL * (PALETTE.size() + 2), ATLAS_CELL, false, Image.FORMAT_RGBA8)
	image.fill(Color.TRANSPARENT)
	for slot in range(PALETTE.size() + 2):
		for y in range(ATLAS_CELL):
			for x in range(ATLAS_CELL):
				var color: Color
				if slot < PALETTE.size():
					color = _cube_pixel(float(x) + 0.5, float(y) + 0.5, PALETTE[slot])
				else:
					color = _empty_cell_pixel(float(x) + 0.5, float(y) + 0.5, slot % 2 == 0)
				image.set_pixel(slot * ATLAS_CELL + x, y, color)
	_tile_atlas = ImageTexture.create_from_image(image)
	_atlas_builds += 1

func _rounded_coverage(x: float, y: float, left: float, top: float, right: float, bottom: float, radius: float) -> float:
	# Analytic rounded-box distance supplies a one-pixel antialiased rim when the
	# atlas is built. No blur/shadow shaders or rounded meshes run every frame.
	var qx := absf(x - (left + right) * 0.5) - (right - left) * 0.5 + radius
	var qy := absf(y - (top + bottom) * 0.5) - (bottom - top) * 0.5 + radius
	var distance := sqrt(maxf(qx, 0.0) * maxf(qx, 0.0) + maxf(qy, 0.0) * maxf(qy, 0.0)) + minf(maxf(qx, qy), 0.0) - radius
	return clampf(0.5 - distance, 0.0, 1.0)

func _cube_pixel(x: float, y: float, base: Color) -> Color:
	var shadow := _rounded_coverage(x, y, 2.0, 5.0, 94.0, 95.0, 6.0) * 0.46
	var coverage := _rounded_coverage(x, y, 1.5, 1.5, 94.5, 92.5, 5.0)
	if coverage <= 0.0:
		return Color(0.025, 0.035, 0.08, shadow)
	var left := x - 1.5
	var right := 94.5 - x
	var top := y - 1.5
	var bottom := 92.5 - y
	var edge := minf(minf(left, right), minf(top, bottom))
	var color := base.lerp(Color.WHITE, 0.05 * (1.0 - y / 96.0)).darkened(y / 96.0 * 0.09)
	if edge < 2.0:
		color = base.lightened(0.34) if top <= 2.0 or left <= 2.0 else base.darkened(0.52)
	elif edge < 13.0:
		if top <= left and top <= right and top <= bottom:
			color = base.lightened(0.48 - top / 130.0)
		elif left <= right and left <= bottom:
			color = base.lightened(0.18 - left / 160.0)
		elif right <= bottom:
			color = base.darkened(0.23 + right / 220.0)
		else:
			color = base.darkened(0.38 + bottom / 220.0)
	else:
		# Soft face sheen and a lower falloff make the cube read as enamel rather
		# than a flat UI swatch. It is baked once into the shared texture.
		var gloss := maxf(0.0, 1.0 - absf(y - 26.0) / 22.0) * 0.055
		color = color.lerp(Color.WHITE, gloss)
	if top > 1.0 and top < 3.1 and x > 9.0 and x < 87.0:
		color = base.lerp(Color.WHITE, 0.78)
	color.a = coverage
	return color

func _empty_cell_pixel(x: float, y: float, alternate: bool) -> Color:
	var coverage := _rounded_coverage(x, y, 1.5, 1.5, 94.5, 94.5, 6.0)
	if coverage <= 0.0:
		return Color.TRANSPARENT
	var color := Color("273153") if alternate else Color("252e50")
	color = color.darkened((1.0 - y / 96.0) * 0.045)
	if x < 3.0 or y < 3.0:
		color = color.darkened(0.14)
	elif y > 93.0:
		color = color.lightened(0.035)
	color.a = coverage
	return color

func get_tile_atlas() -> Texture2D:
	if _tile_atlas == null:
		_build_tile_atlas()
	return _tile_atlas

func get_tile_region(color_index: int) -> Rect2:
	return Rect2(posmod(color_index - 1, PALETTE.size()) * ATLAS_CELL, 0, ATLAS_CELL, ATLAS_CELL)

func _tile(rect: Rect2, color: Color, alpha: float = 1.0, _glow: float = 0.18) -> void:
	if _tile_atlas == null:
		_build_tile_atlas()
	var index := maxi(0, PALETTE.find(color))
	draw_texture_rect_region(_tile_atlas, rect, Rect2(index * ATLAS_CELL, 0, ATLAS_CELL, ATLAS_CELL), Color(1, 1, 1, alpha))

func _draw() -> void:
	_redraw_count += 1
	if _state == "menu":
		return
	# Inset navy cells, a cool upper rim and a low contact shadow frame the board.
	_box(Rect2(BOARD_RECT.position + Vector2(-6, 0), BOARD_RECT.size + Vector2(12, 12)), Color(0.035, 0.05, 0.13, 0.28), 14)
	_box(BOARD_RECT.grow(5), Color("151e3c"), 13, Color("738bca"), 2)
	_box(BOARD_RECT.grow(1), Color("192342"), 8)
	for y in range(GRID_SIZE):
		for x in range(GRID_SIZE):
			var cell := Vector2i(x, y)
			var index := _index(cell)
			var rect := Rect2(BOARD_ORIGIN + Vector2(cell) * CELL_SIZE + Vector2(2, 2), Vector2(CELL_SIZE - 4, CELL_SIZE - 4))
			var empty_slot := PALETTE.size() + (x + y) % 2
			draw_texture_rect_region(_tile_atlas, rect, Rect2(empty_slot * ATLAS_CELL, 0, ATLAS_CELL, ATLAS_CELL))
			if board.size() == GRID_SIZE * GRID_SIZE and board[index] > 0:
				if _cell_pops.has(index):
					var progress := float(_cell_pops[index]) / POP_DURATION
					var grow := sin(progress * PI) * 2.5
					rect = rect.grow(grow)
				_tile(rect, _color_for(board[index]))
	if _ghost_visible and selected_slot >= 0 and selected_slot < pieces.size():
		var valid := can_place(selected_slot, _ghost_cell)
		var ghost_color := Color("9bfbd0") if valid else Color("ff6d80")
		for offset in pieces[selected_slot]["cells"]:
			var cell: Vector2i = _ghost_cell + Vector2i(offset)
			if cell.x >= 0 and cell.y >= 0 and cell.x < GRID_SIZE and cell.y < GRID_SIZE:
				var rect := Rect2(BOARD_ORIGIN + Vector2(cell) * CELL_SIZE + Vector2(2, 2), Vector2(CELL_SIZE - 4, CELL_SIZE - 4))
				_box(rect, Color(ghost_color, 0.20), 4, Color(ghost_color, 0.85), 2, 0.0)
	for slot in range(3):
		var center: Vector2 = TRAY_CENTERS[slot]
		var selected := slot == selected_slot
		var border := Color("b2ddff") if selected else Color(0.64, 0.73, 1.0, 0.13)
		_box(Rect2(center - Vector2(65, 61), Vector2(130, 132)), Color(0.17, 0.23, 0.42, 0.34), 15, border, 2 if selected else 1, 0.0)
		if slot >= pieces.size():
			continue
		if bool(pieces[slot]["used"]):
			draw_circle(center, 18, Color(0.44, 0.57, 0.80, 0.08))
			draw_line(center + Vector2(-10, 0), center + Vector2(-3, 7), Color("7c91bf"), 2.5, true)
			draw_line(center + Vector2(-3, 7), center + Vector2(12, -9), Color("7c91bf"), 2.5, true)
			continue
		var cells: Array = pieces[slot]["cells"]
		var origin := center - _piece_size(slot) * TRAY_CELL * 0.5
		var alpha := 0.25 if _dragging and selected else 1.0
		for cell in cells:
			_tile(Rect2(origin + Vector2(cell) * TRAY_CELL + Vector2.ONE, Vector2(TRAY_CELL - 2, TRAY_CELL - 2)), _color_for(int(pieces[slot]["color_index"])), alpha, 0.06)
	if _dragging and selected_slot >= 0:
		var origin := _pointer_position - _piece_size(selected_slot) * CELL_SIZE * 0.5
		if _pointer_touch:
			origin.y -= TOUCH_LIFT
		for cell in pieces[selected_slot]["cells"]:
			_tile(Rect2(origin + Vector2(cell) * CELL_SIZE + Vector2(2, 2), Vector2(CELL_SIZE - 4, CELL_SIZE - 4)), _color_for(int(pieces[selected_slot]["color_index"])), 0.92, 0.3)
	for beam in _beams:
		var strength := clampf(float(beam["life"]) / 0.42, 0, 1)
		var width := 2.0 + strength * 16.0
		var origin := BOARD_ORIGIN + Vector2(0, (float(beam["line"]) + 0.5) * CELL_SIZE) if int(beam["axis"]) == 0 else BOARD_ORIGIN + Vector2((float(beam["line"]) + 0.5) * CELL_SIZE, 0)
		var end := origin + (Vector2(BOARD_RECT.size.x, 0) if int(beam["axis"]) == 0 else Vector2(0, BOARD_RECT.size.y))
		draw_line(origin, end, Color(0.50, 0.83, 1.0, strength * 0.16), width * 2.8, true)
		draw_line(origin, end, Color(0.68, 0.92, 1.0, strength * 0.5), width, true)
		draw_line(origin, end, Color(1, 1, 1, strength * 0.9), 1.0 + strength * 2.0, true)
	for flash in _flashes:
		var strength := clampf(float(flash["life"]) / 0.42, 0, 1)
		var size := CELL_SIZE * (0.85 + (1.0 - strength) * 0.4)
		_box(Rect2(Vector2(flash["position"]) - Vector2.ONE * size * 0.5, Vector2.ONE * size), Color(flash["color"], strength * 0.4), 5, Color(0.85, 0.97, 1, strength * 0.6), 1, strength * 0.2)
	for particle in _particles:
		var color: Color = particle["color"]
		color.a = minf(1.0, float(particle["life"]) * 2.4)
		var position: Vector2 = particle["position"]
		var size := float(particle["size"])
		if bool(particle.get("spark", false)):
			draw_line(position - Vector2(size * 1.8, 0), position + Vector2(size * 1.8, 0), Color(1, 1, 1, color.a * 0.8), 1.1, true)
			draw_line(position - Vector2(0, size * 1.8), position + Vector2(0, size * 1.8), Color(1, 1, 1, color.a * 0.8), 1.1, true)
		else:
			draw_rect(Rect2(position - Vector2.ONE * size, Vector2.ONE * size * 2.0), color)
