class_name BlockPuzzle
extends Node2D
## Endless offline block placement: use all three pieces, clear rows/columns, repeat.

signal score_changed(score: int)
signal combo_changed(combo: int)
signal lines_changed(lines: int)
signal pieces_changed()
signal selection_changed(slot: int)
signal state_changed(state: String)
signal run_finished(score: int)
signal feedback(kind: String)

const GRID_SIZE := 8
const CELL_SIZE := 54.0
const BOARD_ORIGIN := Vector2(24.0, 194.0)
const BOARD_RECT := Rect2(BOARD_ORIGIN, Vector2(432.0, 432.0))
const TRAY_CENTERS := [Vector2(86, 750), Vector2(240, 750), Vector2(394, 750)]
const TRAY_CELL := 27.0
const TOUCH_LIFT := 88.0
const PALETTE: Array[Color] = [Color("59ee4e"), Color("ff514b"), Color("32b9ff"), Color("ffda45"), Color("bd69ff"), Color("3ce5d7"), Color("ff9850")]
const SHAPES := [
	[Vector2i(0, 0)],
	[Vector2i(0, 0), Vector2i(1, 0)],
	[Vector2i(0, 0), Vector2i(0, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0)],
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(0, 2)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(1, 1)],
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(1, 1)],
	[Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(3, 0)],
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(0, 2), Vector2i(0, 3)],
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(0, 2), Vector2i(1, 2)],
	[Vector2i(1, 0), Vector2i(1, 1), Vector2i(0, 2), Vector2i(1, 2)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(1, 1)],
	[Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1)],
	[Vector2i(0, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(0, 2)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(1, 1), Vector2i(2, 1)],
	[Vector2i(1, 0), Vector2i(2, 0), Vector2i(0, 1), Vector2i(1, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(0, 2), Vector2i(1, 2)],
	[Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1), Vector2i(0, 2), Vector2i(1, 2), Vector2i(2, 2)]
]

var sound_enabled := true
var haptics_enabled := true
var score := 0
var combo := 0
var lines_cleared := 0
var moves := 0
var board: Array[int] = []
var pieces: Array[Dictionary] = []
var selected_slot := -1
var _state := "menu"
var _rng := RandomNumberGenerator.new()
var _time := 0.0
var _bag: Array[int] = []
var _particles: Array[Dictionary] = []
var _flashes: Array[Dictionary] = []
var _pointer_active := false
var _pointer_touch := false
var _touch_id := -1
var _dragging := false
var _from_tray := false
var _press_position := Vector2.ZERO
var _pointer_position := Vector2.ZERO
var _ghost_cell := Vector2i(-100, -100)
var _ghost_visible := false

func _ready() -> void:
	_rng.randomize()
	board.resize(GRID_SIZE * GRID_SIZE)
	board.fill(0)

func start_run() -> void:
	score = 0
	combo = 0
	lines_cleared = 0
	moves = 0
	_bag.clear()
	_particles.clear()
	_flashes.clear()
	_cancel_pointer()
	selected_slot = -1
	load_demo_board()
	pieces.assign([
		_make_piece(SHAPES[12], 2),
		_make_piece(SHAPES[14], 1),
		_make_piece(SHAPES[3], 3)
	])
	_set_state("playing")
	score_changed.emit(score)
	combo_changed.emit(combo)
	lines_changed.emit(lines_cleared)
	pieces_changed.emit()
	selection_changed.emit(selected_slot)
	queue_redraw()

func restart_run() -> void:
	start_run()

func load_demo_board() -> void:
	board.resize(GRID_SIZE * GRID_SIZE)
	board.fill(0)
	for cell in [Vector2i(3, 0), Vector2i(4, 0), Vector2i(4, 1), Vector2i(4, 2)]:
		board[_index(cell)] = 2
	for cell in [Vector2i(0, 5), Vector2i(0, 6), Vector2i(1, 6), Vector2i(0, 7), Vector2i(1, 7), Vector2i(2, 7)]:
		board[_index(cell)] = 1
	for cell in [Vector2i(5, 6), Vector2i(6, 6), Vector2i(7, 6), Vector2i(6, 7), Vector2i(7, 7)]:
		board[_index(cell)] = 3
	queue_redraw()

func reset_to_menu() -> void:
	_cancel_pointer()
	selected_slot = -1
	_set_state("menu")
	board.fill(0)
	pieces.clear()
	_particles.clear()
	_flashes.clear()
	queue_redraw()

func get_state() -> String:
	return _state

func get_board() -> Array[int]:
	return board.duplicate()

func set_paused(paused: bool) -> void:
	if paused and _state == "playing":
		_cancel_pointer()
		_set_state("paused")
	elif not paused and _state == "paused":
		_set_state("playing")

func _set_state(value: String) -> void:
	if _state != value:
		_state = value
		state_changed.emit(_state)

func _index(cell: Vector2i) -> int:
	return cell.y * GRID_SIZE + cell.x

func get_cell(position: Vector2) -> Vector2i:
	return Vector2i(floori((position.x - BOARD_ORIGIN.x) / CELL_SIZE), floori((position.y - BOARD_ORIGIN.y) / CELL_SIZE))

func get_piece_cells(slot: int) -> Array:
	if slot < 0 or slot >= pieces.size():
		return []
	return pieces[slot]["cells"].duplicate()

func _make_piece(cells: Array, color_index: int) -> Dictionary:
	var shape: Array[Vector2i] = []
	for cell in cells:
		shape.append(Vector2i(cell))
	return {"cells": shape, "color_index": color_index, "used": false}

func _shape_fits(cells: Array, anchor: Vector2i) -> bool:
	if cells.is_empty() or board.size() != GRID_SIZE * GRID_SIZE:
		return false
	for offset in cells:
		var cell: Vector2i = anchor + Vector2i(offset)
		if cell.x < 0 or cell.y < 0 or cell.x >= GRID_SIZE or cell.y >= GRID_SIZE:
			return false
		if board[_index(cell)] != 0:
			return false
	return true

func can_place(slot: int, cell: Vector2i) -> bool:
	if slot < 0 or slot >= pieces.size() or bool(pieces[slot].get("used", false)):
		return false
	return _shape_fits(pieces[slot]["cells"], cell)

func select_piece(slot: int) -> bool:
	if _state != "playing" or slot < 0 or slot >= pieces.size() or bool(pieces[slot].get("used", false)):
		return false
	selected_slot = slot
	_ghost_visible = false
	selection_changed.emit(selected_slot)
	feedback.emit("select")
	queue_redraw()
	return true

func place_piece(slot: int, cell: Vector2i) -> bool:
	if _state != "playing" or not can_place(slot, cell):
		if _state == "playing":
			feedback.emit("invalid")
		return false
	var piece := pieces[slot]
	for offset in piece["cells"]:
		var position: Vector2i = cell + Vector2i(offset)
		board[_index(position)] = int(piece["color_index"])
	piece["used"] = true
	moves += 1
	score += piece["cells"].size() * 10
	var cleared := _clear_lines()
	if cleared > 0:
		combo += 1
		lines_cleared += cleared
		score += 100 * cleared * combo
		feedback.emit("clear")
		if haptics_enabled and OS.has_feature("android"):
			Input.vibrate_handheld(35)
	else:
		combo = 0
		feedback.emit("place")
	selected_slot = -1
	_cancel_pointer()
	combo_changed.emit(combo)
	lines_changed.emit(lines_cleared)
	score_changed.emit(score)
	selection_changed.emit(selected_slot)
	var all_used := true
	for candidate in pieces:
		if not bool(candidate["used"]):
			all_used = false
			break
	if all_used:
		_deal_hand()
	pieces_changed.emit()
	_check_game_over()
	queue_redraw()
	return true

func _clear_lines() -> int:
	var rows: Array[int] = []
	var columns: Array[int] = []
	for y in range(GRID_SIZE):
		var full := true
		for x in range(GRID_SIZE):
			if board[y * GRID_SIZE + x] == 0:
				full = false
				break
		if full:
			rows.append(y)
	for x in range(GRID_SIZE):
		var full := true
		for y in range(GRID_SIZE):
			if board[y * GRID_SIZE + x] == 0:
				full = false
				break
		if full:
			columns.append(x)
	var indices: Dictionary = {}
	for y in rows:
		for x in range(GRID_SIZE):
			indices[y * GRID_SIZE + x] = true
	for x in columns:
		for y in range(GRID_SIZE):
			indices[y * GRID_SIZE + x] = true
	for index in indices:
		var color := _color_for(board[index])
		var cell := Vector2i(int(index) % GRID_SIZE, int(index) / GRID_SIZE)
		var center := BOARD_ORIGIN + (Vector2(cell) + Vector2(0.5, 0.5)) * CELL_SIZE
		_flashes.append({"position": center, "color": color, "life": 0.42})
		_emit_particles(center, color, 6)
		board[index] = 0
	return rows.size() + columns.size()

func has_any_move() -> bool:
	for slot in range(pieces.size()):
		if bool(pieces[slot].get("used", false)):
			continue
		for y in range(GRID_SIZE):
			for x in range(GRID_SIZE):
				if can_place(slot, Vector2i(x, y)):
					return true
	return false

func _check_game_over() -> void:
	if _state == "playing" and not has_any_move():
		_cancel_pointer()
		_set_state("game_over")
		feedback.emit("game_over")
		run_finished.emit(score)

func _deal_hand() -> void:
	pieces.clear()
	for slot in range(3):
		var shape_index := _next_shape()
		pieces.append(_make_piece(SHAPES[shape_index], _rng.randi_range(1, PALETTE.size())))
	# Avoid a freshly dealt hand that is already impossible. Remaining pieces can
	# still become blocked through player choices, which is the natural end of a run.
	if not has_any_move():
		for shape in SHAPES:
			var found := false
			for y in range(GRID_SIZE):
				for x in range(GRID_SIZE):
					if _shape_fits(shape, Vector2i(x, y)):
						pieces[0] = _make_piece(shape, _rng.randi_range(1, PALETTE.size()))
						found = true
						break
				if found:
					break
			if found:
				break

func _next_shape() -> int:
	if _bag.is_empty():
		for index in range(SHAPES.size()):
			_bag.append(index)
		# Fisher-Yates uses the per-run generator rather than global random state.
		for index in range(_bag.size() - 1, 0, -1):
			var other := _rng.randi_range(0, index)
			var temporary := _bag[index]
			_bag[index] = _bag[other]
			_bag[other] = temporary
	return _bag.pop_back()

func _piece_size(slot: int) -> Vector2:
	var size := Vector2.ONE
	if slot >= 0 and slot < pieces.size():
		for cell in pieces[slot]["cells"]:
			size.x = maxf(size.x, float(cell.x + 1))
			size.y = maxf(size.y, float(cell.y + 1))
	return size

func _slot_at(position: Vector2) -> int:
	for slot in range(3):
		if Rect2(TRAY_CENTERS[slot] - Vector2(66, 62), Vector2(132, 132)).has_point(position):
			return slot
	return -1

func _cancel_pointer() -> void:
	_pointer_active = false
	_dragging = false
	_from_tray = false
	_touch_id = -1
	_ghost_visible = false

func _pointer_down(position: Vector2, is_touch: bool) -> bool:
	var slot := _slot_at(position)
	if slot >= 0:
		if not select_piece(slot):
			return false
		_pointer_active = true
		_pointer_touch = is_touch
		_from_tray = true
		_dragging = false
		_press_position = position
		_pointer_position = position
		return true
	if BOARD_RECT.has_point(position) and selected_slot >= 0:
		_pointer_active = true
		_pointer_touch = is_touch
		_from_tray = false
		_dragging = false
		_press_position = position
		_pointer_position = position
		_ghost_cell = get_cell(position)
		_ghost_visible = true
		return true
	return false

func _pointer_motion(position: Vector2) -> void:
	_pointer_position = position
	if _pointer_active:
		if _from_tray and position.distance_to(_press_position) > 10.0:
			_dragging = true
		if _dragging:
			var top_left := position - _piece_size(selected_slot) * CELL_SIZE * 0.5
			if _pointer_touch:
				top_left.y -= TOUCH_LIFT
			_ghost_cell = Vector2i(roundi((top_left.x - BOARD_ORIGIN.x) / CELL_SIZE), roundi((top_left.y - BOARD_ORIGIN.y) / CELL_SIZE))
			_ghost_visible = true
		elif not _from_tray:
			_ghost_cell = get_cell(position)
			_ghost_visible = true
	elif selected_slot >= 0:
		_ghost_visible = BOARD_RECT.has_point(position)
		_ghost_cell = get_cell(position)
	queue_redraw()

func _pointer_up(position: Vector2) -> void:
	if not _pointer_active:
		return
	_pointer_motion(position)
	var slot := selected_slot
	var target := _ghost_cell
	var should_place := _dragging or not _from_tray
	_cancel_pointer()
	if should_place:
		place_piece(slot, target)
	queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if _state != "playing":
		return
	if (event is InputEventMouseMotion or event is InputEventMouseButton) and event.device == -1:
		return
	var inverse := get_global_transform_with_canvas().affine_inverse()
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		var position := inverse * touch.position
		if touch.pressed and _touch_id == -1:
			if _pointer_down(position, true):
				_touch_id = touch.index
				get_viewport().set_input_as_handled()
		elif not touch.pressed and touch.index == _touch_id:
			_pointer_up(position)
			_touch_id = -1
			get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		if drag.index == _touch_id:
			_pointer_motion(inverse * drag.position)
			get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if mouse.button_index == MOUSE_BUTTON_LEFT:
			if mouse.pressed:
				if _pointer_down(inverse * mouse.position, false):
					get_viewport().set_input_as_handled()
			elif _pointer_active:
				_pointer_up(inverse * mouse.position)
				get_viewport().set_input_as_handled()
	elif event is InputEventMouseMotion:
		_pointer_motion(inverse * event.position)

func _process(delta: float) -> void:
	if _state == "paused" or _state == "menu":
		return
	_time += delta
	for index in range(_particles.size() - 1, -1, -1):
		var particle := _particles[index]
		particle["life"] = float(particle["life"]) - delta
		if float(particle["life"]) <= 0.0:
			_particles.remove_at(index)
		else:
			particle["position"] = Vector2(particle["position"]) + Vector2(particle["velocity"]) * delta
			particle["velocity"] = Vector2(particle["velocity"]) * maxf(0.0, 1.0 - delta * 2.0)
	for index in range(_flashes.size() - 1, -1, -1):
		_flashes[index]["life"] = float(_flashes[index]["life"]) - delta
		if float(_flashes[index]["life"]) <= 0.0:
			_flashes.remove_at(index)
	queue_redraw()

func _emit_particles(position: Vector2, color: Color, amount: int) -> void:
	for index in range(amount):
		_particles.append({"position": position, "velocity": Vector2.from_angle(_rng.randf_range(0.0, TAU)) * _rng.randf_range(30.0, 150.0), "life": _rng.randf_range(0.3, 0.65), "color": color, "size": _rng.randf_range(1.5, 4.0)})
	while _particles.size() > 180:
		_particles.pop_front()

func _color_for(index: int) -> Color:
	return PALETTE[posmod(index - 1, PALETTE.size())]

func _box(rect: Rect2, color: Color, radius: int, border: Color = Color.TRANSPARENT, width: int = 0, glow: float = 0.0) -> void:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(radius)
	style.border_color = border
	style.set_border_width_all(width)
	if glow > 0.0:
		style.shadow_color = Color(border if border.a > 0.0 else color, glow)
		style.shadow_size = 8
	draw_style_box(style, rect)

func _tile(rect: Rect2, color: Color, alpha: float = 1.0, glow: float = 0.18) -> void:
	var outer := color.darkened(0.52)
	outer.a = alpha
	var rim := color.lightened(0.12)
	rim.a = alpha
	_box(rect, outer, 6, rim, 1, glow * alpha)
	var inner := rect.grow(-2)
	var face := color.darkened(0.05)
	face.a = alpha
	_box(inner, face, 5)
	var top := color.lightened(0.43)
	top.a = alpha * 0.9
	var bottom := color.darkened(0.30)
	bottom.a = alpha * 0.8
	var inset := 7.0 * rect.size.x / 50.0
	var tl := inner.position
	var tr := inner.position + Vector2(inner.size.x, 0)
	var br := inner.end
	var bl := inner.position + Vector2(0, inner.size.y)
	draw_colored_polygon(PackedVector2Array([tl, tr, tr + Vector2(-inset, inset), tl + Vector2(inset, inset)]), top)
	draw_colored_polygon(PackedVector2Array([bl, br, br + Vector2(-inset, -inset), bl + Vector2(inset, -inset)]), bottom)
	var left := color.lightened(0.15)
	left.a = alpha * 0.55
	draw_colored_polygon(PackedVector2Array([tl, bl, bl + Vector2(inset, -inset), tl + Vector2(inset, inset)]), left)
	var right := color.darkened(0.15)
	right.a = alpha * 0.75
	draw_colored_polygon(PackedVector2Array([tr, br, br + Vector2(-inset, -inset), tr + Vector2(-inset, inset)]), right)
	draw_line(tl + Vector2(5, 1), tr + Vector2(-5, 1), Color(1, 1, 1, alpha * 0.7), 1.3, true)
	var shine := Color(1, 1, 1, alpha * 0.10)
	draw_line(tl + Vector2(inset + 2, inset + 2), tl + Vector2(inner.size.x - inset - 2, inset + 2), shine, 1.0, true)

func _draw() -> void:
	if _state == "menu":
		return
	_box(BOARD_RECT.grow(5), Color("170a2b"), 13, Color("a44fff"), 2, 0.22)
	for y in range(GRID_SIZE):
		for x in range(GRID_SIZE):
			var cell := Vector2i(x, y)
			var rect := Rect2(BOARD_ORIGIN + Vector2(cell) * CELL_SIZE + Vector2(2, 2), Vector2(CELL_SIZE - 4, CELL_SIZE - 4))
			var background := Color("321748") if (x + y) % 2 == 0 else Color("29123e")
			_box(rect, background, 5, Color("522568"), 1)
			if board.size() == GRID_SIZE * GRID_SIZE and board[_index(cell)] > 0:
				_tile(rect, _color_for(board[_index(cell)]))
	# A faint grid separates the larger four-by-four quadrants.
	draw_line(BOARD_ORIGIN + Vector2(216, 0), BOARD_ORIGIN + Vector2(216, 432), Color(0.75, 0.42, 1.0, 0.13), 1)
	draw_line(BOARD_ORIGIN + Vector2(0, 216), BOARD_ORIGIN + Vector2(432, 216), Color(0.75, 0.42, 1.0, 0.13), 1)
	if _ghost_visible and selected_slot >= 0 and selected_slot < pieces.size():
		var valid := can_place(selected_slot, _ghost_cell)
		var ghost_color := _color_for(int(pieces[selected_slot]["color_index"])) if valid else Color("ff526b")
		for offset in pieces[selected_slot]["cells"]:
			var cell: Vector2i = _ghost_cell + Vector2i(offset)
			if cell.x >= 0 and cell.y >= 0 and cell.x < GRID_SIZE and cell.y < GRID_SIZE:
				var rect := Rect2(BOARD_ORIGIN + Vector2(cell) * CELL_SIZE + Vector2(2, 2), Vector2(CELL_SIZE - 4, CELL_SIZE - 4))
				_box(rect, Color(ghost_color, 0.3), 5, Color(ghost_color, 0.95), 2, 0.15)
	for slot in range(3):
		var center: Vector2 = TRAY_CENTERS[slot]
		var selected := slot == selected_slot
		var border := Color("bb72ff") if selected else Color("51316c")
		_box(Rect2(center - Vector2(65, 61), Vector2(130, 132)), Color("211036"), 14, border, 2 if selected else 1, 0.16 if selected else 0.0)
		if slot >= pieces.size():
			continue
		if bool(pieces[slot]["used"]):
			draw_line(center + Vector2(-12, 0), center + Vector2(-3, 9), Color("664979"), 3, true)
			draw_line(center + Vector2(-3, 9), center + Vector2(15, -10), Color("664979"), 3, true)
			continue
		var cells: Array = pieces[slot]["cells"]
		var origin := center - _piece_size(slot) * TRAY_CELL * 0.5
		var alpha := 0.25 if _dragging and selected else 1.0
		for cell in cells:
			_tile(Rect2(origin + Vector2(cell) * TRAY_CELL + Vector2.ONE, Vector2(TRAY_CELL - 2, TRAY_CELL - 2)), _color_for(int(pieces[slot]["color_index"])), alpha, 0.12)
	if _dragging and selected_slot >= 0:
		var origin := _pointer_position - _piece_size(selected_slot) * CELL_SIZE * 0.5
		if _pointer_touch:
			origin.y -= TOUCH_LIFT
		for cell in pieces[selected_slot]["cells"]:
			_tile(Rect2(origin + Vector2(cell) * CELL_SIZE + Vector2(2, 2), Vector2(CELL_SIZE - 4, CELL_SIZE - 4)), _color_for(int(pieces[selected_slot]["color_index"])), 0.92, 0.3)
	for flash in _flashes:
		var strength := float(flash["life"]) / 0.42
		var size := CELL_SIZE * (1.0 + (1.0 - strength) * 0.35)
		_box(Rect2(Vector2(flash["position"]) - Vector2.ONE * size * 0.5, Vector2.ONE * size), Color(flash["color"], strength * 0.55), 7, Color.WHITE * Color(1, 1, 1, strength * 0.5), 1, strength * 0.3)
	for particle in _particles:
		var color: Color = particle["color"]
		color.a = minf(1.0, float(particle["life"]) * 2.0)
		draw_circle(particle["position"], float(particle["size"]), color)
