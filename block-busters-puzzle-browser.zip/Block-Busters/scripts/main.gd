extends Node2D
## Presentation and lifecycle for the endless neon block-placement puzzle.

const BG := Color("34487f")
const PANEL := Color("27365f")
const MINT := Color("b5ff79")
const INK := Color("f1f6fc")
const MUTED := Color("b9c8ee")
const PURPLE := Color("a9c1ff")
const PEACH := Color("ffbf65")
const SaveStore = preload("res://scripts/save_store.gd")
const SoundBank = preload("res://scripts/audio.gd")
const GameEngine = preload("res://scripts/gameplay.gd")
const SYMBOL_FONT = preload("res://assets/fonts/DejaVuSans.ttf")
const TITLE_FONT = preload("res://assets/fonts/DejaVuSans-Bold.ttf")

var progress = SaveStore.new()
var game: Node2D
var sounds: Node
var screen := "home"
var return_screen := "home"
var ui: Control
var hud: Control
var score_label: Label
var best_label: Label
var lines_label: Label
var combo_label: Label
var hint_label: Label
var _time := 0.0
var _save_timer := -1.0
var _run_best_before := 0
var _capture_screen := ""
var _capture_path := ""
var _captured := false
var _capture_frames := 0
var _background_texture: GradientTexture2D
var _draw_styles: Dictionary = {}
var _last_viewport := Vector2.ZERO
var _progress_display := 0.0
var _progress_target := 0.0
var _milestone_goal := 150
var milestone_label: Label
var _score_pop := 0.0
var _hero_materials: Dictionary = {}

func _ready() -> void:
	# Web exports cannot fall back to fonts installed on the player's device.
	# Keep the original UI face and supply arrows/pause/life glyphs explicitly.
	ThemeDB.fallback_font.fallbacks = [SYMBOL_FONT]
	Engine.max_fps = 60
	_background_texture = GradientTexture2D.new()
	var gradient := Gradient.new()
	gradient.set_color(0, Color("4b63a3"))
	gradient.set_color(1, Color("263968"))
	gradient.add_point(0.48, Color("3e548e"))
	_background_texture.gradient = gradient
	_background_texture.width = 4
	_background_texture.height = 512
	_background_texture.fill_from = Vector2(0, 0)
	_background_texture.fill_to = Vector2(0, 1)
	get_tree().auto_accept_quit = false
	progress.load_data()
	sounds = SoundBank.new()
	add_child(sounds)
	sounds.enabled = progress.sound_enabled
	game = GameEngine.new()
	add_child(game)
	game.score_changed.connect(_on_score)
	game.lines_changed.connect(_on_lines)
	game.combo_changed.connect(_on_combo)
	game.state_changed.connect(_on_state)
	game.run_finished.connect(_on_finished)
	game.feedback.connect(_on_feedback)
	game.sound_enabled = progress.sound_enabled
	game.haptics_enabled = progress.haptics_enabled
	ui = Control.new()
	ui.size = Vector2(480, 900)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(ui)
	hud = Control.new()
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.size = Vector2(480, 900)
	add_child(hud)
	_show_home()
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--capture="):
			_capture_screen = argument.trim_prefix("--capture=")
		if argument.begins_with("--capture-path="):
			_capture_path = argument.trim_prefix("--capture-path=")
	if not _capture_screen.is_empty():
		_prepare_capture.call_deferred()

func _process(delta: float) -> void:
	_time += delta
	var viewport := get_viewport_rect().size
	position = (viewport - Vector2(480, 900)) * 0.5
	if viewport != _last_viewport:
		_last_viewport = viewport
		queue_redraw()
	if _save_timer >= 0.0:
		_save_timer -= delta
		if _save_timer <= 0.0:
			_save_progress()
	if screen == "home":
		queue_redraw()
	elif screen == "game" and absf(_progress_display - _progress_target) > 0.001:
		_progress_display = move_toward(_progress_display, _progress_target, delta * 1.6)
		queue_redraw()
	if _score_pop > 0.0:
		_score_pop = maxf(0.0, _score_pop - delta)
		if is_instance_valid(score_label):
			var amount := sin(_score_pop / 0.24 * PI) * 0.065
			score_label.scale = Vector2.ONE * (1.0 + amount)
	if not _capture_screen.is_empty() and not _captured:
		_capture_frames += 1
		if _capture_frames == 45:
			_capture.call_deferred()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if is_instance_valid(game) and screen == "game":
			_pause()
		if is_instance_valid(progress):
			_save_progress()
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_go_back()
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_save_progress()
		get_tree().quit()

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE or event.keycode == KEY_P:
			_go_back()
			get_viewport().set_input_as_handled()

func _go_back() -> void:
	match screen:
		"game": _pause()
		"pause": _resume()
		"settings", "help", "privacy", "licenses": _return_from_panel()
		"over": _show_home()
		"home":
			_save_progress()
			get_tree().quit()

func _draw() -> void:
	var visible := Rect2(-position, get_viewport_rect().size)
	if _background_texture:
		draw_texture_rect(_background_texture, visible, false)
	else:
		draw_rect(visible, BG)
	if screen == "home":
		_draw_hero()
	elif screen == "game":
		_rounded_draw(Rect2(30, 178, 420, 8), Color("22315d"), 4)
		if _progress_display > 0.001:
			_rounded_draw(Rect2(30, 178, maxf(8.0, 420 * _progress_display), 8), Color("ffe295"), 4)
			draw_circle(Vector2(30 + 420 * _progress_display, 182), 5, Color("ffe295"))

func _draw_hero() -> void:
	var origin := Vector2(94, 345)
	var cell_size := 36.0
	for i in range(4, 0, -1):
		_rounded_draw(Rect2(origin - Vector2(14 + i * 3, 10 + i * 3), Vector2(316 + i * 6, 205 + i * 6)), Color(0.07, 0.13, 0.3, 0.035), 20)
	_rounded_draw(Rect2(origin - Vector2(14, 10), Vector2(316, 205)), Color("27365d"), 18)
	_rounded_draw(Rect2(origin - Vector2(9, 5), Vector2(306, 195)), Color("1e2c50"), 14)
	for y in range(5):
		for x in range(8):
			var rect := Rect2(origin + Vector2(x, y) * cell_size + Vector2(1, 1), Vector2(33, 33))
			_rounded_draw(rect, Color("263459") if (x+y)%2 == 0 else Color("29385e"), 4)
			var color := Color.TRANSPARENT
			if y >= 3 and x <= 2: color = Color("00df55")
			if (y == 2 and x >= 5) or (y >= 3 and x >= 6): color = Color("3197ff")
			if y == 4 and x >= 3 and x <= 5: color = Color("ff8b3d")
			if color.a > 0.0: _hero_tile(rect, color)
	# A hovering shape gives the home screen a quiet, lightweight rhythm.
	var hover := sin(_time * 1.5) * 3
	for cell in [Vector2i(3,0), Vector2i(4,0), Vector2i(4,1)]:
		_hero_tile(Rect2(origin + Vector2(cell) * cell_size + Vector2(1, hover), Vector2(33,33)), Color("d651ff"))
	var pulse := 0.5 + sin(_time * 1.4) * 0.12
	draw_line(origin + Vector2(-10, 165), origin + Vector2(300,165), Color(0.7,1.0,0.9,pulse * 0.22), 13, true)
	draw_line(origin + Vector2(-10,165), origin + Vector2(300,165), Color(0.7,1.0,0.9,pulse * 0.65), 2, true)
	_draw_spark(Vector2(407, 367), 7 + sin(_time * 1.6), Color("d9e9ff"))
	_draw_spark(Vector2(72, 484), 5, Color("b5ff79"))
	_draw_spark(Vector2(389, 526), 4, Color("ffe295"))

func _hero_tile(rect: Rect2, color: Color) -> void:
	if is_instance_valid(game) and game.has_method("get_tile_atlas"):
		var atlas: Texture2D = game.get_tile_atlas()
		if atlas:
			var key := color.to_rgba32()
			if not _hero_materials.has(key):
				var closest := 1
				var minimum := INF
				for index in range(GameEngine.PALETTE.size()):
					var candidate: Color = GameEngine.PALETTE[index]
					var distance := Vector3(color.r-candidate.r, color.g-candidate.g, color.b-candidate.b).length_squared()
					if distance < minimum:
						minimum = distance
						closest = index + 1
				_hero_materials[key] = closest
			draw_texture_rect_region(atlas, rect, game.get_tile_region(int(_hero_materials[key])))
			return
	_rounded_draw(rect, color.darkened(0.4), 5)
	_rounded_draw(rect.grow(-2), color, 3)

func _draw_spark(center: Vector2, radius: float, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(8):
		var angle := float(i) * TAU / 8.0
		points.append(center + Vector2(cos(angle), sin(angle)) * (radius if i % 2 == 0 else radius * 0.25))
	draw_colored_polygon(points, color)

func _rounded_draw(rect: Rect2, color: Color, radius: int) -> void:
	var key := str(color.to_rgba32()) + ":" + str(radius)
	if not _draw_styles.has(key):
		var box := StyleBoxFlat.new()
		box.bg_color = color
		box.set_corner_radius_all(radius)
		_draw_styles[key] = box
	draw_style_box(_draw_styles[key], rect)

func _clear_ui(clear_hud: bool = true) -> void:
	for child in ui.get_children():
		ui.remove_child(child)
		child.queue_free()
	if clear_hud:
		for child in hud.get_children():
			hud.remove_child(child)
			child.queue_free()
	ui.move_to_front()
	queue_redraw()

func _label(text: String, rect: Rect2, size: int, color: Color = INK, centered: bool = false, parent: Control = null, bold: bool = false) -> Label:
	var label := Label.new()
	label.text = text
	if bold:
		label.add_theme_font_override("font", TITLE_FONT)
	label.position = rect.position
	label.size = rect.size
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	if bold and size >= 40:
		label.add_theme_color_override("font_shadow_color", Color(0.08, 0.14, 0.3, 0.45))
		label.add_theme_constant_override("shadow_offset_y", 3)
		label.add_theme_constant_override("shadow_offset_x", 0)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	if centered:
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	(parent if parent else ui).add_child(label)
	return label

func _style(color: Color, border: Color = Color.TRANSPARENT, radius: int = 16) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(1 if border.a > 0.0 else 0)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 18
	style.content_margin_right = 18
	return style

func _panel(rect: Rect2, color: Color = PANEL, parent: Control = null) -> Panel:
	var panel := Panel.new()
	panel.position = rect.position
	panel.size = rect.size
	panel.add_theme_stylebox_override("panel", _style(color, Color("687fb2")))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	(parent if parent else ui).add_child(panel)
	return panel

func _button(text: String, rect: Rect2, action: Callable, primary: bool = false, parent: Control = null) -> Button:
	var button := Button.new()
	button.text = text
	button.position = rect.position
	button.size = rect.size
	button.add_theme_font_size_override("font_size", 17)
	button.add_theme_font_override("font", TITLE_FONT)
	button.add_theme_color_override("font_color", BG if primary else INK)
	button.add_theme_color_override("font_hover_color", BG if primary else MINT)
	button.add_theme_color_override("font_pressed_color", BG if primary else MINT)
	button.add_theme_stylebox_override("normal", _style(MINT if primary else PANEL, Color.TRANSPARENT if primary else Color("687fb2")))
	button.add_theme_stylebox_override("hover", _style(Color("d2ffa9") if primary else Color("334b7c"), MINT if not primary else Color.TRANSPARENT))
	button.add_theme_stylebox_override("pressed", _style(Color("95dc5a") if primary else Color("1e2d53")))
	button.add_theme_stylebox_override("focus", _style(Color(0, 0, 0, 0), PURPLE))
	button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	button.pressed.connect(func():
		sounds.play("click")
		action.call_deferred()
	)
	(parent if parent else ui).add_child(button)
	return button

func _brand() -> void:
	_panel(Rect2(28, 28, 36, 36), Color("b5ff79"))
	_label("B", Rect2(28, 27, 36, 36), 23, Color("213952"), true, null, true)
	_label("TRISHOOL GAMES", Rect2(76, 28, 275, 36), 12, Color("d4dff6"), false, null, true)

func _footer(text: String = "OFFLINE  /  NO ADS  /  JUST PLAY") -> void:
	_label(text, Rect2(24, 847, 432, 24), 11, MUTED, true)

func _show_home() -> void:
	screen = "home"
	game.reset_to_menu()
	game.visible = false
	_clear_ui()
	_brand()
	_button("≡", Rect2(390, 22, 64, 64), func(): _show_settings("home"))
	_label("YOUR NEXT GREAT ESCAPE", Rect2(30, 113, 420, 24), 11, Color("d1dcf6"), false, null, true)
	_label("BLOCK", Rect2(25, 144, 430, 77), 68, INK, false, null, true)
	_label("BUSTERS", Rect2(25, 211, 430, 77), 68, INK, false, null, true)
	_label("Make space. Make your best.", Rect2(30, 295, 420, 30), 18, Color("d6e2ff"))
	_panel(Rect2(28, 562, 424, 82), Color("2a3b68"))
	_label("PERSONAL BEST", Rect2(48, 575, 245, 21), 10, Color("b9c8ee"), false, null, true)
	_label(_format_score(progress.best_score), Rect2(47, 597, 300, 35), 28, INK, false, null, true)
	_label("∞", Rect2(365, 569, 59, 61), 43, Color("ffe295"), true)
	_button("PLAY ENDLESS    →", Rect2(28, 668, 424, 72), _start_run, true)
	_button("How to play", Rect2(28, 754, 424, 56), func(): _show_help("home"))
	_footer("OFFLINE. UNWIND. ONE MORE RUN.")
	queue_redraw()

func _start_run() -> void:
	_run_best_before = progress.best_score
	_progress_display = 0.0
	_progress_target = 0.0
	progress.runs += 1
	screen = "game"
	game.visible = true
	_clear_ui()
	_build_hud()
	game.start_run()
	queue_redraw()
	_save_progress()

func _build_hud() -> void:
	_label("BLOCK BUSTERS", Rect2(28, 23, 325, 32), 22, INK, false, hud, true)
	_label("THE ENDLESS PUZZLE", Rect2(29, 54, 310, 21), 9, Color("d0dcf7"), false, hud, true)
	_button("Ⅱ", Rect2(390, 24, 64, 64), _pause, false, hud)
	_label("SCORE", Rect2(28, 88, 200, 17), 10, MUTED, false, hud, true)
	score_label = _label("0", Rect2(25, 104, 250, 43), 35, INK, false, hud, true)
	score_label.pivot_offset = Vector2(0, 22)
	_label("PERSONAL BEST", Rect2(285, 88, 170, 17), 9, MUTED, false, hud, true)
	best_label = _label(_format_score(progress.best_score), Rect2(283, 109, 170, 34), 25, Color("ffe295"), false, hud, true)
	lines_label = _label("0 LINES CLEARED", Rect2(29, 152, 155, 22), 10, Color("d2e1ff"), false, hud, true)
	combo_label = _label("", Rect2(176, 150, 150, 25), 12, MINT, true, hud, true)
	milestone_label = _label("NEXT  150", Rect2(331, 152, 123, 22), 10, Color("ffe295"), false, hud, true)
	hint_label = _label("MAKE ROOM FOR SOMETHING GOOD", Rect2(24, 642, 432, 26), 10, Color("d3dff7"), true, hud)
	_label("YOUR NEXT BLOCKS", Rect2(24, 667, 432, 20), 9, Color("d3dff7"), true, hud, true)
	_label("DRAG TO FIT  ·  FILL A ROW OR COLUMN TO BLAST", Rect2(24, 846, 432, 25), 9, Color("c8d8f7"), true, hud)

func _pause() -> void:
	if screen != "game":
		return
	game.set_paused(true)
	screen = "pause"
	game.visible = false
	_save_progress()
	_clear_ui()
	_brand()
	_label("TAKE A BREATHER", Rect2(28, 220, 424, 28), 13, MINT, true)
	_label("On pause.", Rect2(28, 261, 424, 72), 50, INK, true)
	_label("Your next piece can wait.", Rect2(28, 342, 424, 35), 17, MUTED, true)
	_button("RESUME    →", Rect2(28, 439, 424, 68), _resume, true)
	_button("Settings", Rect2(28, 522, 424, 64), func(): _show_settings("pause"))
	_button("How to play", Rect2(28, 600, 424, 64), func(): _show_help("pause"))
	_button("End run & go home", Rect2(28, 709, 424, 64), _show_home)
	_footer("YOUR BOARD WAITS WHILE THE APP STAYS OPEN")

func _resume() -> void:
	screen = "game"
	game.visible = true
	_clear_ui()
	_build_hud()
	_on_score(game.score)
	_on_lines(game.lines_cleared)
	_on_combo(game.combo)
	game.set_paused(false)
	_on_state(game.get_state())

func _on_score(value: int) -> void:
	if value > progress.best_score:
		progress.best_score = value
		if _save_timer < 0.0:
			_save_timer = 1.0
	_milestone_goal = 150
	while _milestone_goal <= value and _milestone_goal < 1_000_000_000:
		_milestone_goal *= 2
	_progress_target = clampf(float(value) / _milestone_goal, 0.0, 1.0)
	if is_instance_valid(milestone_label):
		milestone_label.text = "NEXT  " + _format_score(_milestone_goal)
	if is_instance_valid(score_label):
		score_label.text = _format_score(value)
		_score_pop = 0.24 if value > 0 else 0.0
	if is_instance_valid(best_label):
		best_label.text = _format_score(progress.best_score)
	queue_redraw()

func _on_lines(value: int) -> void:
	if is_instance_valid(lines_label):
		lines_label.text = "%d LINES CLEARED" % value

func _on_combo(value: int) -> void:
	if is_instance_valid(combo_label):
		combo_label.text = "%d× COMBO" % value if value >= 2 else ""

func _on_state(_value: String) -> void:
	if is_instance_valid(hint_label):
		hint_label.text = "MAKE ROOM FOR SOMETHING GOOD"

func _on_feedback(kind: String) -> void:
	sounds.play(kind)

func _on_finished(value: int) -> void:
	progress.best_score = maxi(progress.best_score, value)
	_save_progress()
	screen = "over"
	game.visible = false
	_clear_ui()
	_brand()
	var record := value > _run_best_before
	_label("NEW PERSONAL BEST" if record else "THAT WAS A GOOD RUN", Rect2(28, 193, 424, 28), 13, MINT, true)
	_label("No space left.", Rect2(28, 236, 424, 67), 44, INK, true)
	_panel(Rect2(28, 348, 424, 165))
	_label("YOUR SCORE", Rect2(48, 370, 384, 23), 12, MUTED, true)
	_label(_format_score(value), Rect2(48, 400, 384, 68), 53, MINT, true)
	_label("BEST  " + _format_score(progress.best_score), Rect2(48, 472, 384, 24), 13, MUTED, true)
	_label("A fresh board. A new possibility.", Rect2(28, 544, 424, 32), 16, MUTED, true)
	_button("PLAY AGAIN    ↻", Rect2(28, 614, 424, 68), _start_run, true)
	_button("Back to home", Rect2(28, 698, 424, 64), _show_home)
	_footer()

func _panel_header(title: String, subtitle: String) -> void:
	_button("←", Rect2(28, 28, 64, 64), _return_from_panel)
	_label(title, Rect2(28, 128, 424, 64), 43)
	_label(subtitle, Rect2(28, 198, 424, 32), 16, MUTED)

func _show_settings(from: String) -> void:
	return_screen = from
	screen = "settings"
	game.visible = false
	_clear_ui()
	_panel_header("Make it yours.", "A little less noise. A little more focus.")
	_panel(Rect2(28, 286, 424, 110))
	_label("Sound effects", Rect2(48, 303, 265, 30), 20)
	_label("Satisfying puzzle tones", Rect2(48, 344, 265, 25), 13, MUTED)
	_button("ON" if progress.sound_enabled else "OFF", Rect2(339, 309, 91, 64), _toggle_sound, progress.sound_enabled)
	_panel(Rect2(28, 412, 424, 110))
	_label("Haptic feedback", Rect2(48, 429, 265, 30), 20)
	_label("A subtle tap on supported phones", Rect2(48, 470, 279, 25), 13, MUTED)
	_button("ON" if progress.haptics_enabled else "OFF", Rect2(339, 435, 91, 64), _toggle_haptics, progress.haptics_enabled)
	_label("MADE FOR YOUR OFFLINE MOMENTS", Rect2(28, 580, 424, 30), 12, MINT)
	var about := _label("No accounts. No ads. No tracking.\nYour best score stays on this device.", Rect2(28, 618, 424, 68), 17, MUTED)
	about.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_button("Privacy & credits", Rect2(28, 729, 424, 64), _show_privacy)
	_footer("BLOCK BUSTERS  /  VERSION 1.2.0")

func _toggle_sound() -> void:
	progress.sound_enabled = not progress.sound_enabled
	sounds.enabled = progress.sound_enabled
	game.sound_enabled = progress.sound_enabled
	_save_progress()
	_show_settings(return_screen)

func _toggle_haptics() -> void:
	progress.haptics_enabled = not progress.haptics_enabled
	game.haptics_enabled = progress.haptics_enabled
	_save_progress()
	_show_settings(return_screen)

func _show_help(from: String) -> void:
	return_screen = from
	screen = "help"
	game.visible = false
	_clear_ui()
	_panel_header("Make room for more.", "A little planning. A lot of satisfying clears.")
	_help_row(279, "01", "Pick your piece", "Drag one of your three blocks onto the\ngrid. Or tap a piece, then tap the board.")
	_help_row(423, "02", "Fill a line", "Complete any row or column to clear it.\nClear several together for bonus points.")
	_help_row(567, "03", "Keep the board open", "Use all three blocks to get a fresh set.\nYour run ends when no piece can fit.")
	_label("No timer. No levels. Just your next best.", Rect2(28, 716, 424, 42), 14, MINT, true)
	_button("GOT IT    →", Rect2(28, 779, 424, 64), _return_from_panel, true)

func _help_row(y: float, number: String, title: String, body: String) -> void:
	_panel(Rect2(28, y, 424, 126))
	_label(number, Rect2(46, y + 17, 51, 34), 22, MINT)
	_label(title, Rect2(102, y + 17, 330, 32), 21)
	_label(body, Rect2(102, y + 54, 330, 56), 14, MUTED)

func _show_privacy() -> void:
	screen = "privacy"
	_clear_ui()
	_button("←", Rect2(28, 28, 64, 64), func(): _show_settings(return_screen))
	_label("Play privately.", Rect2(28, 139, 424, 70), 43)
	_label("YOUR GAME STAYS YOURS", Rect2(28, 245, 424, 30), 12, MINT)
	var text := "Block Busters works completely offline.\n\nWe do not collect, transmit, sell, or share\npersonal data. There are no ads, analytics,\naccounts, purchases, or online services.\n\nYour best score and preferences are saved\nonly in the app's storage on this device.\nUninstalling the app removes this data.\nAndroid backup is disabled for this app.\n\nBuilt with Godot Engine (MIT license).\nOriginal artwork and synthesized sound.\nMade by Trishool Games."
	_label(text, Rect2(28, 294, 424, 391), 16, MUTED)
	_button("Engine licenses", Rect2(28, 697, 424, 60), _show_licenses)
	_button("Back to settings", Rect2(28, 773, 424, 60), func(): _show_settings(return_screen))
	_footer("NO NETWORK CONNECTION REQUIRED")

func _show_licenses() -> void:
	screen = "licenses"
	_clear_ui()
	_button("←", Rect2(28, 28, 64, 64), _show_privacy)
	_label("Open-source credits", Rect2(28, 133, 424, 64), 32)
	_label("Godot Engine & its contributors", Rect2(28, 204, 424, 32), 16, MUTED)
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(28, 269)
	scroll.size = Vector2(424, 475)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	ui.add_child(scroll)
	var credits := RichTextLabel.new()
	credits.custom_minimum_size = Vector2(398, 0)
	credits.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	credits.fit_content = true
	credits.scroll_active = false
	credits.add_theme_font_size_override("normal_font_size", 14)
	credits.add_theme_color_override("default_color", MUTED)
	var text := "GODOT ENGINE\n\n" + Engine.get_license_text() + "\n\nTHIRD-PARTY COMPONENTS\n\n"
	for component in Engine.get_copyright_info():
		text += str(component.get("name", "")) + "\n"
		for part in component.get("parts", []):
			for copyright in part.get("copyright", []):
				text += str(copyright) + "\n"
			text += "License: " + str(part.get("license", "")) + "\n"
		text += "\n"
	var licenses := Engine.get_license_info()
	for name in licenses:
		text += str(name) + "\n" + str(licenses[name]) + "\n\n"
	text += "DEJAVU SANS UI FONTS\n\n" + FileAccess.get_file_as_string("res://assets/fonts/LICENSE-DejaVu.txt")
	credits.text = text
	scroll.add_child(credits)
	_button("Back to privacy", Rect2(28, 779, 424, 64), _show_privacy)

func _return_from_panel() -> void:
	if screen == "licenses":
		_show_privacy()
	elif screen == "privacy":
		_show_settings(return_screen)
	elif return_screen == "pause":
		screen = "game"
		_pause()
	else:
		_show_home()

func _save_progress() -> void:
	if not is_instance_valid(progress):
		return
	_save_timer = -1.0
	var error: Error = progress.save_data()
	if error != OK:
		push_warning("Local progress could not be saved (%s)." % error_string(error))

func _format_score(value: int) -> String:
	var text := str(value)
	var result := ""
	for i in range(text.length()):
		if i > 0 and (text.length() - i) % 3 == 0:
			result += ","
		result += text[i]
	return result

func _prepare_capture() -> void:
	match _capture_screen:
		"game":
			_start_run()
		"settings": _show_settings("home")
		"help": _show_help("home")
		"over": _on_finished(2460)
		"pause":
			_start_run()
			_pause()
		_: _show_home()

func _capture() -> void:
	if _captured:
		return
	_captured = true
	await RenderingServer.frame_post_draw
	if _capture_path.is_empty():
		_capture_path = "user://" + _capture_screen + ".png"
	var error := get_viewport().get_texture().get_image().save_png(_capture_path)
	print("SCREENSHOT ", _capture_screen, " ", _capture_path, " error=", error)
	get_tree().quit(0 if error == OK else 1)
