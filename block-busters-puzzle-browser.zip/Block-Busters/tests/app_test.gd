extends SceneTree
## Integration checks for local saves and the actual endless block-puzzle app.

var checks := 0
var failures := 0

func _initialize() -> void:
	_run.call_deferred()

func check(condition: bool, message: String) -> void:
	checks += 1
	if condition:
		print("PASS: ", message)
	else:
		failures += 1
		push_error("FAIL: " + message)

func _first_fit(game: Node2D, slot: int) -> Vector2i:
	for y in range(8):
		for x in range(8):
			var cell := Vector2i(x, y)
			if game.can_place(slot, cell):
				return cell
	return Vector2i(-1, -1)

func _fixture_piece(cells: Array[Vector2i], color_index: int) -> Dictionary:
	return {"cells": cells, "color_index": color_index, "used": false}

func _run() -> void:
	var store_script = load("res://scripts/save_store.gd")
	var store = store_script.new()
	store.save_path = "user://app-test-puzzle-progress.cfg"
	DirAccess.remove_absolute(store.save_path)
	store.load_data()
	check(store.best_score == 0 and store.runs == 0, "fresh install has safe progress defaults")
	store.best_score = 8765
	store.runs = 12
	store.sound_enabled = false
	store.haptics_enabled = false
	check(store.save_data() == OK, "progress atomically saves")
	var restored = store_script.new()
	restored.save_path = store.save_path
	restored.load_data()
	check(restored.best_score == 8765 and restored.runs == 12, "puzzle record and run count survive reload")
	check(not restored.sound_enabled and not restored.haptics_enabled, "sound and haptic preferences survive reload")
	var corrupt := FileAccess.open(store.save_path, FileAccess.WRITE)
	corrupt.store_string("corrupt {broken data")
	corrupt.close()
	var recover = store_script.new()
	recover.save_path = store.save_path
	recover.load_data()
	check(recover.best_score == 0 and recover.sound_enabled, "invalid save falls back to safe defaults")
	DirAccess.remove_absolute(store.save_path)

	var scene = load("res://scenes/main.tscn").instantiate()
	scene.progress.save_path = store.save_path
	root.add_child(scene)
	await process_frame
	check(scene.screen == "home" and not scene.game.visible, "app boots into the puzzle home screen")
	scene.progress.best_score = 0
	scene.progress.runs = 0
	scene._start_run()
	check(scene.screen == "game" and scene.game.get_state() == "playing", "play opens an active puzzle without a launch step")
	check(scene.game.board.size() == 64 and scene.game.pieces.size() == 3, "run has an eight-by-eight board and three block pieces")
	check(scene.game.moves == 0 and scene.game.has_any_move(), "new puzzle is solvable and has no unintended opening move")
	var target := _first_fit(scene.game, 0)
	check(target.x >= 0 and scene.game.place_piece(0, target), "a tray piece places through the actual game API")
	check(scene.game.score > 0 and scene.progress.best_score == scene.game.score, "piece score reaches the HUD and local record through signals")
	scene.game.score_changed.emit(1234)
	check(scene.progress.best_score == 1234 and scene.score_label.text == "1,234", "score signal updates the formatted score and best record")
	scene._pause()
	check(scene.screen == "pause" and scene.game.get_state() == "paused", "pause suspends the current board")
	var paused_board: Array = scene.game.board.duplicate()
	var paused_moves: int = scene.game.moves
	check(not scene.game.place_piece(1, Vector2i.ZERO) and scene.game.board == paused_board and scene.game.moves == paused_moves, "placement cannot change a paused board")
	scene._show_settings("pause")
	var old_sound: bool = scene.progress.sound_enabled
	scene._toggle_sound()
	check(scene.progress.sound_enabled != old_sound and scene.sounds.enabled == scene.progress.sound_enabled, "sound toggle updates audio and saves")
	var old_haptics: bool = scene.progress.haptics_enabled
	scene._toggle_haptics()
	check(scene.progress.haptics_enabled != old_haptics and scene.game.haptics_enabled == scene.progress.haptics_enabled, "haptic toggle updates the puzzle and saves")
	scene._return_from_panel()
	check(scene.screen == "pause" and scene.game.get_state() == "paused", "settings back preserves the paused puzzle")
	scene._resume()
	check(scene.screen == "game" and scene.game.get_state() == "playing" and scene.game.board == paused_board, "resume preserves the existing blocks")
	scene._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
	check(scene.screen == "pause" and scene.game.get_state() == "paused", "losing app focus pauses safely")
	scene._resume()

	# Isolated holes leave no place for either remaining square. Placing one
	# singleton does not fill a row/column, so game over is a real no-move result.
	for y in range(8):
		for x in range(8):
			scene.game.board[y * 8 + x] = 1 if (x + y) % 2 == 0 else 0
	var single: Array[Vector2i] = [Vector2i.ZERO]
	var square: Array[Vector2i] = [Vector2i.ZERO, Vector2i.RIGHT, Vector2i.DOWN, Vector2i.ONE]
	scene.game.pieces.assign([_fixture_piece(single, 1), _fixture_piece(square, 2), _fixture_piece(square, 3)])
	scene.game.score = 1450
	check(scene.game.place_piece(0, Vector2i(1, 0)), "last legal singleton can be placed before remaining shapes are blocked")
	check(scene.game.get_state() == "game_over" and scene.screen == "over" and scene.progress.best_score >= 1450, "no remaining fit opens results and preserves the puzzle record")
	var record: int = scene.progress.best_score
	scene._start_run()
	check(scene.game.score == 0 and scene.game.moves == 0 and scene.game.pieces.size() == 3 and scene.progress.best_score == record, "retry resets the board and hand while preserving the record")

	scene._show_home()
	scene._show_help("home")
	var instruction_text := ""
	for child in scene.ui.get_children():
		if child is Label:
			instruction_text += child.text.to_lower() + " "
	check(scene.screen == "help" and "row" in instruction_text and "column" in instruction_text, "instructions describe block placement and clearing rows and columns")
	scene._return_from_panel()
	check(scene.screen == "home", "instructions return home")
	scene._show_settings("home")
	scene._show_privacy()
	check(scene.screen == "privacy", "privacy notice remains available offline")
	scene._show_licenses()
	check(scene.screen == "licenses", "open-source license notices are reachable")
	scene._go_back()
	check(scene.screen == "privacy", "Android Back leaves credits for privacy")
	scene._go_back()
	check(scene.screen == "settings", "Android Back leaves privacy for settings")
	scene._go_back()
	check(scene.screen == "home", "Android Back leaves settings for home")
	scene.queue_free()
	await process_frame
	DirAccess.remove_absolute(store.save_path)
	print("APP TESTS: %d checks, %d failures" % [checks, failures])
	quit(1 if failures > 0 else 0)
