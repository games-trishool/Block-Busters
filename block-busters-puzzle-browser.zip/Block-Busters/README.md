# Block Busters — endless block puzzle

A portrait, offline **block-placement puzzle** for Android and browsers, built
with Godot 4.6.3. Place tactile, beveled block shapes on an 8×8 recessed navy grid.
Complete rows or columns to clear space, combine clears, and chase your best.
There is no timer, level list, account, advertising, purchase, or server.

Version1.2 refreshes the indigo home/game UI, score animation, milestone bar,
materials, and blast effects. A shared high-resolution tile atlas and cached
background/style resources reduce redraw work. Rendering targets60FPS with
time-based effects; actual FPS depends on device, browser, and graphics settings.

## Browser test in VS Code

Extract the browser ZIP and open the **Block-Busters** folder containing
`package.json` in VS Code. Install Node.js18 or newer, then run:

```sh
npm start
```

Open the address printed in the terminal. No `npm install`, Godot installation,
or Android SDK is needed to play the included browser build. Full instructions
are in [START_HERE.md](START_HERE.md). The `web/` files are a built export;
editing GDScript source requires exporting again with Godot before refreshing.

## How to play

- Drag one of your three pieces onto empty grid cells. On a touchscreen the
  piece lifts above your finger so you can see the landing preview.
- Alternatively, tap/click a piece, then tap/click the cell for its top-left
  corner. Pieces keep their displayed orientation.
- Fill any full row or column to clear it. Intersecting completed rows and
  columns clear together; cleared cells are counted once.
- Use all three pieces to get a new set. Plan around the space you have left.
- The run ends when none of your remaining pieces fit. There are no lives,
  falling blocks, timed moves, or level completion screens.
- Escape/P or Android Back pauses. Leaving the app also pauses it.

Best score and sound/vibration preferences are stored locally in
`user://puzzle-progress.cfg`. The earlier, incorrect arcade prototype's score
file is separate. An active board survives a pause while the app process stays
alive; it does not survive force-stop, process termination, or restart.

## Godot development

Use the existing `/workspace/Block-Busters` checkout. Every cloud task is
already isolated; another Git worktree is unnecessary.

```sh
cd /workspace/Block-Busters
source /workspace/.block-busters-tools/env.sh
godot --editor --path .
```

If the Android tool environment is missing, run `bash tools/setup-android.sh`
first. It installs pinned dependencies outside the checkout. Press F5 in the
editor or run `godot --path .` in a graphical session to play the source.

## Validate and export

```sh
bash tools/test.sh
bash tools/capture-screenshots.sh
godot --headless --path . --export-release "Web Browser" web/index.html
bash tools/build-android.sh debug
bash tools/build-android.sh unsigned
```

The tests exercise legal and rejected placements, simultaneous line clears,
scoring, hand refresh, no-move endings, pause, transformed touch coordinates,
real GUI touch events, saved preferences, and app navigation. Screenshots are
rendered from the actual game, under `artifacts/screenshots/`. For a tall phone,
use `CAPTURE_SIZE=480x1040 bash tools/capture-screenshots.sh artifacts/screenshots-tall`.

Android outputs are `artifacts/block-busters-debug.apk` and
`artifacts/block-busters-unsigned.aab`. Version1.2.0/code3, package
`com.trishoolgames.blockbusters`, ARM64, min API24, target API36. The APK is
test-signed. The unsigned bundle still needs your private upload key before
Play upload; follow [docs/ANDROID.md](docs/ANDROID.md). No production key is
included. SDK/JDK, templates, caches, and the public test key live outside the
checkout under `/workspace/.block-busters-tools`.

Test touch, haptics, screen cutouts, background/resume, local records, and an
extended run on a physical Android phone before Play submission. Browser and
headless checks do not establish physical-device behavior or store acceptance.

## Store release material

Original neon block artwork, adaptive icons, and the feature graphic are under
`assets/`. See [docs/STORE_LISTING.md](docs/STORE_LISTING.md) for listing copy
and account/testing requirements. Complete the developer contact in
[docs/PRIVACY.md](docs/PRIVACY.md) and host the completed policy at a public
HTTPS URL. Confirm the package ID before the first upload.

There are no game servers or recurring content updates to operate. Occasional
Android compatibility or store policy maintenance may still be needed.

| File | Responsibility |
| --- | --- |
| `scripts/gameplay.gd` | Grid, pieces, placement, line clears, input, effects |
| `scripts/main.gd` | Menus, HUD, local best, app lifecycle, privacy and licenses |
| `scripts/save_store.gd` | Atomic local score/settings storage |
| `scripts/audio.gd` | Original synthesized puzzle sounds |
| `tools/serve-web.mjs` | Dependency-free local web server |
| `tests/` | Gameplay, app, and touchscreen checks |

Godot and third-party notices are included in **Settings → Privacy & credits →
Engine licenses**. Original artwork and sound are included. The DejaVu Sans
UI font and symbol fallback's license is in `assets/fonts/` and the in-game credits.
