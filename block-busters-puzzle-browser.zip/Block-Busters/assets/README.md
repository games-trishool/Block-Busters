# Project artwork

Block Busters uses original geometric artwork: vividly colored block pieces
with raised faces, directional bevels, contact shadows, and fine top highlights.
A recessed navy grid sits against a royal indigo background. The composition
represents the existing 8×8 block-placement puzzle; it contains no falling-piece
or lane-steering indicator and uses no third-party game logo or screenshot.

- `icon.svg`: editable, opaque 1024×1024 app icon. Android and Google Play apply
  their own outer masks.
- `icon.png`: 1024×1024 PNG for Android export configuration.
- `icon-foreground.svg` and `icon-background.svg`: 432×432 Android adaptive icon
  layers. Every visible foreground pixel fits in the centered 264px safe circle.
- `store-icon.png`: 512×512 PNG for the Google Play listing.
- `store-feature.svg` and `store-feature.png`: editable source and 1024×500 Play
  feature graphic, labeled **ENDLESS BLOCK PUZZLE**.

Primary colors: royal indigo `#3c508b`, navy `#20294e`, green `#00db4a`, cyan
`#21cdec`, blue `#337fff`, purple `#c640ec`, and orange `#ff7137`.
The feature graphic uses DejaVu Sans. The bundled font fallback and its license
remain under `fonts/`.

To regenerate the PNGs with Inkscape:

```sh
inkscape assets/icon.svg --export-filename=assets/icon.png --export-width=1024 --export-height=1024
inkscape assets/icon.svg --export-filename=assets/store-icon.png --export-width=512 --export-height=512
inkscape assets/store-feature.svg --export-filename=assets/store-feature.png --export-width=1024 --export-height=500
```

Store graphics are promotional artwork. Use captures of the final game on actual
phones for the screenshot section of the store listing. No frame-rate guarantee
is made by these graphics or the store copy; performance varies by device.
