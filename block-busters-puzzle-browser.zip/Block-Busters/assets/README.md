# Project artwork

Block Busters uses original vector artwork: glossy square red, green, and blue
block pieces on a purple checkerboard, with geometric sparkles. The artwork
represents a block-placement puzzle. No third-party game logo or image asset is
included.

- `icon.svg`: editable 1024 × 1024 app icon with an opaque background. Android
  and Google Play apply their own outer masks.
- `icon.png`: 1024 × 1024 PNG rendition for Android export configuration.
- `icon-foreground.svg` / `icon-background.svg`: 432 × 432 Android adaptive icon
  layers. The transparent foreground emblem fits inside the centered 264-pixel
  safe circle.
- `store-icon.png`: 512 × 512 PNG for the Google Play listing.
- `store-feature.svg` / `store-feature.png`: editable source and 1024 × 500 Play
  feature graphic, labeled **ENDLESS BLOCK PUZZLE**.

The promotional feature graphic uses DejaVu Sans when rendered. The game's
bundled symbol fallback and its license remain under `fonts/`.

To regenerate the PNG artwork with Inkscape:

```sh
inkscape assets/icon.svg --export-filename=assets/icon.png --export-width=1024 --export-height=1024
inkscape assets/icon.svg --export-filename=assets/store-icon.png --export-width=512 --export-height=512
inkscape assets/store-feature.svg --export-filename=assets/store-feature.png --export-width=1024 --export-height=500
```
