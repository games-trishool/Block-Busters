# Block Busters — Google Play listing draft

This is release preparation material. The app has not been uploaded, reviewed,
or approved by Google Play. Review the copy against the final build and device
testing before submission.

## Store copy

**App name** (13/30 characters):

Block Busters

**Short description** (80/80 characters):

Place glowing blocks, clear rows and columns, and chase your best score offline.

**Full description**:

Make space for your next best.

Block Busters is a colorful block-placement puzzle made for your phone. Fit
bright, beveled block pieces onto a recessed 8×8 grid. Complete a row or column,
watch it clear, and make room for the next piece.

THINK AHEAD, KEEP GOING

Choose from three pieces at a time. Use all three to receive a fresh hand, and
keep placing for as long as the board has room. The run ends when none of your
remaining pieces can fit. There are no levels to finish or timer to race.

MADE FOR TOUCH

Drag a piece onto the board, preview its position, and release to place it.
You can also tap a piece and then tap a board cell. Clear full rows and columns
together to open the board and earn a bigger score.

COLOR WITH A LITTLE DEPTH

Crisp block faces, softly shaded edges, and a clean indigo board make every
piece easy to read. A landing preview helps you plan before you commit.

CHASE YOUR OWN BEST

Build clear streaks, plan your next move, and beat your personal record. Your
best score and sound/vibration preferences stay on your device.

PLAY ON YOUR TERMS

• Offline, single-player block puzzle
• An 8×8 board and changing three-piece hands
• Complete rows and columns to clear space
• Clear streaks and local best score
• Vivid beveled blocks and placement previews
• No timer, lives, or level list
• Optional sound and vibration
• Pause and resume during a run
• No ads, accounts, or in-app purchases

No server connection, live event, or daily check-in is needed. Just drag, place,
and clear.

## Graphic files

| Purpose | File | Dimensions |
| --- | --- | --- |
| Google Play app icon | `assets/store-icon.png` | 512 × 512 |
| Google Play feature graphic | `assets/store-feature.png` | 1024 × 500 |
| High-resolution source icon | `assets/icon.png` | 1024 × 1024 |
| Editable vector sources | `assets/icon.svg`, `assets/store-feature.svg` | SVG |

The graphics are original geometric artwork. The feature graphic is promotional
artwork; capture screenshots from the actual app for the phone screenshot
section. Do not present concept art as an in-game screenshot.

## Developer information to supply

- Confirm the public developer name; the current artwork uses **Trishool Games**.
- Supply a monitored developer support email address in Play Console. Do not
  leave a placeholder in the public listing.
- Complete `docs/PRIVACY.md` with the developer contact, publish it at a publicly
  accessible HTTPS URL, and enter that URL in Play Console. Keep it accessible
  after release.
- Confirm the application ID before the first upload. The default is
  `com.trishoolgames.blockbusters`; the package ID cannot be changed for an
  already published Play application.

## Play Console submission checklist

- Build a release Android App Bundle with a private upload key. Use Play App
  Signing and back up the upload key/passwords outside the repository. The debug
  APK is for testing, not a Play release artifact.
- Confirm the bundle meets the current target Android API and native-library
  requirements shown by Play Console. A successful local build does not establish
  store acceptance.
- Install the release-equivalent build on real Android devices. Check piece
  selection and dragging, snap previews, invalid drops, simultaneous row/column
  clears, no-move results, screen cutouts, pause/background/resume,
  sound/vibration toggles, best-score persistence, and an extended run.
- Upload real phone screenshots showing the current home screen and active
  puzzle board. Confirm small-screen readability.
- Complete the content rating, target audience, app access, ads, and data safety
  forms. For the current offline build, no app data is collected or shared, no
  account is required, and there are no ads. Reassess these answers if SDKs or
  online features are added.
- Select the intended audience and answer the rating questions accurately. A
  puzzle theme alone does not determine a store rating or Families declaration.
- Complete any identity verification, closed testing, and production access
  steps required for the developer account.
- Review the store copy and privacy policy, then submit the signed bundle through
  an internal or closed testing track before production.

## Operation after release

The game uses local play and local storage, so it needs no game server, live
content schedule, or daily operational monitoring. Keep the developer contact
and privacy policy valid. Plan occasional maintenance when Android compatibility,
a confirmed bug, or a Play policy change requires an update; offline operation
does not remove those store obligations.
