# Graphics and performance — version1.2

The game keeps the existing8×8 placement rules. The refresh adds a richer
indigo interface, beveled cube materials, score pops, milestone progress,
placement pops, sparks, and row/column blast beams.

## Rendering changes

- One shared96px-per-cell texture atlas replaces repeated tile geometry and
  per-tile glow work. The same material is used by the home preview, board,
  tray, and dragged pieces.
- Background/style resources are retained. Settled gameplay does not request
  continuous redraws or allocate new tile materials.
- Effect buffers are bounded and drain after an effect. A native stress probe
  passed51 checks across40 real line clears, confirming one atlas build and
  stable settled counters. The regular gameplay/app/touch suite passes90 checks.
- Rendering targets60FPS. All animations use elapsed time; the target is not
  a promise of the same frame rate on every phone/browser.

## Controlled browser comparison

Measured in Chromium154, WebGL SwiftShader software rendering,480×900,DPR1.
Each sample was5seconds, using the same launch flags and idle/continuous-drag
workload. The figures below are observed requestAnimationFrame cadence, not
physical-phone FPS or proof of engine draw throughput on every frame.

| Workload | Previous version | Enhanced version |
| --- | ---: | ---: |
| Idle game | 9.29 FPS | 22.80 FPS |
| Dragging a piece | 8.49 FPS | 18.68 FPS |

Repeated software samples vary. Hardware GPU, browser configuration, device
pixel density, thermal state, and screen refresh rate affect real results.
No browser runtime errors occurred during placement and settings/pause checks.
Physical Android performance remains unmeasured in this cloud environment.

For a local test, start the browser build with `npm start`, enable hardware
acceleration in your browser, and test normal play plus multiple-line blasts.
