# Play Block Busters — endless block puzzle

This ZIP contains the **complete original Godot project** and a **ready-built
browser version**. You do not need Godot or the Android SDK to play it.

1. Extract the ZIP first. Do not run files inside the ZIP preview.
2. In VS Code choose **File → Open Folder** and select the extracted
   **Block-Busters** folder (the one containing `package.json`).
3. Install **Node.js 18 or newer** if your system does not already have it.
   Restart VS Code after installing Node.js.
4. Choose **Terminal → New Terminal**, then run:

   ```sh
   npm start
   ```

   There are no npm dependencies: **you do not need `npm install`**.

5. Open the address printed in the terminal in Chrome, Edge, Firefox, or Safari.
   Keep the terminal open while playing. The first load compiles the WebAssembly
   game engine and may take a few seconds.
6. Click **Play Endless**. Drag one of the three block pieces onto the purple
   grid, or click a piece and then click a grid cell to place its top-left corner.
   Fill a whole row or column to clear it. Use all three pieces for a new set.
   Escape/P pauses. Touch dragging works on touchscreens. There is no timer.

Do not double-click `web/index.html`: WebAssembly game files need to be served
over HTTP. VS Code Live Server can also serve `web/index.html`; the included
settings point Live Server at `web/`. The `npm start` route is the tested default.

If `npm` is not recognized, install Node.js and restart VS Code. If your browser
reports that WebGL 2 is unavailable, enable browser graphics acceleration and
use an up-to-date browser. If the port is occupied, stop the previous server
with Ctrl+C or choose another `PORT` environment variable.

## Editing the game

The game logic is in `scripts/*.gd` and the scene is `scenes/main.tscn`.
You can edit those files in VS Code. The web files are a **built export**, so
source edits do not appear in your browser automatically.

To rebuild after changing game code, install **Godot 4.6.3** and its matching
export templates, open `project.godot`, choose **Project → Export → Web Browser**,
and export to `web/index.html`. Keep thread support disabled for broad browser
compatibility. Alternatively, with Godot on your PATH:

```sh
godot --headless --editor --path . --import
godot --headless --path . --export-release "Web Browser" web/index.html
```

Then refresh the browser. The browser version uses the same endless block-placement puzzle
as the Android game. Browser storage keeps its own local best score/settings;
clearing site data clears them. Android builds and Play release instructions
are documented separately in `README.md` and `docs/ANDROID.md`.

This ZIP does not contain APKs, signing keys, Android SDK/JDK installations, or
large build caches. It is intended for local source inspection and browser play.
