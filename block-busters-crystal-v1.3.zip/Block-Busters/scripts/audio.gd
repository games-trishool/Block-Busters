class_name ArcadeAudio
extends Node
## Original crystal effects and an original, seamless ambient soundtrack.
## All audio is local. Music and effects have independent preferences.

const MUSIC = preload("res://assets/audio/crystal-drift.ogg")
const GLASS_SHATTER = preload("res://assets/audio/glass-shatter.wav")
const CRYSTAL_COMBO = preload("res://assets/audio/crystal-combo.wav")
const MAX_VOICES := 6
const MUSIC_VOLUME_DB := -19.0

var enabled: bool = true:
	set(value):
		enabled = value
		if not value:
			_stop_effects()
var music_enabled: bool = true:
	set(value):
		music_enabled = value
		_sync_music()
var _effects: Dictionary = {}
var _voices: Array[AudioStreamPlayer] = []
var _voice: int = 0
var _effect_plays: int = 0
var _music: AudioStreamPlayer
var _audio_unlocked := false
var _focus_active := true
var _music_started := false

func _ready() -> void:
	for i in range(MAX_VOICES):
		var player := AudioStreamPlayer.new()
		player.volume_db = -15.0
		add_child(player)
		_voices.append(player)
	_effects["place"] = _tone(700.0, 0.09, 1.12)
	_effects["clear"] = GLASS_SHATTER
	_effects["select"] = _tone(600.0, 0.035)
	_effects["invalid"] = _tone(170.0, 0.07, 0.8)
	_effects["game_over"] = _tone(180.0, 0.4, 0.35)
	_effects["combo"] = CRYSTAL_COMBO
	_effects["click"] = _tone(740.0, 0.04)
	_music = AudioStreamPlayer.new()
	_music.name = "CrystalDriftMusic"
	_music.volume_db = MUSIC_VOLUME_DB
	var loop_stream := MUSIC.duplicate() as AudioStreamOggVorbis
	loop_stream.loop = true
	loop_stream.loop_offset = 0.0
	_music.stream = loop_stream
	add_child(_music)
	_sync_music()

func _exit_tree() -> void:
	# Release looping decoders before scene teardown, including headless tests.
	if is_instance_valid(_music):
		_music.stop()
		_music.stream = null
	_stop_effects()
	for player in _voices:
		player.stream = null
	_effects.clear()

func _input(event: InputEvent) -> void:
	# Browsers permit audible playback after a real input gesture. Do not try
	# to autoplay on page load; the first tap starts this local music loop.
	if event is InputEventScreenTouch and event.pressed:
		unlock_audio()
	elif event is InputEventMouseButton and event.pressed:
		unlock_audio()
	elif event is InputEventKey and event.pressed and not event.echo:
		unlock_audio()

func unlock_audio() -> void:
	if _audio_unlocked:
		return
	_audio_unlocked = true
	_sync_music()

func set_music_enabled(value: bool) -> void:
	music_enabled = value

func set_focus_active(value: bool) -> void:
	_focus_active = value
	if not value:
		_stop_effects()
	_sync_music()

func _sync_music() -> void:
	if not is_instance_valid(_music):
		return
	var should_play := music_enabled and _audio_unlocked and _focus_active
	if should_play:
		if not _music_started:
			_music.play()
			_music_started = true
		_music.stream_paused = false
	else:
		# Pause the decoder so off/background is silent, and enabling it again
		# continues the phrase instead of repeatedly restarting the opening.
		_music.stream_paused = true

func _stop_effects() -> void:
	for player in _voices:
		player.stop()

func play(kind: String) -> void:
	if not enabled or not _focus_active or _voices.is_empty():
		return
	var effect: AudioStream = _effects.get(kind, _effects["place"])
	var player := _voices[_voice]
	_voice = (_voice + 1) % _voices.size()
	player.stream = effect
	player.play()
	_effect_plays += 1

func get_audio_state() -> Dictionary:
	var playing := is_instance_valid(_music) and _music.playing and not _music.stream_paused
	var active_voices := 0
	for player in _voices:
		if player.playing:
			active_voices += 1
	return {"unlocked": _audio_unlocked, "music_enabled": music_enabled,
		"effects_enabled": enabled, "focus_active": _focus_active,
		"music_playing": playing, "music_started": _music_started,
		"music_position": _music.get_playback_position() if is_instance_valid(_music) else 0.0,
		"effect_voices": _voices.size(), "active_effect_voices": active_voices,
		"effect_plays": _effect_plays}

func _tone(frequency: float, length: float, slide: float = 1.0) -> AudioStreamWAV:
	var rate := 22050
	var count := int(length * rate)
	var samples := PackedByteArray()
	samples.resize(count * 2)
	var phase := 0.0
	for i in range(count):
		var t := float(i) / count
		phase += TAU * lerpf(frequency, frequency * slide, t) / rate
		var envelope := minf(t * 25.0, 1.0) * pow(1.0 - t, 2.0)
		var value := int((sin(phase) + sin(phase * 2.0) * 0.12) * envelope * 16000.0)
		samples.encode_s16(i * 2, value)
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.data = samples
	return stream
