#!/usr/bin/env python3
"""Package source and the prebuilt browser export, without caches or Android binaries."""
from pathlib import Path
import hashlib
import zipfile

repo = Path(__file__).resolve().parent.parent
output = repo / 'block-busters-browser.zip'
roots = ['.vscode', 'assets', 'docs', 'scenes', 'scripts', 'tests', 'tools', 'web']
files = [repo / name for name in ['.gitignore', 'project.godot', 'export_presets.cfg', 'README.md', 'START_HERE.md', 'package.json']]
for root in roots:
    files.extend(path for path in (repo / root).rglob('*') if path.is_file())
files = sorted(set(files))
with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in files:
        rel = path.relative_to(repo)
        if '__pycache__' in rel.parts or path.suffix in {'.pyc', '.log', '.tmp', '.keystore', '.jks', '.pem'}:
            continue
        if path.is_symlink():
            raise SystemExit(f'Refusing symbolic link: {rel}')
        archive.write(path, 'Block-Busters/' + rel.as_posix())
with zipfile.ZipFile(output) as archive:
    error = archive.testzip()
    if error:
        raise SystemExit(f'ZIP validation failed: {error}')
    names = archive.namelist()
    for required in ['web/index.html', 'web/index.pck', 'web/index.wasm', 'scripts/audio.gd', 'assets/audio/crystal-drift.ogg', 'tools/serve-web.mjs']:
        if 'Block-Busters/' + required not in names:
            raise SystemExit(f'Missing required file: {required}')
    assert not any('/.godot/' in n or n.endswith(('.apk', '.aab', '.keystore', '.jks')) for n in names)
print(f'{output.name}: {len(names)} files, {output.stat().st_size} bytes')
print('SHA256 ' + hashlib.sha256(output.read_bytes()).hexdigest())
