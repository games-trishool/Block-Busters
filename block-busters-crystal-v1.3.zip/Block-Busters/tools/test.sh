#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
tools_dir="${BLOCK_BUSTERS_TOOLS_DIR:-/workspace/.block-busters-tools}"
export XDG_DATA_HOME="$tools_dir/test-xdg/data"
export XDG_CONFIG_HOME="$tools_dir/test-xdg/config"
export XDG_CACHE_HOME="$tools_dir/test-xdg/cache"
mkdir -p "$XDG_DATA_HOME" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME"
cd "$project_dir"
godot --headless --editor --path "$project_dir" --import
godot --headless --path "$project_dir" --script tests/gameplay_test.gd
godot --headless --path "$project_dir" --script tests/app_test.gd
godot --headless --path "$project_dir" --script tests/touch_ui_test.gd
godot --headless --path "$project_dir" --script tests/crystal_render_test.gd
godot --headless --path "$project_dir" --script tests/audio_test.gd
