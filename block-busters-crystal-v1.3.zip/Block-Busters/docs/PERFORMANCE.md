# Graphics and performance — version 1.3

The game keeps the existing 8×8 placement rules. Version 1.3 adds glossy faceted
crystal faces, baked reflections and highlights, rotating glass-like shards,
crack flashes, and blast shock rings. The jewel-colored interface uses cached
background and glass panel textures. Original ambient music and crystal sounds
are bundled locally and do not use a network service.

## Rendering approach

- One shared 96 px-per-cell texture atlas supplies the home preview, board,
  tray, and dragged pieces. Crystal reflections are baked once rather than
  calculated through a full-screen shader on every frame.
- Background and interface resources are retained. Settled gameplay stops
  requesting redraws after placement and blast effects finish.
- Particle and effect buffers have fixed limits. Shards expire after each blast.
- Rendering targets 60 FPS. All animations use elapsed time; the target does not
  promise the same frame rate on every phone or browser.

Physical Android performance and audio quality must still be checked on devices.
Browser software-rendering measurements do not establish physical-phone FPS.

## Current validation

The five Godot suites pass 130 checks, covering placement rules, touch controls,
settings persistence, crystal material/effect limits, and audio lifecycle.
Chromium checks also confirmed actual WebAudio output after the first tap,
silence with music disabled, and the saved OFF preference after reload. The
390×844 touch-emulation run cleared a real line and showed no horizontal overflow
or browser runtime errors. Emulation does not replace a physical iPhone or
Android device check.

## Historical version 1.2 browser comparison

These figures describe the previous version 1.2 refresh, **not a benchmark of
version 1.3**. The comparison used Chromium 154, WebGL SwiftShader software
rendering, 480×900, DPR 1. Each sample lasted 5 seconds with the same launch flags
and idle/continuous-drag workload. Values are observed requestAnimationFrame
cadence, not proof of engine draw throughput on every frame.

| Workload | Before version 1.2 | Version 1.2 |
| --- | ---: | ---: |
| Idle game | 9.29 FPS | 22.80 FPS |
| Dragging a piece | 8.49 FPS | 18.68 FPS |

Repeated software samples vary. Hardware GPU, browser configuration, device
pixel density, thermal state, and screen refresh rate affect actual results.

For a local check, start the browser build with `npm start`, enable hardware
acceleration, and test normal play plus multiple-line blasts. On your phone,
use the HTTPS forwarded URL from VS Code and check audio toggles, mute behavior,
background/resume, touch placement, and extended play.
