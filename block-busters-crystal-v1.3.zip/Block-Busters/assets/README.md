# Project artwork

Block Busters uses original geometric artwork: vividly colored block pieces
with glossy faceted faces, directional bevels, contact shadows, and sharp reflected
highlights. The version 1.3 in-game renderer bakes these crystal materials into a
shared atlas at runtime. A recessed navy grid sits against a plum/teal jewel
background; retained promotional artwork uses the earlier royal indigo palette. The composition
represents the existing 8×8 block-placement puzzle; it contains no falling-piece
or lane-steering indicator and uses no third-party game logo or screenshot.

- `icon.svg`: editable, opaque 1024×1024 app icon. Android and Google Play apply
  their own outer masks.
- `icon.png`: 1024×1024 PNG for Android export configuration.
- `icon-foreground.svg` and `icon-background.svg`: 432×432 Android adaptive icon
  layers. Every visible foreground pixel fits in the centered 264px safe circle.
- `store-icon.png`: 512×512 PNG for the Google Play listing.
- `store-feature.svg` and `store-feature.png`: editable source and 1024×500 Play
  feature graphic, labeled **ENDLESS BLOCK PUZZLE**.

Primary colors: royal indigo `#3c508b`, navy `#20294e`, green `#00db4a`, cyan
`#21cdec`, blue `#337fff`, purple `#c640ec`, and orange `#ff7137`.
The feature graphic uses DejaVu Sans. The bundled font fallback and its license
remain under `fonts/`.

To regenerate the PNGs with Inkscape:

```sh
inkscape assets/icon.svg --export-filename=assets/icon.png --export-width=1024 --export-height=1024
inkscape assets/icon.svg --export-filename=assets/store-icon.png --export-width=512 --export-height=512
inkscape assets/store-feature.svg --export-filename=assets/store-feature.png --export-width=1024 --export-height=500
```

Store graphics are promotional artwork. Use captures of the final game on actual
phones for the screenshot section of the store listing. No frame-rate guarantee
is made by these graphics or the store copy; performance varies by device.

## Audio

The game includes original synthesized crystal-shatter sound effects and gentle
ambient background music. They work offline, require no downloaded music service,
and have separate settings. Playback begins after a user gesture in the browser
and pauses when the app loses focus. No third-party recording is included.
