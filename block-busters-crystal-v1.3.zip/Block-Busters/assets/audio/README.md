# Original audio

**Crystal Drift** is an original, gentle eight-bar ambient composition at 80 BPM.
Warm sustained chords and a sparse glass-piano melody form a 24-second stereo
loop. Release and room tails wrap across the seam. `ArcadeAudio` plays it softly
at -19 dB, after the first user gesture; the player's music setting is independent
of sound effects. Music pauses while the app is in the background.

`glass-shatter.wav` and `crystal-combo.wav` are original synthesized effects:
a brief fracture followed by scattered inharmonic glass resonances and a quiet
crystal bloom. They contain no recorded or downloaded samples.

All score, oscillators, envelopes, and deterministic noise are authored in
`generate_audio.py`. Rebuilding requires Python 3, numpy, and ffmpeg; these tools
are unnecessary for playing the game. Run `python3 assets/audio/generate_audio.py`
from the project root. Audio is generated at 32 kHz stereo; the soundtrack uses
Ogg Vorbis and the two short effects use 16-bit WAV.
