#!/usr/bin/env python3
"""Original Block Busters audio. Run with Python/numpy and ffmpeg to rebuild.

All oscillators, envelopes, score, and deterministic noise are authored here.
The score repeats every eight bars; wrapped release/reverb tails keep the seam
continuous. Runtime only loads the exported Ogg/WAV files, never this generator.
"""
from pathlib import Path
import math
import subprocess
import tempfile
import wave
import numpy as np

OUT = Path(__file__).resolve().parent
RATE = 32000
RNG = np.random.default_rng(842014)


def hz(midi):
    return 440.0 * 2 ** ((midi - 69) / 12)


def stereo(signal, pan):
    return np.column_stack((signal * math.sqrt((1 - pan) / 2),
                            signal * math.sqrt((1 + pan) / 2)))


def wrap_add(target, signal, time):
    start = round(time * RATE) % len(target)
    for offset in range(0, len(signal), len(target)):
        part = signal[offset:offset + len(target)]
        first = min(len(part), len(target) - start)
        target[start:start + first] += part[:first]
        if first < len(part):
            target[:len(part) - first] += part[first:]
        start = 0


def pad(midi, duration):
    t = np.arange(round(duration * RATE)) / RATE
    f = hz(midi)
    env = (1 - np.exp(-t * 3.3)) * np.minimum(1, np.maximum(0, duration - t) / 1.2) ** 2
    shimmer = 0.94 + 0.06 * np.sin(2 * np.pi * 0.18 * t)
    return (np.sin(2 * np.pi * f * t) + .13 * np.sin(2 * np.pi * f * 2 * t)
            + .06 * np.sin(2 * np.pi * f * 3 * t)) * env * shimmer


def bell(midi, duration=3.0):
    t = np.arange(round(duration * RATE)) / RATE
    f = hz(midi)
    attack = 1 - np.exp(-t * 160)
    signal = np.sin(2 * np.pi * f * t) * np.exp(-t * 2.0)
    signal += .24 * np.sin(2 * np.pi * f * 2.004 * t) * np.exp(-t * 3.5)
    signal += .10 * np.sin(2 * np.pi * f * 3.99 * t) * np.exp(-t * 5)
    return signal * attack * np.minimum(1, (duration - t) * 5)


def write_wav(path, signal):
    if signal.ndim == 1:
        signal = signal[:, None]
    pcm = np.round(np.clip(signal, -.999, .999) * 32767).astype('<i2')
    with wave.open(str(path), 'wb') as handle:
        handle.setnchannels(signal.shape[1])
        handle.setsampwidth(2)
        handle.setframerate(RATE)
        handle.writeframes(pcm.tobytes())


def compose():
    beat = .75  # 80 BPM, four beats/bar, eight bars = 24 seconds.
    length = 8 * 4 * beat
    mix = np.zeros((round(length * RATE), 2), dtype=np.float64)
    chords = [[48, 55, 59, 62, 64], [45, 52, 55, 59, 60],
              [41, 48, 52, 55, 57], [43, 50, 55, 57, 62]]
    for bar in range(8):
        chord = chords[bar % 4]
        for index, note in enumerate(chord):
            wrap_add(mix, stereo(pad(note, 4.8), (index - 2) * .24) * .042,
                     bar * 4 * beat)
        # Low warm foundation, softly bowed rather than a hard bass attack.
        wrap_add(mix, stereo(pad(chord[0] - 12, 3.4), 0) * .065, bar * 4 * beat)
    # Sparse original glass-piano motif; room for the player's crystal effects.
    phrases = [[(0.5, 76), (2, 79), (3, 74)],
               [(0.5, 72), (2.5, 76)],
               [(1, 74), (2.5, 72), (3.5, 69)],
               [(0.5, 71), (2.5, 74)],
               [(0.5, 76), (2, 79), (3, 81)],
               [(0.5, 79), (2.5, 76)],
               [(1, 74), (2.5, 72)],
               [(0.5, 71), (2, 74), (3, 79)]]
    for bar, notes in enumerate(phrases):
        for index, (when, note) in enumerate(notes):
            wrap_add(mix, stereo(bell(note), (-.3 if index % 2 == 0 else .3)) * .075,
                     (bar * 4 + when) * beat)
    dry = mix.copy()
    # A tiny stereo room. Delay tails also wrap so the encoded loop is seamless.
    for delay, gain in [(0.17, .15), (0.31, .10), (0.53, .075), (0.79, .04)]:
        mix += np.roll(dry[:, ::-1], round(delay * RATE), axis=0) * gain
    mix *= .78 / np.max(np.abs(mix))
    with tempfile.TemporaryDirectory(prefix='block-busters-audio-') as temporary:
        wav = Path(temporary) / 'crystal-drift.wav'
        write_wav(wav, mix)
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                        '-i', str(wav), '-c:a', 'libvorbis', '-q:a', '5',
                        '-metadata', 'title=Crystal Drift',
                        '-metadata', 'artist=Block Busters Original Soundtrack',
                        str(OUT / 'crystal-drift.ogg')], check=True)
    print(f'Music: {length:.2f}s, peak={np.max(np.abs(mix)):.3f}, '
          f'RMS={np.sqrt(np.mean(mix ** 2)):.3f}, '
          f'seam step={np.max(np.abs(mix[0] - mix[-1])):.5f}')


def shatter(combo=False):
    duration = 1.2 if combo else .95
    output = np.zeros((round(duration * RATE), 2))
    # A short brittle fracture, rolled off below the harshest noise frequencies.
    t = np.arange(round(.08 * RATE)) / RATE
    noise = RNG.normal(0, 1, len(t))
    crack = np.diff(noise, prepend=noise[0]) * np.exp(-t * 100) * .11
    output[:len(t)] += stereo(crack, 0)
    count = 25 if combo else 19
    for shard in range(count):
        delay = .008 + (shard / count) ** 1.45 * (.28 if combo else .22)
        life = RNG.uniform(.13, .55)
        t = np.arange(round(life * RATE)) / RATE
        f = RNG.uniform(1800, 6600)
        # Inharmonic, short resonances mimic tiny hard glass fragments.
        signal = np.sin(2 * np.pi * f * t) * np.exp(-t * RNG.uniform(14, 29))
        signal += .35 * np.sin(2 * np.pi * f * 1.472 * t) * np.exp(-t * 32)
        signal *= (1 - np.exp(-t * 1100)) * (.08 + RNG.random() * .07)
        start = round(delay * RATE)
        tail = min(len(signal), len(output) - start)
        output[start:start + tail] += stereo(signal[:tail], RNG.uniform(-.9, .9))
    # A soft resonant crystal bloom follows the fracture. Combos rise gently.
    for index, note in enumerate([84, 88, 91] if combo else [79, 86]):
        signal = stereo(bell(note, .8), (index - 1) * .45) * .15
        start = round((.10 + index * .055) * RATE)
        count = min(len(signal), len(output) - start)
        output[start:start + count] += signal[:count]
    output *= np.minimum(1, np.maximum(0, duration - np.arange(len(output)) / RATE) * 20)[:, None]
    output *= .78 / max(.78, np.max(np.abs(output)))
    write_wav(OUT / ('crystal-combo.wav' if combo else 'glass-shatter.wav'), output)


if __name__ == '__main__':
    compose()
    shatter()
    shatter(combo=True)
