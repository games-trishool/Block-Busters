extends SceneTree
## Viewport-delivered touch events exercise puzzle placement and the real GUI.

var checks := 0
var failures := 0
var app: Node2D

func _initialize() -> void:
	_run.call_deferred()

func _check(condition: bool, message: String) -> void:
	checks += 1
	if condition:
		print("PASS: ", message)
	else:
		failures += 1
		push_error("FAIL: " + message)

func _touch(position: Vector2, pressed: bool) -> void:
	var event := InputEventScreenTouch.new()
	event.index = 0
	event.position = position
	event.pressed = pressed
	Input.parse_input_event(event)
	await process_frame

func _tap(position: Vector2) -> void:
	await _touch(position, true)
	await _touch(position, false)
	await process_frame

func _first_fit(slot: int) -> Vector2i:
	for y in range(8):
		for x in range(8):
			var cell := Vector2i(x, y)
			if app.game.can_place(slot, cell):
				return cell
	return Vector2i(-1, -1)

func _cell_center(cell: Vector2i) -> Vector2:
	return Vector2(24, 194) + Vector2(cell) * 54.0 + Vector2(27, 27)

func _run() -> void:
	root.size = Vector2i(480, 900)
	app = load("res://scenes/main.tscn").instantiate()
	app.progress.save_path = "user://touch-ui-test-puzzle-progress.cfg"
	DirAccess.remove_absolute(app.progress.save_path)
	root.add_child(app)
	await process_frame
	await process_frame
	_check(bool(ProjectSettings.get_setting("input_devices/pointing/emulate_mouse_from_touch")), "project enables touchscreen-to-GUI input")
	_check(app.screen == "home", "touch flow starts at the puzzle home screen")
	await _tap(Vector2(240, 695))
	_check(app.screen == "game" and app.game.get_state() == "playing", "touching Play opens the active block puzzle")
	_check(app.game.moves == 0 and app.game.selected_slot == -1, "home button touch does not accidentally place or select a block")

	var first := _first_fit(0)
	_check(first.x >= 0, "first tray piece has a legal opening location")
	await _tap(Vector2(86, 750))
	_check(app.game.selected_slot == 0, "tapping a tray shape selects that actual piece")
	await _tap(_cell_center(first))
	_check(app.game.moves == 1 and bool(app.game.pieces[0]["used"]), "tap-select then tap-grid places a piece through touchscreen input")
	_check(app.game.score > 0 and app.progress.best_score >= app.game.score, "touch placement updates score and local best")

	# A dragged piece is lifted above the finger; aim its top-left ghost at a
	# legal cell using its actual shape extent, then release the same pointer.
	var second := _first_fit(1)
	var extent := Vector2i.ONE
	for value in app.game.pieces[1]["cells"]:
		var cell: Vector2i = value
		extent.x = maxi(extent.x, cell.x + 1)
		extent.y = maxi(extent.y, cell.y + 1)
	var drop := Vector2(24, 194) + Vector2(second) * 54.0 + Vector2(extent) * 27.0 + Vector2(0, 88)
	await _touch(Vector2(240, 750), true)
	var drag := InputEventScreenDrag.new()
	drag.index = 0
	drag.position = drop
	drag.relative = drop - Vector2(240, 750)
	Input.parse_input_event(drag)
	await process_frame
	await _touch(drop, false)
	await process_frame
	_check(second.x >= 0 and app.game.moves == 2 and bool(app.game.pieces[1]["used"]), "dragging and dropping a lifted shape commits its previewed placement")

	var held_board: Array = app.game.board.duplicate()
	await _tap(Vector2(422, 60))
	_check(app.screen == "pause" and app.game.get_state() == "paused", "HUD pause button works through real touch GUI events")
	await _tap(Vector2(240, 554))
	_check(app.screen == "settings" and app.game.get_state() == "paused", "touch Settings preserves the paused puzzle")
	var old_sound: bool = app.progress.sound_enabled
	await _tap(Vector2(384, 320))
	_check(app.screen == "settings" and app.progress.sound_enabled != old_sound and app.sounds.enabled == app.progress.sound_enabled, "touch sound switch updates the audio preference")
	var old_music: bool = app.progress.music_enabled
	var sound_before: bool = app.progress.sound_enabled
	await _tap(Vector2(384, 440))
	_check(app.progress.music_enabled != old_music and app.sounds.music_enabled == app.progress.music_enabled and app.progress.sound_enabled == sound_before, "touch music switch changes only background music")
	await _tap(Vector2(384, 440))
	_check(app.progress.music_enabled == old_music, "touch music switch can restore music")
	var old_haptics: bool = app.progress.haptics_enabled
	await _tap(Vector2(384, 560))
	_check(app.progress.haptics_enabled != old_haptics and app.game.haptics_enabled == app.progress.haptics_enabled, "touch haptic switch updates the puzzle preference")
	await _tap(Vector2(240, 780))
	_check(app.screen == "privacy", "touch Privacy opens the offline notice")
	await _tap(Vector2(240, 727))
	_check(app.screen == "licenses", "touch Engine licenses opens complete credits")
	await _tap(Vector2(240, 809))
	_check(app.screen == "privacy", "touch Back to privacy leaves credits")
	await _tap(Vector2(240, 790))
	_check(app.screen == "settings", "touch Back to settings preserves pause context")
	await _tap(Vector2(60, 60))
	_check(app.screen == "pause" and app.game.get_state() == "paused", "touch Back returns to the paused puzzle")
	await _tap(Vector2(240, 473))
	_check(app.screen == "game" and app.game.get_state() == "playing" and app.game.board == held_board, "touch Resume continues the same board without moving blocks")
	await _tap(Vector2(422, 60))
	await _tap(Vector2(240, 741))
	_check(app.screen == "home" and app.game.get_state() == "menu", "touch End run returns home without starting another puzzle")
	var path: String = app.progress.save_path
	app.queue_free()
	await process_frame
	DirAccess.remove_absolute(path)
	print("TOUCH UI TESTS: %d checks, %d failures" % [checks, failures])
	quit(1 if failures > 0 else 0)
