extends SceneTree
## Crystal material/refraction and shatter lifecycle regression checks.
const Gameplay = preload("res://scripts/gameplay.gd")
var checks := 0
var failures := 0

func _initialize() -> void:
	_run.call_deferred()

func _check(condition: bool, description: String) -> void:
	checks += 1
	if condition:
		print("PASS: ", description)
	else:
		failures += 1
		push_error("FAIL: " + description)

func _light(color: Color) -> float:
	return color.r * 0.2126 + color.g * 0.7152 + color.b * 0.0722

func _run() -> void:
	var game := Gameplay.new()
	root.add_child(game)
	game.start_run()
	var atlas := game.get_tile_atlas()
	var image := atlas.get_image()
	_check(image.get_width() == 864 and image.get_height() == 96, "gloss and all seven crystal colors fit the existing single atlas")
	var valid_material := true
	for slot in range(7):
		var offset := slot * 96
		var reflection := image.get_pixel(offset + 28, 25)
		var body := image.get_pixel(offset + 28, 61)
		var glint := image.get_pixel(offset + 16, 13)
		if _light(reflection) <= _light(body) + 0.05 or _light(glint) <= _light(body) + 0.2:
			valid_material = false
	_check(valid_material, "every crystal material has a bright reflected face and white specular glint over a deep body")
	_check(image.get_pixel(0, 0).a < 0.05 and image.get_pixel(48, 48).a > 0.99, "rounded crystal silhouette has transparent corners and a solid readable face")
	game.board.fill(0)
	for x in range(7): game.board[7 * 8 + x] = 3
	game.pieces[0] = {"cells": [Vector2i.ZERO], "color_index": 3, "used": false}
	game.place_piece(0, Vector2i(7, 7))
	_check(game.lines_cleared == 1 and game.score == 110, "crystal blast retains the real row clearing and scoring result")
	_check(game._particles.size() == 72 and game._flashes.size() == 8 and game._beams.size() == 1, "one row emits a bounded set of individual glass shards, crystal faces and one clear beam")
	var first: Dictionary = game._particles[0]
	var position: Vector2 = first["position"]
	var rotation := float(first["rotation"])
	game._process(0.05)
	_check(Vector2(first["position"]) != position and not is_equal_approx(float(first["rotation"]), rotation), "shards translate and rotate after the clear rather than remaining static squares")
	var before_pause := float(first["life"])
	game.set_paused(true)
	game._process(0.1)
	_check(is_equal_approx(float(first["life"]), before_pause), "pause freezes the shatter animation")
	game.set_paused(false)
	for repetition in range(40):
		game.board.fill(1)
		game._clear_lines()
	_check(game._particles.size() <= Gameplay.MAX_PARTICLES and game._flashes.size() <= 64 and game._beams.size() <= 16, "repeated full-board crystal blasts cannot grow effect buffers past their caps")
	_check(game.get_tile_atlas() == atlas and int(game.get_render_stats()["atlas_builds"]) == 1, "crystal bursts reuse their material atlas without rebuilding it")
	game._process(1.0)
	_check(not game.is_processing() and game._particles.is_empty() and game._flashes.is_empty() and game._beams.is_empty(), "all crystal fragments expire and rendering returns to an idle board")
	print("Crystal render checks: ", checks - failures, "/", checks, " passed")
	game.queue_free()
	quit(1 if failures else 0)
