extends SceneTree
## Meaningful headless checks for the endless block-placement puzzle.

const Gameplay = preload("res://scripts/gameplay.gd")
var failures := 0
var checks := 0
var game: Node2D
var finished_scores: Array[int] = []

func _initialize() -> void:
	_run.call_deferred()

func _check(condition: bool, description: String) -> void:
	checks += 1
	if condition:
		print("PASS: ", description)
	else:
		failures += 1
		push_error("FAIL: " + description)

func _piece(cells: Array, color_index: int = 1, used: bool = false) -> Dictionary:
	return {"cells": cells, "color_index": color_index, "used": used}

func _single(used: bool = false) -> Dictionary:
	return _piece([Vector2i.ZERO], 1, used)

func _clear_board() -> void:
	game.board.fill(0)

func _fresh(pieces: Array) -> void:
	game.start_run()
	_clear_board()
	game.pieces.assign(pieces)

func _occupied() -> int:
	var count := 0
	for value in game.board:
		if int(value) > 0:
			count += 1
	return count

func _tap(position: Vector2, index: int = 0) -> void:
	var event := InputEventScreenTouch.new()
	event.index = index
	event.position = position
	event.pressed = true
	game._unhandled_input(event)
	event = InputEventScreenTouch.new()
	event.index = index
	event.position = position
	event.pressed = false
	game._unhandled_input(event)

func _valid_board_without_full_lines() -> bool:
	if game.board.size() != 64:
		return false
	for value in game.board:
		if int(value) < 0 or int(value) > Gameplay.PALETTE.size():
			return false
	for axis in range(8):
		var row_full := true
		var column_full := true
		for coordinate in range(8):
			row_full = row_full and game.board[axis * 8 + coordinate] > 0
			column_full = column_full and game.board[coordinate * 8 + axis] > 0
		if row_full or column_full:
			return false
	return true

func _stress_endless_hands() -> void:
	game._rng.seed = 8675309
	game.start_run()
	var valid := true
	var completed := 0
	var renewed_hands := 0
	var runs := 1
	for turn in range(150):
		if game.get_state() == "game_over":
			if game.has_any_move():
				valid = false
				break
			runs += 1
			game.restart_run()
		if game.get_state() != "playing" or not game.has_any_move():
			valid = false
			break
		var chosen_slot := -1
		var chosen_cell := Vector2i(-1, -1)
		for slot in range(3):
			for y in range(8):
				for x in range(8):
					if game.can_place(slot, Vector2i(x, y)):
						chosen_slot = slot
						chosen_cell = Vector2i(x, y)
						break
				if chosen_slot >= 0: break
			if chosen_slot >= 0: break
		if chosen_slot < 0:
			valid = false
			break
		var available := 0
		for piece in game.pieces:
			if not bool(piece["used"]): available += 1
		var prior_score: int = game.score
		if not game.place_piece(chosen_slot, chosen_cell):
			valid = false
			break
		completed += 1
		if available == 1: renewed_hands += 1
		if game.score <= prior_score or game.pieces.size() != 3 or not _valid_board_without_full_lines():
			valid = false
			break
		if (game.get_state() == "playing") != game.has_any_move():
			valid = false
			break
	_check(valid and completed == 150 and renewed_hands >= 5, "150 deterministic self-play placements preserve board/score/clear/hand invariants across endless refills and valid run endings")
	print("Self-play exercised ", completed, " placements, ", renewed_hands, " renewed hands, ", runs, " runs.")

func _run() -> void:
	game = Gameplay.new()
	root.add_child(game)
	game.run_finished.connect(func(value: int): finished_scores.append(value))
	game.start_run()
	_check(game.get_state() == "playing" and game.score == 0, "new puzzle starts immediately with zero score")
	_check(game.board.size() == 64 and game.pieces.size() == 3, "board has eight-by-eight cells and three tray pieces")
	_check(_occupied() > 0 and game.has_any_move(), "seeded opening board is colorful and offers a legal move")
	var remaining := 0
	for piece in game.pieces:
		if not bool(piece["used"]): remaining += 1
	_check(remaining == 3, "all opening pieces are available")

	_fresh([_piece([Vector2i.ZERO, Vector2i(0, 1), Vector2i(1, 1)]), _single(), _single()])
	game.board[1] = 2
	_check(game.can_place(0, Vector2i.ZERO), "polyomino empty corners can overlap occupied cells without rejecting valid shape")
	_check(not game.can_place(0, Vector2i(-1, 0)) and not game.can_place(0, Vector2i(7, 7)), "placement rejects negative coordinates and cells outside the board")
	_check(not game.can_place(-1, Vector2i.ZERO) and not game.can_place(99, Vector2i.ZERO), "invalid tray slots cannot be placed")
	_check(game.place_piece(0, Vector2i.ZERO), "legal L-shaped placement succeeds")
	_check(game.board[0] == 1 and game.board[8] == 1 and game.board[9] == 1 and game.board[1] == 2, "placement fills exact shape cells and preserves existing tiles")
	_check(game.score == 30 and game.moves == 1, "placement awards ten points per cell and increments moves")
	_check(not game.place_piece(0, Vector2i(3, 3)) and game.score == 30, "used piece cannot be placed or score twice")
	_check(not game.can_place(1, Vector2i.ZERO), "occupied cells reject overlap")
	var before: Array = game.board.duplicate()
	_check(not game.place_piece(1, Vector2i.ZERO) and game.board == before and not game.pieces[1]["used"], "invalid placement neither mutates board nor consumes the piece")

	_fresh([_single(), _single(), _single()])
	for x in range(7): game.board[x] = 1
	_check(game.place_piece(0, Vector2i(7, 0)), "filling the last cell in a row succeeds")
	_check(_occupied() == 0 and game.lines_cleared == 1, "full row clears exactly once")
	_check(game.score == 110 and game.combo == 1, "first clear awards placement and line bonus")
	for x in range(7): game.board[8 + x] = 2
	game.place_piece(1, Vector2i(7, 1))
	_check(game.score == 320 and game.combo == 2 and game.lines_cleared == 2, "consecutive line clears increase combo multiplier")
	game.place_piece(2, Vector2i(4, 4))
	_check(game.combo == 0, "a placement without a clear ends the clear combo")

	_fresh([_single(), _single(), _single()])
	for x in range(8):
		if x != 3: game.board[3 * 8 + x] = 2
	for y in range(8):
		if y != 3: game.board[y * 8 + 3] = 3
	game.place_piece(0, Vector2i(3, 3))
	_check(_occupied() == 0 and game.lines_cleared == 2, "crossing full row and column clear simultaneously without leaving intersection tiles")
	_check(game.score == 210 and game.combo == 1, "simultaneous row and column award two line bonuses without double placement scoring")

	_fresh([_single(), _single(), _single()])
	game.place_piece(0, Vector2i.ZERO)
	_check(bool(game.pieces[0]["used"]) and not bool(game.pieces[1]["used"]), "placing one piece keeps the rest of the same hand")
	game.place_piece(1, Vector2i(2, 0))
	_check(bool(game.pieces[0]["used"]) and bool(game.pieces[1]["used"]) and not bool(game.pieces[2]["used"]), "hand remains until all three pieces are used")
	game.place_piece(2, Vector2i(4, 0))
	var renewed: bool = game.pieces.size() == 3
	for piece in game.pieces: renewed = renewed and not bool(piece["used"])
	_check(renewed and game.has_any_move(), "using the third piece generates a new hand with a legal move")
	_fresh([_single(), _single(), _single()])
	for y in range(8):
		for x in range(8): game.board[y * 8 + x] = 1 if (x + y) % 2 == 0 else 0
	game.place_piece(0, Vector2i(1, 0))
	game.place_piece(1, Vector2i(3, 0))
	game.place_piece(2, Vector2i(5, 0))
	_check(game.get_state() == "playing" and game.has_any_move(), "new hand offers a fitting piece even when only isolated single-cell gaps remain")

	var domino := _piece([Vector2i.ZERO, Vector2i(1, 0)])
	_fresh([domino, domino.duplicate(true), domino.duplicate(true)])
	for y in range(8):
		for x in range(8): game.board[y * 8 + x] = 1 if (x + y) % 2 == 0 else 0
	_check(not game.has_any_move(), "no-move detection checks actual shapes across every board origin")
	game.pieces[0] = _single()
	_check(game.has_any_move(), "a single fitting piece keeps the puzzle playable")
	var prior_results := finished_scores.size()
	game.place_piece(0, Vector2i(1, 0))
	_check(game.get_state() == "game_over" and finished_scores.size() == prior_results + 1 and finished_scores[-1] == 10, "using the last fitting piece ends the run once with its final score")
	_check(not game.place_piece(1, Vector2i(1, 2)) and finished_scores.size() == prior_results + 1, "game-over placements do not change score or emit extra results")

	_fresh([_single(), _single(), _single()])
	game.set_paused(true)
	_check(game.get_state() == "paused" and not game.place_piece(0, Vector2i.ZERO), "pause blocks placement and scoring")
	game.set_paused(false)
	_check(game.get_state() == "playing" and game.place_piece(0, Vector2i.ZERO), "resume restores the same playable puzzle")

	_fresh([_single(), _single(), _single()])
	_tap(Vector2(86, 750))
	_tap(Vector2(24 + 4 * 54 + 27, 194 + 2 * 54 + 27))
	_check(game.board[2 * 8 + 4] == 1 and bool(game.pieces[0]["used"]), "touch supports selecting a tray piece then tapping its board destination")

	_fresh([_single(), _single(), _single()])
	game.position = Vector2(53, 71)
	_tap(Vector2(86, 750) + game.position)
	_tap(Vector2(24 + 3 * 54 + 27, 194 + 3 * 54 + 27) + game.position)
	_check(game.board[3 * 8 + 3] == 1, "touch coordinates account for centered canvas offsets on wider or taller devices")
	game.position = Vector2.ZERO

	_fresh([_single(), _single(), _single()])
	var finger := InputEventScreenTouch.new()
	finger.index = 0
	finger.position = Vector2(86, 750)
	finger.pressed = true
	game._unhandled_input(finger)
	var duplicate_mouse := InputEventMouseButton.new()
	duplicate_mouse.device = -1
	duplicate_mouse.button_index = MOUSE_BUTTON_LEFT
	duplicate_mouse.position = Vector2(394, 750)
	duplicate_mouse.pressed = true
	game._unhandled_input(duplicate_mouse)
	var drag := InputEventScreenDrag.new()
	drag.index = 0
	drag.position = Vector2(51, 309)
	game._unhandled_input(drag)
	finger = InputEventScreenTouch.new()
	finger.index = 0
	finger.position = drag.position
	finger.pressed = false
	game._unhandled_input(finger)
	_check(game.board[0] == 1 and bool(game.pieces[0]["used"]) and not bool(game.pieces[2]["used"]), "finger drag lifts the piece above the pointer and ignores duplicate emulated mouse input")

	_fresh([_single(), _single(), _single()])
	var mouse := InputEventMouseButton.new()
	mouse.button_index = MOUSE_BUTTON_LEFT
	mouse.position = Vector2(240, 750)
	mouse.pressed = true
	game._unhandled_input(mouse)
	var motion := InputEventMouseMotion.new()
	motion.position = Vector2(159, 329)
	game._unhandled_input(motion)
	mouse = InputEventMouseButton.new()
	mouse.button_index = MOUSE_BUTTON_LEFT
	mouse.position = motion.position
	mouse.pressed = false
	game._unhandled_input(mouse)
	_check(game.board[2 * 8 + 2] == 1 and bool(game.pieces[1]["used"]), "desktop mouse drag places the piece centered at the destination without touch lift")

	_fresh([_single(), _single(), _single()])
	finger = InputEventScreenTouch.new()
	finger.index = 0
	finger.position = Vector2(86, 750)
	finger.pressed = true
	game._unhandled_input(finger)
	game.set_paused(true)
	game.set_paused(false)
	finger = InputEventScreenTouch.new()
	finger.index = 0
	finger.position = Vector2(51, 309)
	finger.pressed = false
	game._unhandled_input(finger)
	_check(_occupied() == 0 and game.score == 0, "pause cancels a held drag so releasing after resume cannot place accidentally")

	_fresh([_single(), _single(), _single()])
	game.set_paused(true)
	_tap(Vector2(86, 750))
	_tap(Vector2(51, 221))
	_check(_occupied() == 0 and game.score == 0, "paused touch gestures cannot consume pieces or alter the board")
	game.reset_to_menu()
	_check(game.get_state() == "menu", "returning home deactivates puzzle input")
	_stress_endless_hands()
	var render: Dictionary = game.get_render_stats()
	_check(int(render["atlas_builds"]) == 1 and int(render["atlas_cells"]) == 9, "one shared high-resolution cube atlas is reused across all puzzle runs")
	_check(int(render["particles"]) <= Gameplay.MAX_PARTICLES and int(render["flashes"]) <= 64 and int(render["beams"]) <= 16 and int(render["active_pops"]) <= 64, "repeated puzzle clears keep every visual effect buffer bounded")
	game._process(1.0)
	render = game.get_render_stats()
	_check(not game.is_processing() and int(render["particles"]) == 0 and int(render["flashes"]) == 0 and int(render["beams"]) == 0 and int(render["active_pops"]) == 0, "finished effects release animation work and return the board to idle")
	print("Puzzle checks: ", checks - failures, "/", checks, " passed")
	game.queue_free()
	quit(1 if failures else 0)
