extends SceneTree
## Music lifecycle, independent preferences, and crystal asset integration.

var checks := 0
var failures := 0

func _initialize() -> void:
	_run.call_deferred()

func check(condition: bool, message: String) -> void:
	checks += 1
	if condition:
		print("PASS: ", message)
	else:
		failures += 1
		push_error("FAIL: " + message)

func _run() -> void:
	var sound_script = load("res://scripts/audio.gd")
	var bank = sound_script.new()
	root.add_child(bank)
	await process_frame
	var state: Dictionary = bank.get_audio_state()
	check(not state.unlocked and not state.music_playing, "music waits for first user gesture")
	check(state.effect_voices == 6, "effects have a fixed six-voice pool")
	check(bank._music.stream is AudioStreamOggVorbis and bank._music.stream.loop, "original ambient soundtrack is a looping Ogg stream")
	check(absf(bank._music.stream.get_length() - 24.0) < 0.01, "eight-bar soundtrack has the expected full loop length")
	check(bank._music.volume_db == -19.0, "music is mixed quietly behind puzzle effects")
	check(bank._effects.clear is AudioStreamWAV and bank._effects.clear.get_length() >= 0.9, "line clears use the original glass-shatter recording")
	check(bank._effects.combo != bank._effects.clear and bank._effects.combo.get_length() > 1.0, "combos have a distinct longer crystal cascade")
	bank.unlock_audio()
	state = bank.get_audio_state()
	check(state.unlocked and state.music_started and state.music_playing, "first gesture starts the ambient music")
	bank.play("clear")
	check(bank.get_audio_state().active_effect_voices == 1, "glass effect plays over the music")
	bank.enabled = false
	state = bank.get_audio_state()
	check(state.active_effect_voices == 0 and state.music_playing, "turning effects off stops their voices and leaves music playing")
	var plays: int = state.effect_plays
	bank.play("combo")
	check(bank.get_audio_state().effect_plays == plays, "effects preference prevents new effects")
	bank.set_music_enabled(false)
	check(not bank.get_audio_state().music_playing and bank._music.stream_paused, "turning music off pauses its decoder")
	bank.enabled = true
	bank.play("clear")
	check(bank.get_audio_state().active_effect_voices > 0 and not bank.get_audio_state().music_playing, "effects remain audible while music is switched off")
	bank.set_music_enabled(true)
	check(bank.get_audio_state().music_playing, "enabling music resumes its loop")
	bank.set_focus_active(false)
	state = bank.get_audio_state()
	check(not state.music_playing and state.active_effect_voices == 0, "backgrounding silences music and all effects")
	plays = state.effect_plays
	bank.play("clear")
	check(bank.get_audio_state().effect_plays == plays, "background app cannot emit a stray blast sound")
	bank.set_focus_active(true)
	check(bank.get_audio_state().music_playing, "foregrounding resumes the music preference")
	bank.set_music_enabled(false)
	bank.set_focus_active(false)
	bank.set_focus_active(true)
	check(not bank.get_audio_state().music_playing, "foregrounding honors a disabled music preference")
	bank.set_music_enabled(true)
	for i in range(30):
		bank.play("combo")
	check(bank.get_audio_state().effect_voices == 6 and bank.get_audio_state().active_effect_voices <= 6, "rapid blasts reuse bounded effect voices")
	bank.queue_free()
	await process_frame

	var store_script = load("res://scripts/save_store.gd")
	var store = store_script.new()
	store.save_path = "user://audio-test-progress.cfg"
	DirAccess.remove_absolute(store.save_path)
	store.load_data()
	check(store.music_enabled, "fresh installs default to enabled background music")
	store.music_enabled = false
	store.sound_enabled = true
	store.haptics_enabled = false
	store.best_score = 4321
	check(store.save_data() == OK, "music preference atomically saves with progress")
	var restored = store_script.new()
	restored.save_path = store.save_path
	restored.load_data()
	check(not restored.music_enabled and restored.sound_enabled and not restored.haptics_enabled and restored.best_score == 4321, "music preference reloads independently of effects, haptics and score")
	var legacy := ConfigFile.new()
	legacy.set_value("settings", "sound", false)
	legacy.set_value("progress", "best_score", 987)
	legacy.save(store.save_path)
	var migrated = store_script.new()
	migrated.save_path = store.save_path
	migrated.load_data()
	check(migrated.music_enabled and not migrated.sound_enabled and migrated.best_score == 987, "pre-music saves gain the safe music default without losing prior preferences")
	DirAccess.remove_absolute(store.save_path)
	print("Audio: ", checks - failures, "/", checks, " checks passed")
	quit(1 if failures else 0)
